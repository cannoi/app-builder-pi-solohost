import path from 'node:path';
import { SYSTEM, ideaPrompt, planPrompt, codePrompt, patchPrompt, reviewPrompt, chatPrompt, builderChatPrompt, descriptionPrompt } from '../ai/prompts.js';
import { localAnalysis, localPlan, writeGeneratedFiles, scaffoldFromTemplate, writeGithubWorkflow } from '../projects/generator.js';
import { matchTemplates, getTemplateById, fillProjectFromTemplate } from '../templates/library.js';
import { selectRealTemplate, isDemoTemplate } from '../templates/select-real.js';
import { runInitQualityLoop } from '../templates/init-loop.js';
import { professionalUiGuard, domainFeatureHints } from '../templates/first-run-quality.js';
import { createTaskContext, runWithTaskContext, enterTaskContext, updateTaskProgress, appendTaskEvent, closeTaskContext, saveTaskCheckpoint, getActiveTaskContext } from '../agent/task-context.js';
import { importZipBuffer } from '../projects/importer.js';
import { runStaticTests, runNodeTests } from '../testing/engine.js';
import { scanProject } from '../security/scanner.js';
import { clampText } from '../utils/validate.js';
import { listFiles } from '../utils/fsx.js';
import { buildAiProjectContext, collectProjectContextText } from '../services/project-context-resolver.js';
import fs from 'node:fs/promises';
import dns from 'node:dns/promises';
import https from 'node:https';
import { saveAttachment, attachmentContext, attachmentList, imageInputsFromAttachments } from '../projects/attachments.js';
import { writeSoloHostPackage } from '../release/solohost.js';
import { stableHostPort } from '../release/solohost-port.js';
import { detectAppProfile } from '../runtime/app-profile.js';
import { snapshotTree, diffTrees, formatDiffBrief } from '../projects/import-diff.js';
import { formatSoloHostErrors } from '../release/manager.js';
import { inferAction, extractGhcrImage, guessSoloHostPorts, classifyLogs, classifyFailureLayer, formatLayerDiagnosis, describeFailure, diagnoseSource, nextStep, guideCard, isHostDockerCommand, isNpmOnEmptyRisk, splitUserSteps, parseGithubRepoUrl } from '../scripts/ops.js';
import { stampMadeBy } from '../projects/badge.js';
import { createProjectZip } from '../projects/exporter.js';
import { gcDocker } from '../docker/cleanup.js';
import { detectUserLanguage, languageInstruction, languageInstructionFor } from '../ai/language.js';
import { publishToGitHub } from '../github/publish.js';
import { ensureMissingDependencies } from '../projects/deps-fix.js';
import { runDare, formatDareReport } from '../dare/engine.js';
import { shouldBlockRepeatedAction, nextRepeatState, repairFingerprint } from './loop-guard.js';
import { mergeVerificationState } from './verification.js';
import { maskSecrets } from '../utils/mask.js';
import { inspectUpgrade, diagnoseUpgradeRequest, applyUpgrade, runRuleUpgrade, beginUpgradeSession, resumeUpgrade, isUpgradePauseError, resolveEmptyUpgradePlan, planHasFileChanges } from '../upgrade/engine.js';
import { diagnoseProject, buildAdvisorReport } from '../diagnose/project.js';
import { refreshProjectBrain, rememberFailedRepair, wasRepairTried } from '../diagnose/brain.js';
import { mapPatchResult, formatOutcomeMessage, outcomeBrief, localeOf, OUTCOMES } from './outcomes.js';
import { filterPatchFiles, remapAndFilterPatchFiles } from './path-safety.js';
import { ensureBoilerplate } from './scaffolds.js';
import { evaluateProductDepth, isLocalDefaults, hasConfiguredAi } from './product-checklist.js';
import { enrichPlan, planCompleteness } from './plan-enrich.js';
import { generateCodeMultiPhase } from './multi-phase-codegen.js';
import { requestImprovePatch } from './improve-ai-cycle.js';
import { classifyFailure, shouldTriggerAiRepair } from '../testing/classify-failure.js';
import { buildAcceptancePlan, formatAcceptancePlanSummary, evaluateAcceptance, buildOptimalAlternatives, formatAlternativesMessage } from './acceptance.js';
import { AgentOrchestrator, formatPlanChecklistText } from '../agent/orchestrator.js';

// Safety net only — does not change what inspectUpgrade does on the happy path.
// Without this, a slow/unusual imported repo (e.g. a hung install/test step)
// could leave the Upgrade job stuck in "running" forever: the busy bar never
// clears and no message is ever shown, which looks exactly like a broken
// button. This guarantees the job always settles within a bounded time.
const UPGRADE_INSPECT_TIMEOUT_MS = 5 * 60 * 1000;
function withTimeout(promise, ms, message) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(message)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

export function registerPipeline(app) {
  const { jobs, ai, projects, snapshots, runner, sandbox, github, releases, cfg, log } = app;
  const orchestrator = new AgentOrchestrator({ ai, projects });

  // Upgrade Workshop is deliberately isolated from create_app/improve flows.
  jobs.on('project_diagnose', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    emit('inspect', 'running', '🩺 Inspecting the project before making any change…');
    const runtime = await projects.readMetadata(project, 'runtime-state.json', {});
    const recent = await projects.readMetadata(project, 'runtime-diagnostics.json', {});
    const logs = [recent?.error, recent?.logs, runtime?.error, runtime?.logs].filter(Boolean).join('\n');
    const report = await diagnoseProject({ project: projects.get(project.id), projects, db: app.db, ai, logs });
    await refreshProjectBrain({ project, projects, db: app.db, extra: { notes: report.rootCause } });
    emit('diagnose', 'done', `Diagnosis complete: ${report.confidence} confidence. No files were changed.`);
    return { projectId: project.id, diagnosis: report, status: 'DIAGNOSED', brief: formatProjectDiagnosis(report) };
  });

  jobs.on('builder_advisor', async (job, { emit }) => {
    const project = job.payload.projectId ? projects.get(job.payload.projectId) : (projects.list()[0] || null);
    emit('advisor', 'running', '🧭 Reviewing session history. No files will be changed.');
    const report = await buildAdvisorReport({ project, projects, db: app.db, scope: job.payload.scope || '30d' });
    if (project) await refreshProjectBrain({ project, projects, db: app.db });
    emit('advisor', 'done', formatAdvisor(report));
    return { projectId: project?.id || null, advisor: report, status: 'ADVISOR_READY', brief: formatAdvisor(report) };
  });

  jobs.on('upgrade_github_import', async (job, { emit }) => {
    const parsed = parseGithubRepoUrl(job.payload.url);
    if (!parsed) throw new Error('Use a public GitHub repository URL such as https://github.com/owner/repository');
    const owner = parsed.owner;
    const repo = parsed.repo;
    const url = parsed.url;
    const archiveUrl = `https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/zipball/HEAD`;
    emit('import', 'running', `Fetching public GitHub source: ${owner}/${repo}…`);
    const response = await fetch(archiveUrl, { headers: { Accept: 'application/vnd.github+json', 'User-Agent': 'pi-app-factory-upgrade' } });
    if (!response.ok) throw new Error(`GitHub public repository could not be downloaded (HTTP ${response.status}).`);
    const buffer = Buffer.from(await response.arrayBuffer());
    let sourceCommit = 'HEAD';
    try {
      const commitResponse = await fetch(`https://api.github.com/repos/${encodeURIComponent(owner)}/${encodeURIComponent(repo)}/commits/HEAD`, { headers: { Accept: 'application/vnd.github+json', 'User-Agent': 'pi-app-factory-upgrade' } });
      if (commitResponse.ok) sourceCommit = String((await commitResponse.json())?.sha || 'HEAD');
    } catch {}
    const project = await projects.create({ idea: `Upgrade existing GitHub app: ${owner}/${repo}`, name: repo, analysis: { name: repo, slug: repo, recommended_stack: {} }, plan: { mode: 'upgrade-existing' } });
    jobs.attachProject(job.id, project.id);
    await importZipBuffer(buffer, projects.sourceDir(project.slug), { replace: true });
    await projects.saveMetadata(project, 'upgrade-source.json', { type: 'github-public', url, owner, repo, ref: 'HEAD', commit: sourceCommit, importedAt: new Date().toISOString() });
    await projects.saveMetadata(project, 'origin.json', { origin: 'upgrade', sourceType: 'github-public', url, owner, repo, commit: sourceCommit, updatedAt: new Date().toISOString() });
    projects.setStatus(project, 'UPGRADE_INSPECTING');
    emit('import', 'done', 'GitHub source imported. Starting the independent Upgrade Workshop.');
    // 1.8.18: GitHub import skips Build checks. Baseline is optional/best-effort only.
    emit('inspect', 'running', 'Registering the imported app (no scan/repair)…');
    let result = { ready: true, baseline: { fileCount: 0 }, safeRepairs: [], issues: [] };
    try {
      result = await withTimeout(
        inspectUpgrade({ project: projects.get(project.id), projects, snapshots, log }),
        Math.min(UPGRADE_INSPECT_TIMEOUT_MS, 45000),
        'Baseline registration timed out — app is still ready without Build checks.',
      );
    } catch (err) {
      emit('inspect', 'done', `Baseline skipped: ${String(err.message || err).slice(0, 160)}`);
      result = {
        ready: true,
        baseline: { fileCount: 0 },
        issues: [],
        safeRepairs: [],
        brief: `Project ${repo} imported. Checks skipped (only apps created in Builder are auto-scanned).`,
      };
    }
    projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
    emit('inspect', 'done', '✓ GitHub import ready — scan/DARE/repair skipped.');
    return {
      projectId: project.id,
      source: { type: 'github-public', owner, repo, url },
      importSkippedChecks: true,
      ...result,
      ready: true,
    };
  });

  jobs.on('upgrade_inspect', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    await projects.saveMetadata(project, 'origin.json', { ...(await projects.readMetadata(project, 'origin.json', {})), origin: 'upgrade', updatedAt: new Date().toISOString() });
    projects.setStatus(project, 'UPGRADE_INSPECTING');
    emit('inspect', 'running', 'Registering the existing app and creating a non-repairing Upgrade baseline…');
    const result = await withTimeout(
      inspectUpgrade({ project: projects.get(project.id), projects, snapshots, log }),
      UPGRADE_INSPECT_TIMEOUT_MS,
      'Upgrade inspection took too long and was stopped. This can happen with large or unusual repositories — try again, or use Import ZIP with just the app source instead.',
    );
    projects.setStatus(projects.get(project.id), 'UPGRADE_READY'); // never lock Upgrade on inspect
    emit('baseline', 'done', `Upgrade baseline ready. No Build scan or repair was run. ${result.baseline.fileCount} file(s) registered.`);
    return result;
  });

  jobs.on('upgrade_request', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    const baseline = await projects.readMetadata(project, 'upgrade-baseline.json', null);
    if (!baseline) throw new Error('Upgrade baseline is missing. Inspect the app first.');
    projects.setStatus(project, 'UPGRADE_DIAGNOSING');
    const request = String(job.payload.request || '').trim();
    const ruleText = String(job.payload.ruleText || '').trim();
    const pastedRule = /RULE_NAME|REQUIRED CAPABILITIES|REQUIRED_CAPABILITIES/i.test(request);
    const existingSession = await projects.readMetadata(project, 'upgrade-session.json', null);
    const wasResumed = Boolean(existingSession?.status === 'paused' && existingSession?.resumable && existingSession?.request === request);
    const session = await beginUpgradeSession({ project, projects, request, mode: (ruleText || pastedRule) ? 'rule' : 'normal' });
    if (ruleText || pastedRule) {
      try {
        const result = await runRuleUpgrade({ project, projects, snapshots, ai, request, ruleText: ruleText || request, emit, resume: wasResumed && session.mode === 'rule' });
        const currentSession = await projects.readMetadata(project, 'upgrade-session.json', {});
        if (result.status === 'completed') {
          await projects.saveMetadata(project, 'upgrade-session.json', { ...currentSession, status: 'completed', resumable: false, phase: 'complete', completedSteps: [...new Set([...(currentSession.completedSteps || []), ...(result.execution?.tasks || []).filter((t) => ['done','satisfied'].includes(t.status)).map((t) => t.id)])], finishedAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
        } else if (!result.needsUserAction) {
          await projects.saveMetadata(project, 'upgrade-session.json', { ...currentSession, status: 'paused', resumable: true, phase: 'rule', updatedAt: new Date().toISOString() });
        }
        projects.setStatus(projects.get(project.id), 'UPGRADE_READY'); // keep Upgrade unlocked; session may still be paused
        return { ...result, session: await projects.readMetadata(project, 'upgrade-session.json', {}) };
      } catch (err) {
        if (isUpgradePauseError(err)) {
          const paused = await projects.readMetadata(project, 'upgrade-rule-execution.json', {});
          const currentSession = await projects.readMetadata(project, 'upgrade-session.json', {});
          await projects.saveMetadata(project, 'upgrade-session.json', { ...currentSession, status: 'paused', resumable: true, mode: 'rule', phase: 'rule', currentStep: paused?.tasks?.find((t) => t.status === 'pending')?.id || currentSession.currentStep || 'rule', lastError: { code: String(err.code || 'PAUSED_AI_UNAVAILABLE'), message: String(err.message || err).slice(0, 1200), at: new Date().toISOString() }, updatedAt: new Date().toISOString() });
          projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
          emit('pause', 'done', `⏸ Upgrade paused safely: ${String(err.message || err).slice(0, 220)}. Resume to continue from the saved task.`);
          return { projectId: project.id, paused: true, resumable: true, execution: paused, session: await projects.readMetadata(project, 'upgrade-session.json', {}), brief: 'Upgrade paused safely. Verified work was kept. Resume to continue from the saved task.' };
        }
        throw err;
      }
    }
    const existingPlan = await projects.readMetadata(project, 'upgrade-plan.json', null);
    if (existingPlan && wasResumed && session.status === 'running' && session.phase !== 'plan') {
      emit('patch', 'running', 'Continuing from the saved Upgrade plan. No completed step will be repeated.');
      try {
        const applied = await resumeUpgrade({ project: projects.get(project.id), projects, snapshots, ai, request, emit });
        projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
        return applied;
      } catch (err) {
        if (isUpgradePauseError(err)) {
          await projects.saveMetadata(project, 'upgrade-session.json', await projects.readMetadata(project, 'upgrade-session.json', {}));
          projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
          emit('pause', 'done', `⏸ Upgrade paused safely: ${String(err.message || err).slice(0, 220)}. Resume to continue.`);
          return { projectId: project.id, paused: true, resumable: true, session: await projects.readMetadata(project, 'upgrade-session.json', {}), brief: 'Upgrade paused safely. Verified work was kept. Resume to continue.' };
        }
        throw err;
      }
    }
    emit('diagnose', 'running', 'Inspecting the real app and creating the Upgrade plan…');
    try {
      let plan = await diagnoseUpgradeRequest({ project, projects, ai, request, ruleText: '' });
      await projects.saveMetadata(project, 'upgrade-plan.json', { ...plan, request, createdAt: new Date().toISOString() });
      await projects.updateMetadata?.(project, 'upgrade-session.json', {});
      const secretStop = /secret|credential|wallet|private key/i.test(String(plan.needs_user_action || ''));
      if (secretStop) {
        projects.setStatus(projects.get(project.id), 'UPGRADE_READY'); // advisory only — do not lock Upgrade
        emit('recommend', 'done', plan.needs_user_action);
        return { projectId: project.id, plan, needsUserAction: true, needsApproval: false, brief: plan.needs_user_action, upgradeUnlocked: true };
      }
      // Empty plan must resolve to NO_CHANGE / REPLAN — never PAUSE
      if (!planHasFileChanges(plan)) {
        const resolved = await resolveEmptyUpgradePlan({
          project: projects.get(project.id), projects, ai, plan, request, emit,
          replanCount: Number(plan.replanCount || 0),
        });
        if (resolved.noChange) {
          projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
          return {
            projectId: project.id,
            plan: resolved.plan || plan,
            execution: { files: [], noChange: true },
            session: resolved.session || await projects.readMetadata(project, 'upgrade-session.json', {}),
            needsApproval: false,
            brief: resolved.brief || 'Upgrade analyzed. No code changes were required.',
            next: 'Open preview or Publish if ready.',
            terminalState: 'COMPLETED_NO_CHANGE',
          };
        }
        // Replan produced files — apply them
        plan = resolved.plan;
        await projects.saveMetadata(project, 'upgrade-plan.json', { ...plan, request, createdAt: new Date().toISOString() });
      }
      emit('patch', 'running', 'Applying the upgrade. No extra confirmation is required.');
      const applied = await applyUpgrade({ project: projects.get(project.id), projects, snapshots, plan, request, approved: true, ruleExecution: true });
      const sessionNow = await projects.readMetadata(project, 'upgrade-session.json', {});
      await projects.saveMetadata(project, 'upgrade-session.json', { ...sessionNow, status: 'completed', resumable: false, phase: 'complete', currentStep: 'verify', completedSteps: [...new Set([...(sessionNow.completedSteps || []), 'diagnose', 'apply', 'verify'])], changedFiles: [...new Set([...(sessionNow.changedFiles || []), ...(applied.files || [])])], finalHash: applied.sourceHash || sessionNow.workingHash || null, finishedAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
      projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
      emit('verify', 'done', `Upgrade verified. ${applied.files.length} file(s) changed. Rollback is available if you want the previous version.`);
      return { projectId: project.id, plan, execution: applied, session: await projects.readMetadata(project, 'upgrade-session.json', {}), needsApproval: false, brief: plan.recommendation || 'Upgrade completed.', next: 'Open preview or Publish. Use Rollback if this is not what you wanted.' };
    } catch (err) {
      // AI_NO_CHANGE is never a provider pause — resolve empty plan instead of looping
      if (err?.code === 'AI_NO_CHANGE' || /contains no file changes/i.test(String(err?.message || ''))) {
        const currentPlan = await projects.readMetadata(project, 'upgrade-plan.json', {});
        const resolved = await resolveEmptyUpgradePlan({
          project: projects.get(project.id), projects, ai, plan: currentPlan, request, emit,
          replanCount: Number(currentPlan?.replanCount || 0),
        });
        if (resolved.noChange) {
          projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
          return {
            projectId: project.id,
            plan: resolved.plan || currentPlan,
            execution: { files: [], noChange: true },
            session: resolved.session || await projects.readMetadata(project, 'upgrade-session.json', {}),
            needsApproval: false,
            brief: resolved.brief || 'Upgrade analyzed. No code changes were required.',
            terminalState: 'COMPLETED_NO_CHANGE',
          };
        }
        // Replan produced files on catch path — apply once
        try {
          const applied = await applyUpgrade({ project: projects.get(project.id), projects, snapshots, plan: resolved.plan, request, approved: true, ruleExecution: true });
          projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
          emit('verify', 'done', `Upgrade verified after replan. ${(applied.files || []).length} file(s) changed.`);
          return { projectId: project.id, plan: resolved.plan, execution: applied, needsApproval: false, brief: resolved.plan?.recommendation || 'Upgrade completed after replan.' };
        } catch (applyErr) {
          if (isUpgradePauseError(applyErr)) {
            const sessionPaused = await projects.readMetadata(project, 'upgrade-session.json', {});
            await projects.saveMetadata(project, 'upgrade-session.json', { ...sessionPaused, status: 'paused', resumable: true, lastError: { code: String(applyErr.code || 'PAUSED_AI_UNAVAILABLE'), message: String(applyErr.message || applyErr).slice(0, 1200), at: new Date().toISOString() }, updatedAt: new Date().toISOString() });
            projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
            emit('pause', 'done', `⏸ Provider unavailable. Verified work is preserved. Resume when ready.`);
            return { projectId: project.id, paused: true, resumable: true, session: await projects.readMetadata(project, 'upgrade-session.json', {}), brief: 'Upgrade paused: provider unavailable. Verified work preserved.' };
          }
          projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
          throw applyErr;
        }
      }
      if (isUpgradePauseError(err)) {
        const sessionPaused = await projects.readMetadata(project, 'upgrade-session.json', {});
        await projects.saveMetadata(project, 'upgrade-session.json', { ...sessionPaused, status: 'paused', resumable: true, lastError: { code: String(err.code || 'PAUSED_AI_UNAVAILABLE'), message: String(err.message || err).slice(0, 1200), at: new Date().toISOString() }, updatedAt: new Date().toISOString() });
        projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
        emit('pause', 'done', `⏸ Upgrade paused safely: ${String(err.message || err).slice(0, 220)}. Resume to continue from the saved plan.`);
        return { projectId: project.id, paused: true, resumable: true, session: await projects.readMetadata(project, 'upgrade-session.json', {}), plan: await projects.readMetadata(project, 'upgrade-plan.json', null), brief: 'Upgrade paused safely. No verified work was rolled back. Resume to continue from the saved plan.' };
      }
      const currentSession = await projects.readMetadata(project, 'upgrade-session.json', {});
      if (currentSession?.phase === 'apply') {
        await projects.saveMetadata(project, 'upgrade-plan-last-failed.json', await projects.readMetadata(project, 'upgrade-plan.json', null));
        await projects.saveMetadata(project, 'upgrade-session.json', { ...currentSession, status: 'paused', resumable: true, phase: 'plan', currentStep: 'diagnose', lastError: { code: String(err.code || 'UPGRADE_VERIFY_FAILED'), message: String(err.message || err).slice(0, 1200), at: new Date().toISOString() }, updatedAt: new Date().toISOString() });
      }
      projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
      throw err;
    }
  });

  jobs.on('upgrade_resume', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    const session = await projects.readMetadata(project, 'upgrade-session.json', null);
    if (!session?.resumable) throw new Error('No resumable Upgrade session is available.');
    projects.setStatus(projects.get(project.id), 'UPGRADE_DIAGNOSING');
    const resumed = await projects.readMetadata(project, 'upgrade-session.json', {});
    await projects.saveMetadata(project, 'upgrade-session.json', { ...resumed, status: 'running', lastError: null, updatedAt: new Date().toISOString() });
    try {
      if (session.mode === 'rule') {
        const ruleState = await projects.readMetadata(project, 'upgrade-rule-execution.json', {});
        const ruleText = await projects.readMetadata(project, 'upgrade-rule.json', {});
        const result = await runRuleUpgrade({ project, projects, snapshots, ai, request: session.request, ruleText: ruleText?.rule?.source || session.request, emit, resume: true });
        projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
        return result;
      }
      const result = await resumeUpgrade({ project, projects, snapshots, ai, request: session.request, emit });
      projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
      return result;
    } catch (err) {
      if (isUpgradePauseError(err)) {
        const current = await projects.readMetadata(project, 'upgrade-session.json', {});
        await projects.saveMetadata(project, 'upgrade-session.json', { ...current, status: 'paused', resumable: true, lastError: { code: String(err.code || 'PAUSED_AI_UNAVAILABLE'), message: String(err.message || err).slice(0, 1200), at: new Date().toISOString() }, updatedAt: new Date().toISOString() });
        projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
        emit('pause', 'done', `⏸ AI provider temporarily unavailable. Verified work is preserved. Resume will continue from ${current.currentStep || 'the saved step'}.`);
        return { projectId: project.id, paused: true, resumable: true, session: await projects.readMetadata(project, 'upgrade-session.json', {}), brief: 'Upgrade remains paused and resumable. Verified work was preserved.' };
      }
      const currentSession = await projects.readMetadata(project, 'upgrade-session.json', {});
      await projects.saveMetadata(project, 'upgrade-session.json', { ...currentSession, status: 'paused', resumable: true, phase: currentSession?.phase === 'apply' ? 'plan' : (currentSession?.phase || 'plan'), currentStep: currentSession?.phase === 'apply' ? 'diagnose' : (currentSession?.currentStep || 'diagnose'), lastError: { code: String(err.code || 'UPGRADE_PAUSED'), message: String(err.message || err).slice(0, 1200), at: new Date().toISOString() }, updatedAt: new Date().toISOString() });
      projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
      throw err;
    }
  });

  jobs.on('upgrade_apply', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    projects.setStatus(project, 'UPGRADING');
    let plan = job.payload.plan || await projects.readMetadata(project, 'upgrade-plan.json', {});
    if (!planHasFileChanges(plan)) {
      const resolved = await resolveEmptyUpgradePlan({
        project: projects.get(project.id), projects, ai, plan,
        request: job.payload.request || plan.request || '', emit,
        replanCount: Number(plan.replanCount || 0),
      });
      projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
      if (resolved.noChange) {
        return { ...resolved, files: [], brief: resolved.brief || 'No code changes were required.' };
      }
      plan = resolved.plan;
    }
    emit('patch', 'running', 'Applying the saved Upgrade plan…');
    const result = await applyUpgrade({ project: projects.get(project.id), projects, snapshots, plan, request: job.payload.request || plan.request || '', approved: job.payload.approved === true });
    projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
    emit('verify', 'done', `Upgrade verified. ${result.files.length} file(s) changed. Ready for release or rollback.`);
    return result;
  });

  jobs.on('create_app', async (job, { emit }) => {
    const idea = String(job.payload.idea || '').trim();
    if (!idea) throw new Error('Describe your idea first.');
    const userLanguage = detectUserLanguage(idea);

    emit('analyze', 'running', 'Understanding your idea…');
    let analysis;
    const incomingFiles = Array.isArray(job._files) ? job._files : [];
    try {
      const attachmentSummary = incomingFiles.map((f) => ({ name: f.originalname, type: f.mimetype, bytes: f.buffer?.length || 0 }));
      const r = await ai.completeJson({ task: 'IDEA_ANALYSIS', system: SYSTEM, prompt: ideaPrompt(idea, attachmentSummary), images: imageInputs(incomingFiles) });
      analysis = r.json;
    } catch (err) {
      log.warn('Idea analysis fell back to local defaults', { error: err.message });
      analysis = localAnalysis(idea);
      analysis.fallbackReason = friendlyAiError(err);
      if (hasConfiguredAi(ai, cfg)) {
        emit('analyze', 'done', 'AI analysis did not complete. Builder will not treat a name-only fallback as a finished product.');
      } else {
        emit('analyze', 'done', 'No AI key — using a minimal local outline. Add an AI key in Settings for a full app.');
      }
    }

    emit('plan', 'running', 'Preparing a simple plan…');
    let plan;
    try {
      const attachmentSummary = incomingFiles.map((f) => ({ name: f.originalname, type: f.mimetype, bytes: f.buffer?.length || 0 }));
      const r = await ai.completeJson({ task: 'PRODUCT_PLANNING', system: SYSTEM, prompt: planPrompt(idea, analysis, JSON.stringify(attachmentSummary)), images: imageInputs(incomingFiles) });
      plan = r.json;
    } catch (err) {
      plan = localPlan(idea, analysis);
      plan.fallbackReason = friendlyAiError(err);
      if (hasConfiguredAi(ai, cfg)) {
        emit('plan', 'done', 'AI planning did not complete. Code generation will still run with your key; a thin template is not accepted as done.');
      }
    }
    plan = enrichPlan(plan, analysis, idea);
    const planInfo = planCompleteness(plan);
    emit('plan', 'done', planInfo.summary);

    const project = await projects.create({
      idea,
      name: plan.name || analysis.name,
      analysis,
      plan,
    });
    for (const file of incomingFiles.slice(0, 8)) {
      if (file?.buffer) await saveAttachment(projects.projectDir(project), file);
    }
    await projects.chat(project, idea, 'user', { attachments: incomingFiles.map((f) => f.originalname).filter(Boolean) });
    analysis.questions = normalizeQuestions(analysis.questions);
    await projects.saveMetadata(project, 'requirements.json', analysis);
    await projects.saveMetadata(project, 'architecture.json', plan);
    await projects.saveMetadata(project, 'user-language.json', { language: userLanguage, source: idea });
    jobs.attachProject(job.id, project.id);
    const initialPlan = await projects.startWorkPlan(project, {
      jobId: job.id,
      message: idea,
      action: 'create_app',
      language: userLanguage,
      steps: [
        { action: 'analyze', goal: 'Understand the idea, constraints, and required features.' },
        { action: 'plan', goal: 'Choose the smallest safe architecture and verification plan.' },
        { action: 'build', goal: 'Generate the first complete application without secrets.' },
        { action: 'test', goal: 'Run static checks, security scan, preview, and browser verification.' },
      ],
    });
    await projects.updateWorkPlan(project, { stepId: initialPlan.steps[0].id, step: { status: 'done', result: 'Requirements analyzed.' } });
    await projects.updateWorkPlan(project, { stepId: initialPlan.steps[1].id, step: { status: 'done', result: 'Architecture and product plan saved.' } });
    emit('plan', 'done', 'Job plan saved. Every build step will report what changed and what remains.');

    if (job.payload.autoBuild && analysis.questions.length && !job.payload.demo) {
      projects.setStatus(project, 'WAITING_INPUT');
      await projects.chat(project, 'I need a few quick choices before I build this.', 'assistant', { questions: analysis.questions, fixedTemplate: true });
      await projects.finishWorkPlan(project, 'waiting_input', 'Waiting for the user choices before build can continue.');
      emit('questions', 'done', 'I need a few quick choices before I build this.');
      return { projectId: project.id, analysis, plan, needsInput: true, questions: analysis.questions };
    }

    projects.setStatus(project, 'READY_TO_BUILD');
    try {
      const createTaskCtx = createTaskContext({
        taskType: 'CREATE',
        originalRequest: idea,
        projectId: project.id,
        projectSlug: project.slug,
        protectedFiles: ['Dockerfile', 'docker-compose.yml', 'config_options.yml'],
        executionPlan: ['template-or-generate', 'customize', 'verify'],
      });
      enterTaskContext(createTaskCtx);
      await projects.saveMetadata(project, 'task-context.json', {
        sessionId: createTaskCtx.sessionId,
        taskType: 'CREATE',
        originalRequest: String(idea || '').slice(0, 2000),
        status: 'active',
        currentStage: 'analyze',
      }).catch(() => {});
      appendTaskEvent({ type: 'task_start', summary: String(idea || '').slice(0, 240) });
    } catch { /* non-fatal */ }


    // Template-first (default ON): ALWAYS a real professional template — never demo/sandbox.
    const preferTemplate = job.payload.preferTemplate !== false && job.payload.useTemplateLibrary !== false;
    if (job.payload.autoBuild && preferTemplate) {
      try {
        emit('template', 'running', 'Selecting a real SoloHost template (professional UI; demos blocked)…');
        const selection = await selectRealTemplate(cfg.templatesDir, idea, {
          preferredId: job.payload.templateId || null,
          limit: 12,
          requireNetworkForThin: true,
        });
        await projects.saveMetadata(project, 'template-match.json', {
          ...(selection.match || {}),
          realSelection: {
            templateId: selection.templateId,
            reason: selection.reason,
            network: selection.network,
          },
        });
        const tid = selection.templateId;
        if (!tid || isDemoTemplate(selection.template)) {
          const msg = 'No real professional template matched. Template mode is ON — demos and AI-only scaffolds are blocked.';
          emit('template', 'failed', msg);
          await projects.finishWorkPlan(project, 'failed', msg).catch(() => {});
          await projects.chat(project, `${msg}\n${selection.reason || ''}\nTurn Templates off only if you want pure AI generation.`, 'assistant', { templateRequired: true });
          return { projectId: project.id, failed: true, code: 'TEMPLATE_REQUIRED' };
        }

        const filled = await fillProjectFromTemplate({
          templatesDir: cfg.templatesDir,
          project: projects.get(project.id),
          projects,
          templateId: tid,
          idea,
        });
        if (!filled.ok) {
          throw Object.assign(new Error(filled.message || 'Template fill failed'), { code: filled.code || 'TEMPLATE_FILL_FAILED' });
        }

        await stampMadeBy(projects.sourceDir(project.slug), cfg).catch(() => {});
        await writeGithubWorkflow(projects.sourceDir(project.slug), project).catch(() => {});
        if (snapshots?.create) await snapshots.create(project, 'after-template-instantiate').catch(() => {});
        emit(
          'template',
          'done',
          `Real template «${filled.templateId}» (${filled.files.length} files${filled.fetched ? ', upstream fetched' : ''}). Quality init…`,
        );

        const loopResult = await runInitQualityLoop({
          project: projects.get(project.id),
          projects,
          idea,
          templateId: filled.templateId,
          emit,
          improveProject,
          testAndMaybeFix,
          hasAi: hasConfiguredAi(ai, cfg),
        });
        await projects.saveMetadata(project, 'init-quality-loop.json', loopResult).catch(() => {});

        const depth = await evaluateProductDepth(projects.sourceDir(project.slug), {
          name: project.name || plan?.name || analysis?.name,
          idea,
        });
        await projects.saveMetadata(project, 'product-checklist.json', depth).catch(() => {});

        // The final on-disk assessment is authoritative. Never let a stale/intermediate
        // loop result override a failing final checklist.
        if (!depth.ok) {
          const blocked = [
            `Created from real template «${filled.templateId}», but the product quality gate did not pass.`,
            depth.summary,
            `Improvement loop: ${loopResult.roundsRun || 0}/${loopResult.maxRounds || 0} rounds; ${loopResult.blockedReason || 'quality requirements remain unmet'}.`,
            'The project is preserved for further improvement. It is not reported as a finished/verified product.',
          ].join('\n');
          emit('quality_gate', 'failed', blocked);
          projects.setStatus(project, 'FAILED');
          await projects.chat(project, blocked, 'assistant', {
            templateId: filled.templateId, realTemplate: true, productChecklist: depth,
            initQuality: loopResult, qualityBlocked: true,
          });
          await projects.finishWorkPlan(project, 'failed', `Quality gate failed: ${depth.score}/100`).catch(() => {});
          return {
            projectId: project.id, analysis, plan, templateId: filled.templateId,
            realTemplate: true, failed: true, code: 'PRODUCT_QUALITY_GATE_FAILED',
            productChecklist: depth, initQuality: loopResult,
          };
        }

        projects.setStatus(project, 'READY');
        const gate = 'First-run UI passed the product quality gate. Run the main workflow and complete runtime verification before publishing.';
        await projects.chat(
          project,
          [
            `Created from real template «${filled.templateId}» (demos blocked).`,
            selection.reason || '',
            selection.network ? 'Network available for thin upstream fetch when needed.' : 'Offline — used complete SoloHost std template.',
            depth.summary,
            gate,
            'Next: ▶ Run → use the main workflow → verify → 🚀 Publish.',
          ].filter(Boolean).join('\n'),
          'assistant',
          { templateId: filled.templateId, realTemplate: true, productChecklist: depth, initQuality: loopResult },
        );
        await projects.finishWorkPlan(project, 'done', `Real template ${filled.templateId}; product score ${depth.score}/100`).catch(() => {});
        return {
          projectId: project.id,
          analysis,
          plan,
          templateId: filled.templateId,
          realTemplate: true,
          productChecklist: depth,
          initQuality: loopResult,
        };
      } catch (err) {
        log.warn('Template-first path failed; strict template mode prevents fallback', { error: err.message });
        emit('template', 'failed', `Template creation failed: ${err.message}. Template mode is ON; no demo/AI-only fallback was used.`);
        await projects.finishWorkPlan(project, 'failed', 'Template creation failed; fallback intentionally blocked.').catch(() => {});
        await projects.chat(project, `Template creation failed, and template mode is ON. I stopped without substituting a demo or AI-only scaffold.
${String(err.message || err).slice(0, 700)}
Retry after fixing the template source or turn template mode off.`, 'assistant', { templateRequired: true, templateError: String(err.message || err) });
        return { projectId: project.id, failed: true, code: err.code || 'TEMPLATE_CREATE_FAILED' };
      }
    }


    if (job.payload.autoBuild) {
      await projects.updateWorkPlan(project, { stepId: initialPlan.steps[2].id, step: { status: 'running' } });
      emit('generate', 'running', 'Writing the first version…');
      try {
        const built = await generateCode({ project: projects.get(project.id), analysis, plan, emit, allowFallback: Boolean(job.payload.demo) });
        const fresh = projects.get(project.id);
        const depth = await evaluateProductDepth(projects.sourceDir(fresh.slug), {
          name: fresh.name || plan?.name || analysis?.name,
          idea,
        });
        await projects.saveMetadata(fresh, 'product-checklist.json', depth);
        const localShell = (isLocalDefaults(analysis) || isLocalDefaults(plan) || built?.fallback) && hasConfiguredAi(ai, cfg) && !job.payload.demo;
        if (localShell || !depth.ok) {
          const msg = [
            depth.summary,
            localShell ? 'AI was configured but planning/code fell back to a minimal shell — that is not a finished product.' : '',
            'Next: open Settings and confirm the AI key works (Test), then ask in chat to expand the app (screens, main actions, save data), or tap Improve with a clearer product goal.',
          ].filter(Boolean).join(' ');
          emit('generate', 'failed', msg);
          await projects.updateWorkPlan(project, { stepId: initialPlan.steps[2].id, step: { status: 'failed', error: msg.slice(0, 1000) } });
          await projects.finishWorkPlan(project, 'failed', 'Build stopped: product checklist did not pass.');
          await projects.chat(fresh, msg, 'assistant', { productChecklist: depth, fixedTemplate: true });
          throw Object.assign(new Error(msg), { code: 'PRODUCT_TOO_THIN', checklist: depth });
        }
        emit('generate', 'done', depth.summary);
        await projects.updateWorkPlan(project, { stepId: initialPlan.steps[2].id, step: { status: 'done', result: 'Application files generated.' } });
        await projects.updateWorkPlan(project, { stepId: initialPlan.steps[3].id, step: { status: 'done', result: 'Initial checks and preview completed.' } });
        await projects.finishWorkPlan(project, 'done', 'Initial app build and verification are recorded. Future changes must use a new plan step.');
      } catch (err) {
        await projects.updateWorkPlan(project, { stepId: initialPlan.steps[2].id, step: { status: 'failed', error: String(err.message || err).slice(0, 1000) } });
        await projects.finishWorkPlan(project, 'failed', 'Initial build stopped safely. No unverified build is reported as complete.');
        throw err;
      }
    } else {
      await projects.finishWorkPlan(project, 'waiting_input', 'Plan is ready. Start Build when you want the app files generated.');
    }

    return { projectId: project.id, analysis, plan };
  });

  jobs.on('continue_build', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    const analysis = await projects.readMetadata(project, 'requirements.json', {});
    const plan = await projects.readMetadata(project, 'architecture.json', {});
    const answers = job.payload.answers || {};
    analysis.answers = answers;
    analysis.questions = normalizeQuestions(analysis.questions);
    await projects.saveMetadata(project, 'requirements.json', analysis);
    emit('plan', 'running', 'Updating the plan from your choices…');
    let nextPlan = plan;
    try {
      const r = await ai.completeJson({ task: 'PRODUCT_PLANNING', system: SYSTEM, prompt: planPrompt(`${project.idea}\nUser choices: ${JSON.stringify(answers)}`, analysis), projectId: project.id });
      nextPlan = r.json;
    } catch (err) {
      log.warn('Plan refresh fell back to saved plan', { error: err.message });
    }
    await projects.saveMetadata(project, 'architecture.json', nextPlan);
    projects.setStatus(project, 'READY_TO_BUILD');
    const workPlan = await projects.startWorkPlan(project, {
      jobId: job.id,
      message: `Continue build with choices: ${JSON.stringify(answers)}`,
      action: 'continue_build',
      language: detectUserLanguage(project.idea),
      steps: [{ action: 'build', goal: 'Generate the app using the saved choices.' }, { action: 'test', goal: 'Verify the generated app and preview.' }],
    });
    await projects.updateWorkPlan(project, { stepId: workPlan.steps[0].id, step: { status: 'running' } });
    try {
      const result = await generateCode({ project: projects.get(project.id), analysis, plan: nextPlan, emit, allowFallback: false });
      await projects.updateWorkPlan(project, { stepId: workPlan.steps[0].id, step: { status: 'done', result: 'Application files generated.' } });
      const previewFailed = result.tested?.dockerBuild?.status === 'failed';
      const nodeFailed = result.tested?.nodeResult?.status === 'failed';
      const scanBlocked = (result.tested?.scan?.critical || 0) > 0;
      const step2Ok = !previewFailed && !nodeFailed && !scanBlocked;
      await projects.updateWorkPlan(project, {
        stepId: workPlan.steps[1].id,
        step: {
          status: step2Ok ? 'done' : 'failed',
          result: step2Ok ? 'Initial checks and preview passed.' : String(result.tested?.dockerBuild?.error || result.tested?.nodeResult?.error || 'Verification failed.').slice(0, 500),
          ...(step2Ok ? {} : { error: String(result.tested?.dockerBuild?.error || result.tested?.nodeResult?.error || 'Preview or tests failed.').slice(0, 500) }),
        },
      });
      const finished = await projects.finishWorkPlan(project, step2Ok ? 'done' : 'failed', step2Ok
        ? 'Build resumed from the saved plan and was verified.'
        : 'Files generated, but verification reported a failure.');
      return { ...result, workPlan: finished };
    } catch (err) {
      await projects.updateWorkPlan(project, { stepId: workPlan.steps[0].id, step: { status: 'failed', error: String(err.message || err).slice(0, 1000) } });
      await projects.finishWorkPlan(project, 'failed', 'Build stopped safely; no unverified result is reported as complete.');
      throw err;
    }
  });

  jobs.on('build', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    const analysis = await projects.readMetadata(project, 'requirements.json', {});
    const plan = await projects.readMetadata(project, 'architecture.json', {});
    const workPlan = await projects.startWorkPlan(project, {
      jobId: job.id,
      message: 'Build the saved project plan.',
      action: 'build',
      language: detectUserLanguage(project.idea),
      steps: [{ action: 'build', goal: 'Generate or update the application files from the saved plan.' }, { action: 'test', goal: 'Verify the build, security, preview, and browser flow.' }],
    });
    await projects.updateWorkPlan(project, { stepId: workPlan.steps[0].id, step: { status: 'running' } });
    try {
      const result = await generateCode({ project, analysis, plan, emit, allowFallback: false });
      await projects.updateWorkPlan(project, { stepId: workPlan.steps[0].id, step: { status: 'done', result: 'Application files generated.' } });
      const previewFailed = result.tested?.dockerBuild?.status === 'failed';
      const nodeFailed = result.tested?.nodeResult?.status === 'failed';
      const scanBlocked = (result.tested?.scan?.critical || 0) > 0;
      const step2Ok = !previewFailed && !nodeFailed && !scanBlocked;
      await projects.updateWorkPlan(project, {
        stepId: workPlan.steps[1].id,
        step: {
          status: step2Ok ? 'done' : 'failed',
          result: step2Ok ? 'Checks and preview passed.' : String(result.tested?.dockerBuild?.error || result.tested?.nodeResult?.error || 'Verification failed.').slice(0, 500),
          ...(step2Ok ? {} : { error: String(result.tested?.dockerBuild?.error || result.tested?.nodeResult?.error || 'Preview or tests failed.').slice(0, 500) }),
        },
      });
      const finished = await projects.finishWorkPlan(project, step2Ok ? 'done' : 'failed', step2Ok
        ? 'Build and verification were recorded.'
        : 'Files generated, but runtime or browser verification needs attention.');
      return { ...result, workPlan: finished };
    } catch (err) {
      await projects.updateWorkPlan(project, { stepId: workPlan.steps[0].id, step: { status: 'failed', error: String(err.message || err).slice(0, 1000) } });
      await projects.finishWorkPlan(project, 'failed', 'Build stopped safely; no unverified result is reported as complete.');
      throw err;
    }
  });

  jobs.on('test', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    return testAndMaybeFix(project, emit);
  });

  jobs.on('analyze', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    emit('analyze', 'running', 'Checking files, tests, Docker build, and security…');
    const source = projects.sourceDir(project.slug);
    const diagnosis = await diagnoseSource(source);
    if (!diagnosis.files.length) {
      return {
        action: 'analyze',
        ok: false,
        diagnosis,
        brief: 'Check is locked. There is no app yet. Tap Build first.',
        next: 'Tap ✨ Build, then Check again.',
      };
    }
    const tested = await testAndMaybeFix(project, emit);
    const runtime = await projects.readMetadata(project, 'runtime.json', {});
    const brief = [
      tested.scan?.critical ? 'Security issues were found.' : 'Security scan is clean.',
      tested.staticResult?.status === 'passed' ? 'Required files look complete.' : 'Some required files are missing.',
      tested.dockerBuild?.status === 'passed' ? 'Docker build passed.' : `Docker build: ${tested.dockerBuild?.error || tested.dockerBuild?.reason || tested.dockerBuild?.status || 'not run'}.`,
      runtime.status === 'passed' ? 'A preview has already run.' : 'Tap ▶ Run to open a live preview.',
    ].join(' ');
    return {
      action: 'analyze',
      ok: tested.scan?.critical === 0 && tested.staticResult?.status === 'passed',
      tested,
      diagnosis,
      brief,
      next: tested.scan?.critical ? 'Tap Improve so I can remove the unsafe setting.' : (runtime.status === 'passed' ? 'If the preview looks right, tap Publish.' : 'Tap ▶ Run next.'),
    };
  });

  jobs.on('security', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    emit('security', 'running', 'Checking for secrets and unsafe settings…');
    projects.setStatus(project, 'SECURITY_CHECK');
    const scan = await scanProject(projects.sourceDir(project.slug));
    await projects.saveMetadata(project, 'security.json', scan);
    if (scan.status === 'BLOCK') projects.setStatus(project, 'FAILED');
    else projects.setStatus(project, 'WAITING_APPROVAL');
    return scan;
  });

  jobs.on('run', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    const importOrigin = await isImportOrUpgradeOrigin(project);
    const sourcePath = projects.sourceDir(project.slug);
    const profile = await detectAppProfile(sourcePath).catch(() => null);
    if (profile?.preferPublish) {
      emit('run', 'running', profile.guidance?.en || 'Heavy framework/container app — preview may be limited; Publish is the reliable path.');
      await projects.saveMetadata(project, 'app-profile.json', { ...profile, detectedAt: new Date().toISOString() });
    }
    emit('run', 'running', 'Starting a safe local preview…');
    // Never park Upgrade apps in BUILDING (that felt like a locked step).
    if (!importOrigin) projects.setStatus(project, 'BUILDING');
    else projects.setStatus(project, 'UPGRADE_READY');
    let result = await runner.runApp({ sourcePath, projectSlug: project.slug, timeout: cfg.limits.sandboxTimeoutSec, keepRunning: true });
    // Upgrade/Import or heavy framework apps: never run DARE recovery on preview failure.
    if (result.status !== 'passed' && !importOrigin && !profile?.preferPublish) {
      emit('run', 'running', '🔧 Recovering…');
      const history = await projects.readMetadata(project, 'dare-history.json', []);
      const dare = await runDare({
        sourceDir: sourcePath,
        logs: `${result.error || ''}\n${result.logs || ''}`,
        extra: { message: 'RUN_RECOVERY' },
        history: Array.isArray(history) ? history : [],
      });
      await projects.saveMetadata(project, 'dare-history.json', (dare.history || []).slice(-20));
      if (dare.ok && (dare.changed || []).length && !dare.stopped) {
        emit('run', 'running', '✅ Fixed — Continuing…');
        result = await runner.runApp({ sourcePath, projectSlug: project.slug, timeout: cfg.limits.sandboxTimeoutSec, keepRunning: true });
      }
    }
    const publicBase = String(process.env.PREVIEW_PUBLIC_BASE_URL || '').replace(/\/$/, '');
    const publicUiUrl = publicBase ? `${publicBase}/preview/${encodeURIComponent(project.slug)}/` : `/preview/${encodeURIComponent(project.slug)}/`;
    const runtime = { ...result, image: null, imageFile: null, publicUiUrl, lastSeenAt: new Date().toISOString(), nextSteps: result.status === 'passed' ? ['Open the preview', 'Improve with AI if needed', 'Publish when ready'] : ['Fix the reported issue', 'Run again'], updatedAt: new Date().toISOString() };
    await projects.saveMetadata(project, 'runtime.json', runtime);
    const tests = await projects.readMetadata(project, 'test-plan.json', {});
    const previewPassed = result.status === 'passed' && result.health === true;
    const refreshedTests = {
      ...tests,
      preview: result,
      e2e: result.e2e || null,
      verifiedAt: new Date().toISOString(),
    };
    if (previewPassed) {
      // Live preview + health is the source of truth for SoloHost readiness.
      // Stale npm-test failures (wrong PORT, fork timing) must not block Publish.
      refreshedTests.nodeResult = {
        status: 'passed',
        runner: 'preview-health',
        superseded: tests.nodeResult?.status === 'failed' ? tests.nodeResult : null,
        reason: 'Preview health and browser checks passed; those replace the earlier local npm test report.',
      };
    }
    await projects.saveMetadata(project, 'test-plan.json', refreshedTests);
    if (result.status === 'passed') {
      projects.setStatus(project, 'WAITING_APPROVAL');
      emit('run', 'done', runtime.internet?.ok === true ? '✓ Preview started; health, browser, and Internet checks passed.' : '✓ Preview started and browser check passed. Internet browsing is not yet verified.');
    } else if (importOrigin || profile?.preferPublish) {
      // Import/Upgrade or heavy framework apps: never lock FAILED + diagnose.
      projects.setStatus(project, importOrigin ? 'UPGRADE_READY' : 'WAITING_APPROVAL');
      const soft = [
        importOrigin
          ? 'Preview did not start for this imported/Upgrade app.'
          : 'Preview did not start for this framework/container app.',
        profile?.guidance?.en || 'Builder preview is limited for Vite/React/Docker-build apps.',
        'Scan, DARE, and auto-diagnosis are skipped here — use Publish → GHCR → SoloHost for a real run.',
        result.warning || result.error || result.message || '',
        'Next: Publish, or Improve only if you want source changes. Upgrade flow stays open (not blocked).',
      ].filter(Boolean).join('\n');
      emit('run', 'done', soft);
      return {
        ...runtime,
        status: 'preview_limited',
        importSkippedChecks: Boolean(importOrigin),
        appProfile: profile || null,
        downloads: [],
        ui_url: publicUiUrl,
        next: 'Publish to SoloHost. Preview is optional for framework apps.',
      };
    } else {
      projects.setStatus(project, 'FAILED');
      const message = result.error || 'The app could not start or pass browser testing.';
      emit('run', 'failed', message);
      emit('diagnose', 'running', '⚠️ Problem detected. Investigating…');
      try {
        const report = await diagnoseProject({ project, projects, db: app.db, logs: [result.error, result.logs, message].filter(Boolean).join('\n') });
        await refreshProjectBrain({ project, projects, db: app.db, extra: { notes: report.rootCause } });
        const brief = formatUserDiagnosis(report);
        emit('diagnose', 'done', brief);
        const err = new Error(brief);
        err.diagnosis = report;
        throw err;
      } catch (diagErr) {
        if (diagErr.diagnosis) throw diagErr;
        throw new Error(message);
      }
    }
    return { ...runtime, downloads: [], ui_url: publicUiUrl, next: 'Open the test link, improve if needed, then Publish.' };
  });

  jobs.on('stop', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    emit('stop', 'running', 'Stopping the preview…');
    const result = await runner.stopApp({ projectSlug: project.slug });
    await projects.saveMetadata(project, 'runtime.json', { status: 'stopped', stoppedAt: new Date().toISOString(), ...result });
    if (project.status !== 'RELEASED') projects.setStatus(project, 'WAITING_APPROVAL');
    return result;
  });

  jobs.on('improve', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    const feedback = String(job.payload.feedback || '').trim();
    if (!feedback) throw new Error('Tell AI what to improve.');
    const incomingFiles = Array.isArray(job._files) ? job._files : [];
    for (const file of incomingFiles.slice(0, 8)) {
      if (file?.buffer) await saveAttachment(projects.projectDir(project), file);
    }
    if (incomingFiles.length) {
      await projects.chat(project, `📎 Attached ${incomingFiles.length} file(s) for this repair.`, 'system', {
        attachments: incomingFiles.map((file) => file.originalname).filter(Boolean),
      });
    }
    const language = detectUserLanguage(feedback);
    const priorRuntime = await projects.readMetadata(project, 'runtime.json', null);
    const orchPlan = await orchestrator.generatePlan({
      jobId: job.id,
      project,
      feedback,
      language,
      runtime: priorRuntime,
    });
    const plan = await projects.startWorkPlan(project, {
      jobId: job.id,
      message: feedback,
      action: 'improve',
      language,
      steps: [{ action: 'improve', goal: feedback, tests: ['static checks', 'runtime tests', 'security scan', 'preview'] }],
    });
    emit('plan', 'done', formatPlanChecklistText(orchPlan));
    await projects.updateWorkPlan(project, { stepId: plan.steps[0].id, step: { status: 'running' } });
    emit('ai', 'running', language === 'Vietnamese' ? 'Agent Orchestrator đang thực hiện kế hoạch sửa lỗi…' : 'Agent Orchestrator is executing the bug-fix plan…');
    try {
      const result = await improveProject(project, feedback, emit, { orchestratorPlan: orchPlan });
      if (result.tested) {
        const previousTests = await projects.readMetadata(project, 'test-plan.json', {});
        await projects.saveMetadata(project, 'test-plan.json', mergeVerificationState(previousTests, result.tested));
      }
      if (result.runtime?.status === 'passed' || (result.tested?.staticResult?.status === 'passed' && result.tested?.nodeResult?.status !== 'failed' && result.tested?.scan?.critical === 0)) {
        await projects.saveMetadata(project, 'action-guard.json', null);
      }
      if ((result.files || []).length) {
        const pendingRelease = await projects.readMetadata(project, 'release-pending.json', null);
        if (pendingRelease && typeof pendingRelease === 'object') {
          await projects.saveMetadata(project, 'release-pending.json', {
            ...pendingRelease,
            status: 'needs_republish',
            localChangedAt: new Date().toISOString(),
          });
        }
      }
      // 1.8.9: the plan and the "next" hint must agree with the REAL outcome (rolled back / no change / needs action
      // must never be recorded as "Change verified" or tell the user to Publish).
      const outcome = result.outcome || ((result.files || []).length ? OUTCOMES.DONE : OUTCOMES.NO_CHANGE);
      const applied = outcome === OUTCOMES.DONE || outcome === OUTCOMES.PARTIAL;
      const stepOk = applied || outcome === OUTCOMES.NO_CHANGE;
      await orchestrator.finalize(project, orchPlan, {
        outcome,
        verified: applied && result.runtime?.status === 'passed',
        summary: applied
          ? (result.explanation || (language === 'Vietnamese' ? 'Đã sửa và kiểm chứng chạy thử.' : 'Patched and verified in live preview.'))
          : String(result.brief || result.explanation || outcome).slice(0, 220),
      });
      await projects.updateWorkPlan(project, {
        stepId: plan.steps[0].id,
        step: {
          status: stepOk ? 'done' : 'failed',
          files: result.files || [],
          result: applied ? (result.explanation || 'Change verified.') : String(result.brief || result.explanation || outcome).slice(0, 600),
          ...(stepOk ? {} : { error: String(result.brief || outcome).slice(0, 600) }),
        },
        reports: [{ action: 'improve', status: stepOk ? 'done' : 'failed', outcome, files: result.files || [], explanation: result.explanation || '' }],
      });
      const finished = await projects.finishWorkPlan(project, stepOk ? 'done' : 'failed', applied
        ? 'Change was checked after the patch. The checkpoint remains available for rollback.'
        : 'No change was kept. The previous working state is intact.');
      return {
        ...result,
        outcome,
        workPlan: finished,
        orchestratorPlan: orchPlan,
        acceptance: result.acceptance || null,
        alternatives: result.alternatives || null,
        next: applied
          ? (localeOf(language) === 'vi'
            ? (result.outcomeInfo?.next || '')
            : (result.next || 'Tap ▶ Run to verify the repair, then tap 🚀 Publish. Publish uploads the repaired files (overwrite). Do not use Re-check until the new source is on GitHub.'))
          : (result.outcomeInfo?.next || result.alternatives?.items?.[0]?.title || ''),
      };
    } catch (err) {
      await orchestrator.finalize(project, orchPlan, {
        outcome: 'FAILED',
        verified: false,
        summary: String(err.message || err).slice(0, 220),
      });
      await projects.updateWorkPlan(project, {
        stepId: plan.steps[0].id,
        step: { status: 'failed', error: String(err.message || err).slice(0, 1000), notes: ['No unverified change is reported as complete.'] },
        reports: [{ action: 'improve', status: 'failed', error: String(err.message || err).slice(0, 1000) }],
      });
      await projects.finishWorkPlan(project, 'failed', 'The step stopped safely. Review the error and the saved checkpoint before continuing.');
      throw err;
    }
  });

  jobs.on('sandbox', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    emit('sandbox', 'running', 'Trying the app in a temporary box…');
    projects.setStatus(project, 'SANDBOX');
    const result = await sandbox.run({
      project,
      sourcePath: projects.sourceDir(project.slug),
      jobId: job.id,
    });
    if (result.status === 'passed') projects.setStatus(project, 'WAITING_APPROVAL');
    return result;
  });

  jobs.on('github', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    if (!github.configured()) {
      throw new Error('GITHUB_TOKEN_REQUIRED: Add your GitHub username and token in Settings → GitHub before Publish. No files were uploaded.');
    }
    emit('github', 'running', 'Publishing to GitHub…');
    const pushed = await publishToGitHub({
      upgradeOrigin: typeof upgradeOrigin !== 'undefined' && Boolean(upgradeOrigin),
      github,
      project,
      sourceDir: projects.sourceDir(project.slug),
      version: project.version,
      emit,
    });
    await projects.saveMetadata(project, 'release.json', { github: pushed });
    if (!pushed.ok) throw new Error([pushed.error, pushed.fix].filter(Boolean).join('\n\n'));
    return pushed;
  });

  async function runRelease(project, payload, emit) {
    const originMeta = await projects.readMetadata(project, 'origin.json', {});
    const upgradeMeta = await projects.readMetadata(project, 'upgrade-origin.json', null);
    const upgradeOrigin = Boolean(
      originMeta?.origin === 'upgrade'
      || originMeta?.origin === 'import'
      || originMeta?.policy === 'import-skip-checks'
      || originMeta?.policy === 'accept-external-source-no-auto-repair'
      || upgradeMeta?.origin === 'upgrade'
      || await isImportOrUpgradeOrigin(project)
    );
    emit('validate', 'running', upgradeOrigin
      ? '✓ Upgrade-origin release — synchronizing deployment artifacts without application repair…'
      : '✓ App generated — validating project files…');
    const tests = await projects.readMetadata(project, 'test-plan.json', {});
    const source = projects.sourceDir(project.slug);
    let security = await projects.readMetadata(project, 'security.json', {});
    let runtime = await projects.readMetadata(project, 'runtime.json', {});

    if (payload.approved !== true && payload.confirm !== true) throw new Error('Release blocked: approve the tested app first.');

    if (!upgradeOrigin) {
      security = await scanProject(source);
      await projects.saveMetadata(project, 'security.json', security);
      if (security.critical > 0) {
        const report = security.copy_for_ai || 'APP BUILDER SECURITY REPORT\nNo detailed report was generated.';
        emit('security', 'failed', `${security.summary}\n\n${report}`);
        throw new Error(`RELEASE_SECURITY_BLOCKED\n${security.summary}\n\n${report}\n\nNEXT: Tap Improve and let the AI apply the smallest targeted security fix, then Run and Publish again.`);
      }
      if (runtime.status !== 'passed' || runtime.health !== true) throw new Error('Release blocked: run the app successfully before publishing. Tap Run first.');
    } else {
      // Upgrade/Import: Publish does not require live Run. Preview is optional.
      runtime = { ...runtime, status: 'passed', health: true, source: 'upgrade-import-baseline' };
      await projects.saveMetadata(project, 'runtime.json', { ...runtime, updatedAt: new Date().toISOString() });
      emit('validate', 'done', '✓ Upgrade/Import publish — live Run not required. Deployment package synchronization remains required.');
    }

    // Hard gate: never continue Publish without GitHub credentials
    const wantsPush = payload.push !== false && payload.verifyImage !== true;
    if (wantsPush && !github.configured()) {
      throw new Error('GITHUB_TOKEN_REQUIRED: GitHub username and token are required before Publish. Open Settings → enter GitHub owner + token → Save, then Publish again.');
    }
    if (!github.configured() && payload.verifyImage === true) {
      throw new Error('GITHUB_TOKEN_REQUIRED: GitHub token is required to check the published image. Add it in Settings first.');
    }

    const pendingEarly = await projects.readMetadata(project, 'release-pending.json', null);
    // Check image / Re-check only. A normal Publish tap always uploads local source.
    const verifyOnlyEarly = Boolean(pendingEarly?.githubUrl)
      && payload.existingAction !== 'overwrite'
      && payload.forcePublish !== true
      && (payload.verifyImage === true || payload.recheck === true);

    // SoloHost runtime contract preflight runs before the first GitHub publication.
    // Check-image / re-check must not re-apply the same Dockerfile contract or the
    // user gets a repair loop while GitHub Actions is still building.
    let releaseDare = { ok: false, stopped: false, alreadyFixed: false };
    if (!upgradeOrigin && !verifyOnlyEarly) {
      const releaseDareHistory = await projects.readMetadata(project, 'dare-history.json', []);
      const releaseDareCheckpoint = await snapshots.create(project, 'before-release-runtime-preflight').catch(() => null);
      releaseDare = await runDare({
        sourceDir: source,
        logs: `${runtime.error || ''}\n${runtime.logs || ''}`,
        extra: { message: 'SOLOHOST_RELEASE_PREFLIGHT' },
        history: Array.isArray(releaseDareHistory) ? releaseDareHistory : [],
      });
      await projects.saveMetadata(project, 'dare-history.json', (releaseDare.history || []).slice(-20));
      if (releaseDare.ok && (releaseDare.changed || []).length) {
        emit('validate', 'running', `SoloHost runtime preflight repaired ${releaseDare.files.join(', ') || 'the runtime contract'}; rechecking before publish…`);
        const preflightStatic = await runStaticTests(source);
        const preflightNode = await runNodeTests(source, 45000);
        const preflightScan = await scanProject(source);
        if (preflightStatic.status === 'failed' || preflightNode.status === 'failed' || preflightScan.critical > 0) {
          if (releaseDareCheckpoint?.id) await snapshots.restore(project, releaseDareCheckpoint.id).catch(() => {});
          throw new Error(`RELEASE_RUNTIME_PREFLIGHT_FAILED\n${formatDareReport(releaseDare)}\nThe deterministic repair did not pass local verification, so the previous state was restored.`);
        }
        emit('validate', 'done', `✓ SoloHost runtime preflight passed after ${releaseDare.ruleId || 'deterministic'} repair.`);
      } else if (releaseDare.alreadyFixed || releaseDare.next === 'CONTINUE') {
        emit('validate', 'done', '✓ SoloHost runtime contract already satisfied. Continuing publish.');
      } else if (releaseDare.stopped && pendingEarly?.githubUrl) {
        emit('validate', 'done', 'Runtime contract was already repaired. Checking GitHub/GHCR instead of repeating the same patch.');
      } else if (releaseDare.stopped) {
        emit('validate', 'done', 'Runtime contract repair already ran. Continuing with the current source instead of repeating the same patch.');
      }
    }
    const previewFresh = runtime.status === 'passed' && runtime.health === true;
    if (!upgradeOrigin && tests.nodeResult?.status === 'failed' && !previewFresh) {
      throw new Error('Release blocked: the latest saved verification still has a failed runtime test. Tap Run first so the live preview can refresh the test report.');
    }
    if (!upgradeOrigin && tests.nodeResult?.status === 'failed' && previewFresh) {
      emit('validate', 'done', 'Live preview already passed. I am using that result instead of the older npm test report.');
      tests.nodeResult = { status: 'passed', runner: 'preview-health', reason: 'Superseded by a passing live preview.' };
      await projects.saveMetadata(project, 'test-plan.json', { ...tests, verifiedAt: new Date().toISOString() });
    }

    if (!upgradeOrigin) await stampMadeBy(source, cfg);
    const quality = upgradeOrigin
      ? await projects.readMetadata(project, 'upgrade-quality.json', { mode: 'upgrade-origin', verdict: 'NOT_REVIEWED_BY_BUILD' })
      : await review(project);
    let aiDescription = '';
    try {
      const desc = await ai.completeJson({ task: 'DESCRIPTION', system: SYSTEM, prompt: descriptionPrompt(project), projectId: project.id });
      aiDescription = String(desc.json?.description || '').trim();
    } catch { /* deterministic fallback below */ }
    const notes = await releases.prepareNotes(project, source, quality);

    let githubPublish = null;
    let githubUrl = null;
    let imageVerification = { ok: false };
    let workflowRun = null;
    let workflowDiagnostics = null;
    let autoRepair = null;

    // Field choice BEFORE GitHub push for brand-new projects (not upgrade, no existing package)
    {
      const { resolveFieldPolicy, hasExistingSoloHostPackage } = await import('../release/field-gate.js');
      const earlyExisting = await hasExistingSoloHostPackage(source);
      const earlyGate = await resolveFieldPolicy({
        projectDir: projects.projectDir(project),
        payload,
        existingPackage: earlyExisting,
        upgradeOrigin,
      });
      if (earlyGate.needsChoice && payload.verifyImage !== true && payload.recheck !== true) {
        emit('package', 'done', 'Choose install fields before publishing to GitHub.');
        return {
          status: 'needs_field_choice',
          release: null,
          quality: null,
          guide: {
            step: 2,
            title: 'Choose install fields',
            action: 'solohost_fields',
            label: 'Choose fields',
            payload: { projectId: project.id },
            detail: 'Pick Full form, All defaults, Login only, or Custom before GitHub publish.',
          },
          next: 'Choose install fields, then Publish again.',
          brief: 'RESULT: Not ready.\nWHY: SoloHost install fields not chosen yet.\nNEXT: Choose Full / Defaults / Login only / Custom.',
        };
      }
    }

    const pending = await projects.readMetadata(project, 'release-pending.json', null);
    const verifyOnly = Boolean(pending?.githubUrl)
      && payload.existingAction !== 'overwrite'
      && payload.forcePublish !== true
      && (payload.verifyImage === true || payload.recheck === true);
    if (verifyOnly) {
      githubUrl = pending.githubUrl;
      githubPublish = { ok: true, verified: true, owner: pending.owner, repo: pending.repo, url: pending.githubUrl, sha: pending.sha };
      emit('github', 'done', 'GitHub source is already verified. Checking the matching Actions run…');
    } else if (github.configured() && payload.push !== false) {
      emit('github', 'running', 'Publishing source…');
      githubPublish = await publishToGitHub({
        upgradeOrigin: typeof upgradeOrigin !== 'undefined' && Boolean(upgradeOrigin),
        github,
        project,
        sourceDir: source,
        version: notes.version,
        emit,
        runtimeOk: Boolean(upgradeOrigin) || (runtime.health === true && runtime.status === 'passed'),
        repoName: payload.repoName || pending?.repo || project.slug,
        existingAction: payload.existingAction || (pending?.repo || payload.forcePublish ? 'overwrite' : 'confirm'),
      });
      githubUrl = githubPublish.ok && githubPublish.verified ? githubPublish.url : null;
      if (githubPublish.code === 'REPO_EXISTS') {
        return {
          status: 'needs_repository_choice', githubUrl: githubPublish.url || null, githubPublish,
          installReady: false, checklist: ['✓ Build', '✓ Test', '• GitHub', '• GHCR', '• SoloHost'],
          repoChoice: true, choices: githubPublish.choices || [], guide: { step: 3, title: 'Choose the repository action', action: 'publish', label: '🚀 Publish', detail: 'Choose Overwrite to replace the existing repository, or Create new repository to keep it unchanged.' },
          brief: `RESULT: GitHub needs your choice.\nDONE: The app passed the pre-publish checks.\nMISSING: Choose Overwrite or Create new repository.\nNEXT: Choose one option below.`,
          next: 'Choose Overwrite or Create new repository.',
        };
      }
      if (!githubPublish.ok) {
        const zipFail = await createProjectZip({ sourceDir: source, outputDir: path.join(projects.projectDir(project), 'artifacts'), slug: project.slug, kind: 'project' }).catch(() => null);
        return {
          status: 'blocked', githubUrl: null, githubPublish, installReady: false,
          checklist: ['✓ Build', '✓ Test', '✗ GitHub', '• GHCR', '• SoloHost'],
          downloads: [
            ...(zipFail ? [{ kind: 'project', filename: zipFail.filename, url: `/api/projects/${project.id}/download?kind=project` }] : []),
            { kind: 'github-fallback', filename: 'GitHub-ZIP-Image-Publisher-v5.0.ps1', url: `/api/projects/${project.id}/github-fallback` },
          ],
          fallback: { ...(githubPublish.fallback || {}), scriptUrl: `/api/projects/${project.id}/github-fallback`, scriptFilename: 'GitHub-ZIP-Image-Publisher-v5.0.ps1' },
          brief: [githubPublish.error, githubPublish.fix].filter(Boolean).join('\n'),
          next: 'GitHub source was not verified. Fix the GitHub access shown above, then tap Publish once.',
        };
      }
    } else {
      throw new Error('GITHUB_TOKEN_REQUIRED: GitHub authorization is required. Open Settings → GitHub owner + token → Save, then Publish again.');
    }

    const owner = githubPublish?.owner || pending?.owner || cfg.github.owner || 'YOUR_GITHUB';
    const repo = githubPublish?.repo || pending?.repo || project.slug;
    // Prefer the immutable commit SHA tag for the install kit. The workflow
    // smoke-tests that exact commit and SoloHost will never accidentally reuse
    // a stale image carrying the same human version tag. Keep the version tag
    // as a fallback for older/pending releases where a commit SHA is unknown.
    let imageTag = githubPublish?.sha || pending?.sha || notes.version;
    imageTag = /^[0-9a-f]{40}$/i.test(String(imageTag)) ? String(imageTag).toLowerCase() : notes.version;
    let registryImage = `ghcr.io/${owner}/${repo}:${imageTag}`.toLowerCase();

    async function savePending(extra = {}) {
      await projects.saveMetadata(project, 'release-pending.json', {
        owner, repo, githubUrl, version: notes.version, sha: githubPublish?.sha || pending?.sha || null,
        image: registryImage, createdAt: pending?.createdAt || new Date().toISOString(),
        autoRepairAttempts: Number(pending?.autoRepairAttempts || 0), ...extra,
      });
    }

    if (githubUrl) {
      await savePending({ status: 'waiting_image' });
      for (let cycle = 0; cycle < 2; cycle += 1) {
        emit('docker-publish', 'running', cycle === 0 ? 'Checking GitHub Actions → GHCR image…' : 'Re-checking the repaired GitHub Actions build…');
        const wait = await waitForGithubImage({ repo, owner, imageTag: imageTag, headSha: githubPublish?.sha || pending?.sha || null, emit });
        imageVerification = wait.imageVerification || { ok: false };
        workflowRun = wait.workflowRun || null;
        workflowDiagnostics = wait.diagnostics || null;
        if (wait.ok) break;
        if (wait.pending) {
          await savePending({ status: 'waiting_image', workflowRun: workflowRun || null, lastCheckedAt: new Date().toISOString() });
          const detail = 'GitHub source is uploaded. The matching image is still building. Tap Check image when GitHub Actions finishes.';
          emit('release', 'done', detail);
          return {
            status: 'waiting_github_actions', release: null, quality, githubUrl, githubPublish, installReady: false,
            checklist: ['✓ Build', '✓ Test', '✓ GitHub', '• GHCR', '• SoloHost'], image: registryImage,
            imageVerification, workflowRun, workflowDiagnostics, autoRepair,
            guide: { step: 4, title: 'Waiting for the GHCR image', action: 'publish', label: '🔄 Check image', detail },
            next: detail, brief: `RESULT: GitHub source is verified.\nMISSING: ${registryImage}\nNEXT: Wait for GitHub Actions to finish, then tap Check image.`,
          };
        }

        if (!wait.failed) break;
        const attempts = Number((pending?.autoRepairAttempts || autoRepair?.attempts || 0));
        if (upgradeOrigin || attempts >= 1 || cycle >= 1 || payload.verifyImage === true) break;
        autoRepair = await repairGithubActionsFailure({ project, source, owner, repo, version: notes.version, githubUrl, workflowRun, diagnostics: workflowDiagnostics, emit, notes, projectPayload: payload });
        if (!autoRepair?.ok) break;
        if (!pending || typeof pending !== 'object') pending = {};
        pending.autoRepairAttempts = 1;
        githubPublish = autoRepair.githubPublish || githubPublish;
        githubUrl = githubPublish?.url || githubUrl;
        if (/^[0-9a-f]{40}$/i.test(String(githubPublish?.sha || ''))) {
          imageTag = String(githubPublish.sha).toLowerCase();
          registryImage = `ghcr.io/${owner}/${repo}:${imageTag}`.toLowerCase();
        }
        await savePending({ status: 'waiting_image', autoRepairAttempts: 1, sha: githubPublish?.sha || null, image: registryImage });
      }
    }

    const imageOk = Boolean(imageVerification.ok);
    if (!imageOk) {
      await savePending({ status: workflowDiagnostics ? 'workflow_failed' : 'waiting_image', workflowRun, diagnostics: workflowDiagnostics, autoRepairAttempts: autoRepair?.attempts || pending?.autoRepairAttempts || 0, lastCheckedAt: new Date().toISOString() });
      const classified = classifyLogs(workflowDiagnostics?.logTail || imageVerification?.error || '') || {};
      const logExcerpt = String(workflowDiagnostics?.logTail || imageVerification?.error || '').split(/\n/).slice(-18).join('\n').slice(-1800);
      const diagnosisText = workflowDiagnostics
        ? [
            workflowDiagnostics.summary,
            classified.title,
            classified.hint,
            workflowDiagnostics.run?.html_url ? `Run: ${workflowDiagnostics.run.html_url}` : '',
            logExcerpt,
          ].filter(Boolean).join('\n')
        : (imageVerification?.error || 'The image is not visible in GHCR yet.');
      const detail = workflowDiagnostics
        ? `GitHub Actions failed.\n${classified.title || workflowDiagnostics.summary}\n${classified.hint || ''}\n${logExcerpt || 'No readable log lines were returned.'}`
        : 'GitHub Actions is still building or GHCR has not finished indexing the image.';
      emit('release', 'done', detail);
      return {
        status: workflowDiagnostics ? 'github_actions_failed' : 'waiting_github_actions', release: null, quality, githubUrl, githubPublish,
        installReady: false, checklist: ['✓ Build', '✓ Test', '✓ GitHub', '✗ GHCR', '• SoloHost'], image: registryImage,
        imageVerification, workflowRun, workflowDiagnostics, autoRepair, diagnosis: diagnosisText,
        guide: { step: 4, title: workflowDiagnostics ? 'Fix the GitHub Actions build' : 'Waiting for the GHCR image', action: 'publish', label: workflowDiagnostics ? '🚀 Re-check build' : '🔄 Check image', payload: { approved: true, confirm: true, push: true, verifyImage: true }, detail: workflowDiagnostics ? `${String(detail).slice(0, 500)}\nRe-check reads the latest Actions result and does not upload source again.` : detail },
        next: workflowDiagnostics ? 'Read the Actions error above. Fix that cause, then tap Re-check build.' : 'Wait for GitHub Actions, then tap Check image.',
        brief: `RESULT: GitHub source is verified.\nWHY: ${String(detail).slice(0, 900)}\nMISSING: ${registryImage}\nNEXT: ${workflowDiagnostics ? 'Do not republish until the Actions error above is fixed. Tap Re-check build to read the latest run.' : 'Tap Check image when the build finishes.'}`,
      };
    }

    try { await github.setContainerPublic(`${owner}/${repo}`); } catch {}
    await github.createRelease(repo, notes.version, notes.notes).catch((err) => log.warn('GitHub release notes failed', { error: String(err.message || err).replace(/ghp_[A-Za-z0-9]+/g, 'ghp_***') }));

    // IMPORTANT: do not create or offer the SoloHost install kit before the exact
    // GHCR image tag has been verified. This removes the previous race condition.
    emit('package', 'running', 'GHCR image verified. Creating the SoloHost install kit…');
    const projectDir = projects.projectDir(project);
    const metaDir = path.join(projectDir, 'metadata');
    const { resolveFieldPolicy, hasExistingSoloHostPackage } = await import('../release/field-gate.js');
    const existingPackage = await hasExistingSoloHostPackage(source);
    const gate = await resolveFieldPolicy({
      projectDir,
      payload,
      existingPackage,
      upgradeOrigin,
    });
    if (gate.needsChoice) {
      await fs.mkdir(metaDir, { recursive: true }).catch(() => {});
      await fs.writeFile(path.join(metaDir, 'release-pending.json'), JSON.stringify({
        status: 'package_pending',
        reason: 'needs_field_choice',
        image: registryImage,
        githubUrl,
        version: notes?.version,
        updatedAt: new Date().toISOString(),
      }, null, 2)).catch(() => {});
      emit('package', 'done', 'Choose which install fields SoloHost should ask for.');
      return {
        status: 'needs_field_choice',
        release: null,
        quality,
        githubUrl,
        image: registryImage,
        guide: {
          step: 5,
          title: 'Choose install fields',
          action: 'solohost_fields',
          label: 'Choose fields',
          payload: { projectId: project.id },
          detail: 'Pick Full form, All defaults, Login only, or Custom before the SoloHost kit is built.',
        },
        next: 'Choose install fields, then publish continues.',
        brief: 'RESULT: Not ready.\nWHY: SoloHost install fields not chosen yet.\nNEXT: Choose Full / Defaults / Login only / Custom.',
      };
    }
    const fieldPolicy = gate.policy;
    let packageInfo = await releases.prepareSoloHost(project, source, registryImage, aiDescription, {
      fieldPolicy,
      hostPort: gate.hostPort,
      metaDir,
    });
    if (packageInfo?.ok === false && packageInfo?.lint?.errors?.length) {
      // Image already verified: heal package once more instead of locking the user.
      try {
        const { writeSoloHostPackage } = await import('../release/solohost.js');
        packageInfo = await writeSoloHostPackage({
          project,
          sourceDir: source,
          image: registryImage,
          hostPort: gate.hostPort,
          description: aiDescription,
          fieldPolicy: fieldPolicy || { mode: 'auth', fields: {}, fixedValues: {}, minimal: true },
          preferLatestImage: true,
          minimalInstallFields: true,
        });
      } catch { /* keep previous packageInfo */ }
    }
    if (packageInfo?.ok === false && packageInfo?.lint?.errors?.length) {
      const errText = formatSoloHostErrors(packageInfo.lint.errors.map((e) => e.rule + ': ' + (e.params?.var || e.path)));
      emit('package', 'running', `SoloHost kit written with warnings; remaining lint: ${errText.slice(0, 280)}`);
      // Do not throw after GHCR success — kit files are on disk; user can still copy them.
      packageInfo = { ...packageInfo, ok: true, softLint: true, lint: packageInfo.lint };
    }
    emit('package', 'running', 'Validating SoloHost package…');
    const validation = await releases.validateSoloHost(source, {
      acceptUnverified: gate.acceptUnverified,
      policy: fieldPolicy,
    });
    if (validation?.code === 'UNREACHABLE' || validation?.mode === 'unreachable') {
      await fs.writeFile(path.join(metaDir, 'release-pending.json'), JSON.stringify({
        status: 'package_pending',
        reason: 'unreachable',
        image: registryImage,
        githubUrl,
        version: notes?.version,
        updatedAt: new Date().toISOString(),
      }, null, 2)).catch(() => {});
      emit('package', 'done', 'SoloHost validator unreachable. Confirm to accept unverified kit.');
      return {
        status: 'needs_confirmation',
        code: 'UNREACHABLE',
        release: null,
        quality,
        githubUrl,
        image: registryImage,
        packageInfo,
        guide: {
          step: 5,
          title: 'Accept unverified SoloHost kit?',
          action: 'publish',
          label: 'Accept unverified',
          payload: { approved: true, confirm: true, push: true, verifyImage: true, acceptUnverified: true, fieldPolicy },
          detail: 'Remote SoloHost validation is unreachable. Local lint passed. Accept to continue with an unverified kit.',
        },
        next: 'Tap Accept unverified, or retry later.',
        brief: 'RESULT: Needs confirmation.\nWHY: SoloHost validator unreachable.\nNEXT: Accept unverified or retry.',
      };
    }
    if (validation?.ok === false) {
      const errText = formatSoloHostErrors(validation.errors);
      emit('package', 'failed', `SoloHost package validation failed: ${errText}`);
      throw new Error(`SoloHost package validation failed: ${errText}`);
    }
    if (validation?.warnings?.length) {
      emit('package', 'done', `SoloHost package ready (local OK). Note: ${formatSoloHostErrors(validation.warnings)}`);
    }
    const zip = await createProjectZip({ sourceDir: source, outputDir: path.join(projects.projectDir(project), 'artifacts'), slug: project.slug, kind: 'solohost' }).catch(() => null);
    // Upgrade-origin: runtime.health may be baseline-true; do not require live Run for install kit after GHCR verify
    const installReady = Boolean(validation?.ok !== false && githubUrl && imageOk && (zip || packageInfo));
    const status = installReady ? 'released' : 'github_published';
    const rec = releases.record(project, { version: notes.version, notes: notes.notes, githubUrl, status });
    projects.setStatus(project, installReady ? 'RELEASED' : 'WAITING_APPROVAL');
    await fs.rm(path.join(projects.projectDir(project), 'metadata', 'release-pending.json'), { force: true }).catch(() => {});

    let composeYaml = '';
    let configYaml = '';
    try {
      composeYaml = await fs.readFile(path.join(source, 'solohost', 'docker-compose.yml'), 'utf8');
      configYaml = await fs.readFile(path.join(source, 'solohost', 'config_options.yml'), 'utf8');
    } catch {}
    // Short chat event; full YAML delivered via result.solohostFiles for structured UI.
    const copyGuide = installReady
      ? '\n📦 SoloHost install kit ready — use the copy cards below (or download ZIP).'
      : '';

    const checklist = ['✓ Build', runtime.health ? '✓ Test' : '• Test', githubUrl ? '✓ GitHub' : '✗ GitHub', imageOk ? '✓ GHCR' : '✗ GHCR', installReady ? '✓ SoloHost' : '• SoloHost'];
    const next = installReady
      ? 'Copy docker-compose.yml + config_options.yml into SoloHost → Save → Start.'
      : 'GHCR is verified, but the SoloHost ZIP was not created. Use Zip to retry packaging.';
    if (installReady) {
      emit('release', 'done', `GitHub ✓ · GHCR ✓ · SoloHost install kit ✓${copyGuide}`);
    }
    return {
      status, release: rec, quality, githubUrl, githubPublish, installReady, checklist,
      solohostFiles: installReady ? {
        compose: composeYaml.trim(),
        config: configYaml.trim(),
        filenames: ['docker-compose.yml', 'config_options.yml'],
      } : null,
      image: registryImage, imageVerification, workflowRun, workflowDiagnostics, autoRepair, soloHostPackage: packageInfo, validation, imageOk,
      downloads: [
        zip ? { kind: 'solohost', filename: zip.filename, url: `/api/projects/${project.id}/download?kind=solohost` } : null,
        { kind: 'project', filename: `${project.slug}-source.zip`, url: `/api/projects/${project.id}/download?kind=project` },
        { kind: 'github-fallback', filename: 'GitHub-ZIP-Image-Publisher-v5.0.ps1', url: `/api/projects/${project.id}/github-fallback` },
      ].filter(Boolean),
      fallback: githubPublish?.fallback || null,
      missing: installReady ? [] : ['SoloHost install kit was not created.'],
      next,
      guide: { step: 5, title: 'Install on SoloHost', action: 'export', payload: { kind: 'solohost' }, label: '⬇ Install kit', detail: '1. Download the SoloHost ZIP. 2. In SoloHost choose Import/Add App and select the ZIP. 3. Save any requested settings and tap Start.' },
      install: githubPublish?.install || null,
      brief: `RESULT: ${installReady ? 'Ready for SoloHost.' : 'GHCR verified, packaging needs retry.'}\nDONE: GitHub source and exact GHCR image are verified.\nNEXT: ${next}`,
    };
  }

  async function waitForGithubImage({ repo, owner, imageTag, headSha, emit }) {
    const deadline = Date.now() + 480000;
    let imageVerification = { ok: false };
    let workflowRun = null;
    let diagnostics = null;
    while (Date.now() < deadline) {
      // When we know the freshly published commit SHA, first bind the check to
      // that exact Actions run. A pre-existing GHCR tag must never satisfy a
      // new release before its own workflow has passed.
      workflowRun = await github.latestWorkflowRun(repo, 'docker.yml', { headSha }).catch(() => null) || workflowRun;
      if (headSha && !workflowRun) {
        emit('docker-publish', 'running', 'Waiting for the GitHub Actions run for this commit…');
        await new Promise((resolve) => setTimeout(resolve, 3000));
        continue;
      }
      if (workflowRun?.status === 'completed' && workflowRun.conclusion && workflowRun.conclusion !== 'success') {
        if (workflowRun.id && typeof github.workflowDiagnostics === 'function') {
          diagnostics = await github.workflowDiagnostics(repo, workflowRun.id).catch((err) => ({ summary: 'Unable to read GitHub Actions logs.', logTail: String(err.message || err) }));
        }
        imageVerification = await github.verifyContainerImage(`${owner}/${repo}`, imageTag).catch((err) => ({ ok: false, error: String(err?.message || err) }));
        return { failed: true, imageVerification: { ...imageVerification, workflow: workflowRun, error: `GitHub Actions finished with ${workflowRun.conclusion}.` }, workflowRun, diagnostics };
      }
      imageVerification = await github.verifyContainerImage(`${owner}/${repo}`, imageTag).catch((err) => ({ ok: false, error: String(err?.message || err) }));
      if (workflowRun?.status === 'completed' && workflowRun.conclusion === 'success' && imageVerification.ok) {
        return { ok: true, imageVerification, workflowRun, diagnostics };
      }
      emit('docker-publish', 'running', workflowRun?.status === 'in_progress' || workflowRun?.status === 'queued' ? `GitHub Actions: ${workflowRun.status}…` : 'Waiting for the matching GHCR tag…');
      await new Promise((resolve) => setTimeout(resolve, 3000));
    }
    return { pending: true, imageVerification, workflowRun, diagnostics };
  }

  async function repairGithubActionsFailure({ project, source, owner, repo, version, githubUrl, workflowRun, diagnostics, emit, notes, projectPayload }) {
    if (!diagnostics?.logTail) return { ok: false, reason: 'No readable GitHub Actions log.' };
    const classified = classifyLogs(diagnostics.logTail) || {};
    let dareCheckpoint = null;
    try {
      const history = await projects.readMetadata(project, 'dare-history.json', []);
      dareCheckpoint = await snapshots.create(project, 'before-dare-github-actions').catch(() => null);
      const dare = await runDare({ sourceDir: source, logs: diagnostics.logTail, extra: classified, history: Array.isArray(history) ? history : [] });
      await projects.saveMetadata(project, 'dare-history.json', (dare.history || []).slice(-20));
      emit('repair', dare.ok ? 'running' : 'done', formatDareReport(dare));
      if (dare.ok) {
        const republish = await publishToGitHub({
          upgradeOrigin: typeof upgradeOrigin !== 'undefined' && Boolean(upgradeOrigin),
          github, project, sourceDir: source, version, emit,
          runtimeOk: true, repoName: repo, existingAction: 'overwrite', refreshWorkflow: false,
        });
        if (republish.ok && republish.verified) {
          emit('repair', 'done', `${formatDareReport(dare)}\n✓ Re-publish and GitHub verification passed.`);
          return { ok: true, attempts: 1, githubPublish: republish, rootCause: dare.reason, explanation: dare.reason, files: dare.files, dare };
        }
        if (dareCheckpoint?.id) {
          await snapshots.restore(project, dareCheckpoint.id).catch(() => {});
          emit('rollback', 'done', 'The deterministic repair did not produce a verified GitHub result, so the previous checkpoint was restored.');
        }
      }
      if (dare.userAction || dare.stopped) {
        return { ok: false, reason: dare.reason, dare, userAction: dare.userAction };
      }
      const crashLayer = /DOCKER_CONTAINER_CRASH|ALPINE_NATIVE_MODULE|NODE_SYNTAX_ERROR|container exited before smoke|did not become reachable/i.test(`${classified.code || ''} ${classified.title || ''} ${diagnostics.logTail || ''}`);
      if (crashLayer) {
        emit('repair', 'done', 'GHCR smoke failed because the app container died. Builder will not rewrite GitHub Actions for this. Fix the app start/Dockerfile, then tap Re-check build.');
        return { ok: false, reason: 'App container crashed in GHCR. Workflow rewrite skipped.', classified, dare };
      }
    } catch (err) {
      if (dareCheckpoint?.id) await snapshots.restore(project, dareCheckpoint.id).catch(() => {});
      emit('repair', 'failed', String(err.message || err).slice(0, 240));
    }
    const logText = String(diagnostics.logTail || '');
    const portHit = logText.match(/running on port\s+(\d+)/i);
    // A generic smoke failure is not enough evidence to edit the workflow.
    // Container crashes (including EACCES) belong to runtime/source diagnosis;
    // only an explicit workflow classification may trigger a workflow patch.
    const workflowSmokeRepairEligible = classified?.code === 'workflow_port_mismatch'
      || classified?.code === 'workflow_smoke_timeout'
      || classified?.code === 'workflow_image_tag_mismatch';
    if (workflowSmokeRepairEligible) {
      const listenPort = portHit ? Number(portHit[1]) : 0;
      emit('repair', 'running', listenPort
        ? `The smoke test missed port ${listenPort}. Updating the GitHub workflow without rewriting the app…`
        : 'Updating the GitHub smoke-test workflow so it finds the built image tag and a listening port…');
      try {
        await writeGithubWorkflow(source, { ...project, version, listenPort });
        const df = path.join(source, 'Dockerfile');
        const current = await fs.readFile(df, 'utf8').catch(() => '');
        if (listenPort && current && !new RegExp(`EXPOSE\\s+${listenPort}\\b`).test(current)) {
          const next = /EXPOSE\s+\d+/.test(current)
            ? current.replace(/EXPOSE\s+\d+/, `EXPOSE ${listenPort}`)
            : `${current.trim()}\nEXPOSE ${listenPort}\n`;
          await fs.writeFile(df, next);
        }
        const republish = await publishToGitHub({
          upgradeOrigin: typeof upgradeOrigin !== 'undefined' && Boolean(upgradeOrigin),
          github, project, sourceDir: source, version, emit,
          runtimeOk: true, repoName: repo, existingAction: 'overwrite', refreshWorkflow: false,
        });
        if (republish.ok && republish.verified) {
          emit('repair', 'done', '✓ GitHub workflow smoke test was updated. Actions will rebuild the image.');
          return { ok: true, attempts: 1, githubPublish: republish, rootCause: classified.title || 'GitHub Actions smoke test', explanation: classified.hint || 'Workflow image tag/port probe updated.', files: ['.github/workflows/docker.yml'] };
        }
      } catch (err) {
        emit('repair', 'failed', String(err.message || err).slice(0, 240));
      }
    }
    const evidence = clampText(`${diagnostics.summary}\nCLASSIFICATION: ${JSON.stringify(classified || {})}\nFAILED JOBS:\n${JSON.stringify(diagnostics.jobs || [])}\nLOG:\n${diagnostics.logTail}`, 16000);
    emit('diagnose', 'running', 'Reading the failed GitHub Actions job and asking AI for the smallest safe fix…');
    let r;
    try {
      const relevant = await collectProjectContext(source, '', 'improve');
      r = await ai.completeJson({
        task: 'DEBUGGING',
        system: SYSTEM,
        prompt: `${languageInstruction(project.idea)}\nGITHUB ACTIONS RELEASE FAILURE\nRepository: ${owner}/${repo}\nWorkflow run: ${workflowRun?.html_url || workflowRun?.id || 'unknown'}\n\nEVIDENCE:\n${evidence}\n\nPROJECT FILES:\n${relevant}\n\nREQUIRED RESPONSE:\n- Diagnose the concrete root cause from the Actions log.\n- Prefer workflow/config fixes when the app itself is healthy. Do not change working app code for a CI-only problem.\n- Return only files that are strictly required.\n- Risk must be low for automatic repair.\n- Do not invent secrets, tokens, permissions, or host access.\n${patchPrompt(project, evidence, relevant, 'Fix only the current GitHub Actions build failure. Preserve the working app and SoloHost contract.')}`,
        projectId: project.id,
      });
    } catch (err) {
      emit('diagnose', 'failed', friendlyAiError(err));
      return { ok: false, reason: friendlyAiError(err) };
    }
    const proposed = Array.isArray(r.json?.files) ? r.json.files : [];
    const risk = String(r.json?.risk || 'medium').toLowerCase();
    if (!proposed.length || risk !== 'low') {
      emit('diagnose', 'done', `AI diagnosis: ${String(r.json?.root_cause || classified?.title || 'The workflow failure needs manual review.').slice(0, 240)}`);
      return { ok: false, reason: r.json?.explanation || 'AI did not return a low-risk automatic fix.' };
    }

    const beforeStatic = await runStaticTests(source);
    const beforeNode = await runNodeTests(source, 45000);
    const beforeSecurity = await scanProject(source);
    const checkpoint = await applySafeAiPatch({ sourceDir: source, files: proposed, project, snapshots, reason: 'github-actions-auto-fix' });
    emit('repair', 'running', `Applying one low-risk GitHub Actions repair (${proposed.length} file${proposed.length === 1 ? '' : 's'})…`);
    try {
      const afterStatic = await runStaticTests(source);
      const afterNode = await runNodeTests(source, 45000);
      const afterSecurity = await scanProject(source);
      const worse = failureScore(afterStatic, afterNode) > failureScore(beforeStatic, beforeNode) || afterSecurity.critical > beforeSecurity.critical;
      if (worse) {
        await snapshots.restore(project, checkpoint.snapshot.id).catch(() => {});
        emit('rollback', 'done', 'The automatic Actions repair made verification worse, so the previous working state was restored.');
        return { ok: false, rolledBack: true, reason: 'Verification became worse.' };
      }
      await stampMadeBy(source, cfg);
      const republish = await publishToGitHub({
        upgradeOrigin: typeof upgradeOrigin !== 'undefined' && Boolean(upgradeOrigin),
        github, project, sourceDir: source, version, emit,
        runtimeOk: true, repoName: repo, existingAction: 'overwrite', refreshWorkflow: false,
      });
      if (!republish.ok || !republish.verified) {
        await snapshots.restore(project, checkpoint.snapshot.id).catch(() => {});
        emit('rollback', 'done', 'The repaired source could not be republished safely, so the previous working state was restored.');
        return { ok: false, rolledBack: true, githubPublish: republish, reason: republish.error || 'Re-publish verification failed.' };
      }
      emit('repair', 'done', `✓ Safe repair applied: ${String(r.json?.root_cause || 'GitHub Actions issue fixed.').slice(0, 220)}`);
      return { ok: true, attempts: 1, githubPublish: republish, rootCause: r.json?.root_cause || '', explanation: r.json?.explanation || '', files: proposed.map((f) => f.path) };
    } catch (err) {
      await snapshots.restore(project, checkpoint.snapshot.id).catch(() => {});
      emit('rollback', 'done', 'The automatic GitHub Actions repair did not verify, so the previous working state was restored.');
      return { ok: false, rolledBack: true, reason: String(err.message || err).slice(0, 500) };
    }
  }

  jobs.on('release', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    return runRelease(project, job.payload || {}, emit);
  });


  jobs.on('sandbox_command', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    const command = String(job.payload.command || '').trim();
    if (!command) throw new Error('Sandbox command is empty.');
    emit('sandbox', 'running', `Sandbox: ${command.slice(0, 120)}`);
    const result = await runner.execSandbox({ sourcePath: projects.sourceDir(project.slug), image: job.payload.image || null, command, timeout: Math.min(Number(job.payload.timeout || 120), 300) });
    emit('sandbox', result.status === 'passed' ? 'done' : 'failed', result.status === 'passed' ? 'Sandbox command completed.' : (result.error || 'Sandbox command failed.'));
    return result;
  });

  async function collectPublishedIncidentEvidence(project, message, runtimeNow) {
    const raw = `${message}\n${runtimeNow?.error || ''}\n${runtimeNow?.logs || ''}`;
    if (!/(EACCES|permission denied|cannot find module|ERR_MODULE_NOT_FOUND|process died|container (?:exited|crashed)|did not become reachable|health check.*(?:fail|error)|connection refused|GHCR.*(?:fail|error|denied)|GitHub Actions.*(?:fail|error)|không chạy|lỗi)/i.test(raw)) return null;

    const release = await projects.readMetadata(project, 'release.json', {});
    const pending = await projects.readMetadata(project, 'release-pending.json', {});
    const released = release?.github || {};
    const fromMessage = parseGithubRepoUrl(message);
    const parsedRelease = parseGithubRepoUrl(released?.url || pending?.githubUrl || '');
    const repoInfo = fromMessage || parsedRelease || ((released?.owner && released?.repo) ? { owner: released.owner, repo: released.repo, url: released.url || `https://github.com/${released.owner}/${released.repo}` } : null);

    let workflowRun = null;
    let workflowDiagnostics = null;
    if (repoInfo?.repo && github?.latestWorkflowRun) {
      const headSha = released?.sha || pending?.sha || null;
      workflowRun = await github.latestWorkflowRun(repoInfo.repo, 'docker.yml', { headSha }).catch(() => null);
      if (workflowRun?.status === 'completed' && workflowRun.conclusion && workflowRun.conclusion !== 'success' && workflowRun.id && typeof github.workflowDiagnostics === 'function') {
        workflowDiagnostics = await github.workflowDiagnostics(repoInfo.repo, workflowRun.id).catch((err) => ({
          summary: 'Unable to read GitHub Actions logs.',
          logTail: String(err.message || err),
        }));
      }
    }

    const published = Boolean(released?.verified || released?.url || pending?.githubUrl || repoInfo?.repo);
    const incident = maskSecrets(clampText(raw, 9000));
    const githubEvidence = workflowDiagnostics
      ? maskSecrets(clampText([
        `Repository: ${repoInfo?.owner || ''}/${repoInfo?.repo || ''}`,
        `Workflow: ${workflowRun?.html_url || workflowRun?.id || 'unknown'}`,
        `Status: ${workflowRun?.status || 'unknown'} / ${workflowRun?.conclusion || 'unknown'}`,
        workflowDiagnostics.summary,
        workflowDiagnostics.logTail,
      ].filter(Boolean).join('\n'), 10000))
      : (workflowRun ? `Repository: ${repoInfo?.owner || ''}/${repoInfo?.repo || ''}\nWorkflow: ${workflowRun.html_url || workflowRun.id || 'unknown'}\nStatus: ${workflowRun.status || 'unknown'} / ${workflowRun.conclusion || 'unknown'}` : 'No matching GitHub Actions failure was available.');

    return {
      published,
      repoInfo,
      release,
      pending,
      workflowRun,
      workflowDiagnostics,
      context: `PUBLISHED RUNTIME INCIDENT EVIDENCE\nUser/runtime evidence:\n${incident}\n\nGitHub evidence:\n${githubEvidence}`,
    };
  }

  async function triagePublishedIncident(project, message, runtimeNow, emit) {
    const evidence = await collectPublishedIncidentEvidence(project, message, runtimeNow);
    if (!evidence) return null;
    const source = projects.sourceDir(project.slug);
    const history = await projects.readMetadata(project, 'dare-history.json', []);
    let checkpoint = null;
    try {
      checkpoint = await snapshots.create(project, 'before-published-incident-repair').catch(() => null);
      const dare = await runDare({
        sourceDir: source,
        logs: `${message}\n${runtimeNow?.error || ''}\n${runtimeNow?.logs || ''}\n${evidence.workflowDiagnostics?.logTail || ''}`,
        extra: evidence.workflowRun || {},
        history: Array.isArray(history) ? history : [],
      });
      await projects.saveMetadata(project, 'dare-history.json', (dare.history || []).slice(-20));
      if (dare.stopped) {
        return { handled: false, stopped: true, evidence, dare };
      }
      if (dare.ok || dare.alreadyFixed || dare.next === 'CONTINUE') {
        if (dare.ok) emit('repair', 'done', formatDareReport(dare));
        else emit('repair', 'done', `✓ Deterministic diagnosis complete. ${dare.reason || 'The source already contains the required runtime repair.'}`);
        return {
          handled: true,
          action: evidence.published ? 'publish' : 'run',
          reply: dare.ok
            ? `I found a concrete runtime problem and applied the smallest safe repair. I will verify the published image before reporting success.`
            : `I found the same runtime issue, but the source already contains the required safe repair. I will verify the published image instead of changing the app again.`,
          goal: evidence.published ? 'Verify the published GitHub Actions run and exact GHCR image after the deterministic runtime diagnosis; do not repeat the same source patch.' : 'Run the repaired app and verify health before reporting success.',
          dare,
          evidence,
        };
      }
      if (dare.userAction) {
        return { handled: false, evidence, userAction: true, dare };
      }
      return { handled: false, evidence, dare };
    } catch (err) {
      if (checkpoint?.id) await snapshots.restore(project, checkpoint.id).catch(() => {});
      emit('repair', 'failed', `Deterministic incident repair stopped safely: ${String(err.message || err).slice(0, 220)}`);
      return { handled: false, evidence, error: String(err.message || err).slice(0, 500) };
    }
  }

  jobs.on('builder_chat', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    const message = String(job.payload.message || '').trim();
    if (!message) throw new Error('Write a message first.');
    const userLanguage = detectUserLanguage(message);
    const incomingFiles = Array.isArray(job._files) ? job._files : [];
    for (const file of incomingFiles.slice(0, 8)) if (file?.buffer) await saveAttachment(projects.projectDir(project), file);
    await projects.chat(project, message, 'user', { attachments: incomingFiles.map((f) => f.originalname).filter(Boolean) });
    const source = projects.sourceDir(project.slug);
    const diagnosis = await diagnoseSource(source);
    const runtimeNow = await projects.readMetadata(project, 'runtime.json', {});
    const history = (await projects.chatHistory(project)).slice(-16).map((m) => `${m.role}: ${String(m.message || '').slice(0, 240)}`).join('\n');
    const activity = await projects.readMetadata(project, 'activity.json', []);
    const activityText = (Array.isArray(activity) ? activity.slice(-40) : []).map((a) => `${a.t || ''} ${a.action || ''} ${a.status || ''} ${String(a.detail || '').slice(0, 160)}`).join('\n');
    const handoff = await projects.readMetadata(project, 'handoff.json', {});
    const previousPlan = await projects.readMetadata(project, 'work-plan.json', {});
    const context = await collectProjectContext(source, message, 'chat');
    const attachContext = await attachmentContext(projects.projectDir(project));
    const requestedImage = extractGhcrImage(message);
    const installFromImage = Boolean(requestedImage && /(solohost|cài đặt|cai dat|install|docker-compose|config_options|file cài|tạo file|tao file|generate)/i.test(message));
    const incident = await triagePublishedIncident(project, message, runtimeNow, emit);
    const pendingRelease = await projects.readMetadata(project, 'release-pending.json', null);
    const waitingForImage = Boolean(pendingRelease?.githubUrl) && ['waiting_image', 'workflow_failed'].includes(String(pendingRelease?.status || ''));
    const asksPublishStatus = /publish|ghcr|github|check image|re-?check|xuất bản|xuat ban|ảnh|image/i.test(message);
    const incidentContext = incident?.evidence?.context ? `\n${incident.evidence.context}` : '';
    emit('ai', 'running', installFromImage ? 'Preparing SoloHost install files from the GitHub image…' : (incident?.handled ? 'Skipping AI: deterministic repair is being verified…' : 'AI is deciding the next best step…'));
    let r = { json: { action: inferAction(message) || 'reply', reply: '', commands: [] } };
    if (!incident?.handled && waitingForImage && asksPublishStatus) {
      r = {
        json: {
          action: 'publish',
          reply: pendingRelease.status === 'workflow_failed'
            ? 'GitHub already has the source. I will read the latest Actions result instead of editing the app again.'
            : 'GitHub already has the source. I will check whether the GHCR image is ready instead of changing the app.',
          steps: [{ action: 'publish', goal: 'Check the existing GitHub Actions / GHCR image without republishing source.' }],
        },
      };
    } else if (incident?.handled) {
      const verifiedPublishedIncident = Boolean(incident.evidence?.published && incident.evidence?.repoInfo?.repo);
      const needsFreshRun = runtimeNow?.status !== 'passed' || runtimeNow?.health !== true;
      const steps = verifiedPublishedIncident && incident.action === 'publish' && needsFreshRun
        ? [
          { action: 'run', goal: 'Run the repaired app and verify health before republishing the existing release.' },
          { action: 'publish', goal: incident.goal },
        ]
        : [{ action: incident.action, goal: incident.goal }];
      r = { json: { action: incident.action, reply: incident.reply, commands: [], steps } };
    } else {
      try {
        if (!installFromImage) {
          r = await ai.completeJson({
            task: 'USER_CHAT',
            system: SYSTEM,
            prompt: builderChatPrompt(project, message, `${languageInstruction(message)}\nHANDOFF:\n${JSON.stringify(handoff)}\nCURRENT WORK PLAN:\n${JSON.stringify(previousPlan)}\nACTIVITY LOG:\n${activityText}\nHISTORY:\n${history}\nDIAGNOSIS:\n${JSON.stringify(diagnosis)}\nRUNTIME:\n${JSON.stringify({ status: runtimeNow.status, error: runtimeNow.error, previewPath: runtimeNow.previewPath })}\n${incidentContext}\n${context}\n${attachContext}`, await attachmentList(projects.projectDir(project))),
            projectId: project.id,
            images: [...imageInputs(incomingFiles), ...(await imageInputsFromAttachments(projects.projectDir(project)))],
          });
        } else {
          r = { json: { action: 'export', reply: `Creating SoloHost install files for ${requestedImage}.`, commands: [], steps: [{ action: 'export', goal: message }] } };
        }
      } catch (err) {
        emit('ai', 'failed', friendlyAiError(err));
      }
    }
    let action = String(r.json?.action || inferAction(message) || 'reply');
    if (installFromImage) action = 'export';
    const failureLayer = classifyFailureLayer(message);
    if (failureLayer.layer && failureLayer.layer !== 'GENERATED_APP' && failureLayer.codeChange === false && action === 'improve') {
      action = 'analyze';
    }
    if (action === 'reply') {
      const inferred = inferAction(message);
      if (inferred && inferred !== 'reply') action = inferred;
    }
    const gated = gateAction(action, { files: diagnosis.files, runtime: runtimeNow, githubConfigured: github.configured(), imageRef: requestedImage });
    if (gated.lock) action = gated.action;
    const reply = [gated.lock, String(r.json?.reply || '')].filter(Boolean).join('\n');
    const skipped = [];
    for (const command of Array.isArray(r.json?.commands) ? r.json.commands.slice(0, 4) : []) {
      if (!command?.command) continue;
      if (isHostDockerCommand(command.command) || isNpmOnEmptyRisk(command.command)) {
        skipped.push(command.command);
        emit('sandbox', 'done', `Skipped raw command. I will use the built-in ${action} script instead.`);
        continue;
      }
    }
    let payload = { projectId: project.id, action, reply, skipped, reports: [] };
    const planned = [];
    if (Array.isArray(r.json?.steps) && r.json.steps.length > 1) {
      for (const step of r.json.steps.slice(0, 5)) {
        planned.push({ action: String(step.action || inferAction(step.goal || '') || action), goal: String(step.goal || message) });
      }
    } else {
      const pieces = splitUserSteps(message);
      if (pieces.length > 1) planned.push(...pieces.map((goal) => ({ action: inferAction(goal) || action, goal })));
      else planned.push({ action, goal: String(r.json?.feedback || message) });
    }
    const workPlan = await projects.startWorkPlan(project, {
      jobId: job.id,
      message,
      action,
      language: userLanguage,
      steps: planned.map((step) => ({ ...step, tests: step.action === 'improve' ? ['static checks', 'runtime tests', 'security scan', 'preview'] : [] })),
    });
    payload = { projectId: project.id, action, reply, skipped, reports: [], workPlanId: workPlan.id };
    emit('plan', 'done', `Plan ready: ${planned.length} step${planned.length === 1 ? '' : 's'}. Each step will be verified and recorded.`);
    // A failed prerequisite must not be followed by a dependent Run/Publish.
    // Independent safe analysis steps may still continue, but never let a later
    // successful preview hide an earlier failed repair.
    let prerequisiteFailed = false;
    if (action === 'question' && Array.isArray(r.json.questions) && r.json.questions.length) {
      await projects.saveMetadata(project, 'chat-question.json', { questions: r.json.questions });
      projects.setStatus(project, 'WAITING_INPUT');
      payload.questions = r.json.questions;
    } else {
      for (const [stepIndex, step] of planned.entries()) {
        const planStep = workPlan.steps[stepIndex];
        let stepAction = step.action;
        if (prerequisiteFailed && ['run', 'publish', 'export'].includes(stepAction)) {
          payload.reports.push({ action: stepAction, status: 'blocked', goal: step.goal, error: 'Blocked because the previous repair/build step failed.' });
          await projects.updateWorkPlan(project, {
            stepId: planStep.id,
            step: { status: 'blocked', error: 'Blocked because a previous required step failed.' },
            reports: payload.reports,
          });
          emit(stepAction, 'failed', `Skipped ${stepAction}: the previous required step failed. Fix that issue first.`);
          continue;
        }
        const gatedStep = gateAction(stepAction, { files: diagnosis.files, runtime: runtimeNow, githubConfigured: github.configured(), imageRef: requestedImage || extractGhcrImage(step.goal) });
        if (gatedStep.lock) stepAction = gatedStep.action;
        await projects.updateWorkPlan(project, { stepId: planStep.id, step: { status: 'running', action: stepAction } });
        try {
          if (stepAction === 'build') {
            emit('build', 'running', `Step: write files — ${step.goal.slice(0, 80)}`);
            const analysis = await projects.readMetadata(project, 'requirements.json', {});
            const plan = await projects.readMetadata(project, 'architecture.json', {});
            payload.built = await generateCode({ project, analysis, plan, emit, allowFallback: false });
          } else if (stepAction === 'improve') {
            emit('improve', 'running', `Step: targeted patch — ${step.goal.slice(0, 80)}`);
            const chatOrchPlan = await orchestrator.generatePlan({
              jobId: job.id,
              project,
              feedback: step.goal,
              language: userLanguage,
              runtime: runtimeNow,
            });
            payload.orchestratorPlan = chatOrchPlan;
            emit('plan', 'done', formatPlanChecklistText(chatOrchPlan));
            await snapshots.create(project, 'before-step-improve').catch(() => {});
            payload.result = await improveProject(project, step.goal, emit, { orchestratorPlan: chatOrchPlan });
            if (payload.result?.runtime) payload.runtime = payload.result.runtime;
            const stepOutcome = payload.result?.outcome || ((payload.result?.files || []).length ? OUTCOMES.DONE : OUTCOMES.NO_CHANGE);
            const stepApplied = stepOutcome === OUTCOMES.DONE || stepOutcome === OUTCOMES.PARTIAL;
            await orchestrator.finalize(project, chatOrchPlan, {
              outcome: stepOutcome,
              verified: stepApplied && payload.result?.runtime?.status === 'passed',
              summary: stepApplied
                ? (payload.result?.explanation || (userLanguage === 'Vietnamese' ? 'Đã sửa và kiểm chứng chạy thử.' : 'Patched and verified in live preview.'))
                : String(payload.result?.brief || payload.result?.explanation || stepOutcome).slice(0, 220),
            });
            payload.orchestratorPlan = chatOrchPlan;
          } else if (stepAction === 'run') {
            payload.runtime = await runWithRepair(project, emit, step.goal);
          } else if (stepAction === 'analyze') {
            emit('analyze', 'running', 'Checking files, crash logs, and security without changing code…');
            payload.tested = await inspectOnly(project, emit);
            payload.diagnosis = payload.tested.diagnosis || await diagnoseSource(source);
            if (runtimeNow.logs) payload.crash = classifyLogs(runtimeNow.logs || runtimeNow.error || '');
            const layerNow = classifyFailureLayer(step.goal || message);
            payload.layer = layerNow.layer || 'UNKNOWN';
            payload.layerReport = formatLayerDiagnosis({
              layer: payload.layer,
              message: step.goal || message,
              crash: payload.crash,
              next: layerNow.ask || 'I will not change app code until this layer is confirmed.',
            });
            emit('analyze', 'done', payload.layerReport);
          } else if (stepAction === 'export') {
            const image = extractGhcrImage(step.goal) || extractGhcrImage(message);
            const kind = image || /install|solohost|config|cài đặt|solo\s*host/i.test(step.goal) ? 'solohost' : 'project';
            if (image) {
              const ports = guessSoloHostPorts(step.goal, image);
              emit('release', 'running', `Writing SoloHost files for ${image}`);
              await writeSoloHostPackage({
                project,
                sourceDir: projects.sourceDir(project.slug),
                image,
                hostPort: ports.hostPort,
                containerPort: ports.containerPort,
              });
              payload.image = image;
              payload.installReady = true;
            }
            const artifact = await createProjectZip({ sourceDir: projects.sourceDir(project.slug), outputDir: path.join(projects.projectDir(project), 'artifacts'), slug: project.slug, kind });
            payload.downloads = [
              { kind, filename: artifact.filename, url: `/api/projects/${project.id}/download?kind=${kind}` },
              { kind: 'github-fallback', filename: 'GitHub-ZIP-Image-Publisher-v5.0.ps1', url: `/api/projects/${project.id}/github-fallback` },
            ];
          } else if (stepAction === 'publish') {
            emit('release', 'running', 'Publishing the app now…');
            const autoRepairRelease = Boolean(incident?.handled && incident?.evidence?.published && incident?.evidence?.repoInfo?.repo);
            payload.result = await runRelease(project, {
              approved: true,
              confirm: true,
              push: true,
              verifyImage: waitingForImage || payload.verifyImage === true,
              existingAction: autoRepairRelease ? 'overwrite' : 'confirm',
              repoName: autoRepairRelease ? incident.evidence.repoInfo.repo : undefined,
            }, emit);
            payload.publish_ready = payload.result?.status === 'released' || payload.result?.status === 'packaged';
          }
          let stepStatus = 'done';
          let stepError = '';
          if (stepAction === 'improve' && (payload.result?.outcome === OUTCOMES.ROLLED_BACK || payload.result?.outcome === OUTCOMES.NEEDS_ACTION)) {
            stepStatus = 'failed';
            stepError = payload.result?.outcomeInfo?.reason || 'Acceptance verification failed.';
          }
          if (stepAction === 'run' && payload.runtime?.status !== 'passed') {
            stepStatus = 'failed';
            stepError = payload.runtime?.error || 'Run did not produce a verified healthy runtime.';
          }
          if (stepAction === 'publish') {
            const publishStatus = String(payload.result?.status || '');
            if (publishStatus === 'waiting_github_actions' || publishStatus === 'needs_repository_choice') {
              stepStatus = 'waiting';
              stepError = payload.result?.next || 'Publish is waiting for the next required user/action step.';
            } else if (!['released', 'packaged'].includes(publishStatus)) {
              stepStatus = 'failed';
              stepError = payload.result?.brief || payload.result?.next || 'Publish did not reach a verified release state.';
            }
          }
          if (stepStatus === 'failed') prerequisiteFailed = true;
          payload.reports.push({ action: stepAction, status: stepStatus === 'waiting' ? 'blocked' : stepStatus, goal: step.goal, error: stepError });
          await projects.updateWorkPlan(project, {
            stepId: planStep.id,
            step: {
              status: stepStatus,
              action: stepAction,
              files: payload.result?.files || payload.built?.files || [],
              error: stepError || undefined,
              result: stepAction === 'improve' ? (payload.result?.explanation || 'Patch verified.') : (stepStatus === 'done' ? `${stepAction} completed.` : stepError),
            },
            reports: payload.reports,
          });
          if (stepStatus === 'done') emit(stepAction, 'done', `${stepAction} completed and verified.`);
          else if (stepStatus === 'waiting') emit(stepAction, 'done', stepError);
          else emit(stepAction, 'failed', stepError);
        } catch (err) {
          const error = String(err.message || err).slice(0, 240);
          payload.reports.push({ action: stepAction, status: 'failed', goal: step.goal, error });
          prerequisiteFailed = true;
          await projects.updateWorkPlan(project, {
            stepId: planStep.id,
            step: { status: 'failed', action: stepAction, error, notes: ['Dependent steps were blocked after this failure.'] },
            reports: payload.reports,
          });
          emit(stepAction, 'failed', `Step failed: ${error}`);
        }
      }
    }
    const planStatus = action === 'question' ? 'waiting_input' : (payload.reports.some((item) => item.status === 'failed' || item.status === 'blocked') ? 'failed' : 'done');
    const finishedPlan = await projects.finishWorkPlan(project, planStatus, planStatus === 'done'
      ? 'All planned steps completed and were recorded. Continue from this report instead of repeating earlier work.'
      : planStatus === 'waiting_input'
        ? 'Waiting for the user choices before build can continue.'
        : 'One or more steps failed. Completed work was kept only after verification; dependent steps were blocked.');
    payload.workPlan = finishedPlan;
    if (payload.result?.acceptance) payload.acceptance = payload.result.acceptance;
    if (payload.result?.alternatives) payload.alternatives = payload.result.alternatives;
    const latestRuntime = payload.runtime || payload.result?.runtime || await projects.readMetadata(project, 'runtime.json', {});
    if (action !== 'run') {
      await gcDocker({ keepImage: null, keepContainer: null, log }).catch(() => {});
    } else {
      await gcDocker({ keepImage: latestRuntime.image || null, keepContainer: latestRuntime.status === 'passed' ? latestRuntime.container : null, log }).catch(() => {});
    }
    payload.guide = payload.result?.guide || guideCard({ runtime: latestRuntime, findings: diagnosis.findings, action, publishReady: payload.publish_ready });
    payload.next = payload.result?.alternatives?.items?.[0]?.title
      ? (payload.result?.outcomeInfo?.next || payload.result.alternatives.items[0].title)
      : payload.guide.detail;
    if (payload.result?.brief && (action === 'improve' || payload.alternatives || payload.acceptance)) {
      payload.brief = payload.result.brief;
    } else {
      payload.brief = formatUserBrief({ action, runtime: latestRuntime, diagnosis, reply, next: payload.next, language: userLanguage, reports: payload.reports });
    }
    if (payload.layerReport) payload.brief = `${payload.layerReport}\n${payload.brief || ''}`.trim();
    await gcDocker({ keepImage: latestRuntime.image || null, keepContainer: latestRuntime.status === 'passed' ? latestRuntime.container : null, log }).catch(() => {});
    await projects.chat(project, payload.brief, 'assistant', { action, next: payload.next, acceptance: payload.acceptance || undefined, alternatives: payload.alternatives || undefined });
    const failCard = describeFailure({
      error: latestRuntime.error || payload.reports.find((s) => s.status === 'failed')?.error || '',
      logs: latestRuntime.logs || '',
      findings: diagnosis.findings || [],
      action,
    });
    payload.fix = failCard.fix;
    payload.copyForAi = latestRuntime.status === 'passed' ? null : failCard.copy;
    const prevActivity = Array.isArray(activity) ? activity : [];
    await projects.saveMetadata(project, 'activity.json', [
      ...prevActivity,
      {
        t: new Date().toISOString(),
        action,
        status: latestRuntime.status || (payload.reports.some((s) => s.status === 'failed') ? 'failed' : 'done'),
        detail: failCard.what,
        next: payload.next,
      },
    ].slice(-200));
    await projects.saveMetadata(project, 'handoff.json', {
      updatedAt: new Date().toISOString(),
      userLanguage,
      lastUserMessage: message,
      lastAction: action,
      lastBrief: payload.brief,
      next: payload.next,
      runtime: { status: latestRuntime.status, previewPath: latestRuntime.previewPath, error: latestRuntime.error },
      files: diagnosis.files.slice(0, 40),
      workPlan: {
        id: finishedPlan.id,
        status: finishedPlan.status,
        steps: finishedPlan.steps.map((item) => ({ id: item.id, action: item.action, goal: item.goal, status: item.status, files: item.files, error: item.error })),
      },
    });
    emit('guide', 'done', payload.next);
    return payload;
  });

  jobs.on('ask', async (job) => {
    const project = mustProject(job.payload.projectId);
    const question = String(job.payload.question || '').trim();
    if (!question) throw new Error('Ask a question first.');
    const userLanguage = detectUserLanguage(question);
    const sourceDir = projects.sourceDir(project.slug);
    const githubMeta = await projects.readMetadata(project, 'upgrade-source.json', {}).catch(() => ({}));
    const ctx = await buildAiProjectContext(project, {
      mode: 'ask',
      query: question,
      sourceDir,
      maxChars: 28000,
      meta: {
        sourceType: githubMeta?.repo || githubMeta?.url ? 'github' : 'local',
        commitSha: githubMeta?.commit || githubMeta?.ref || null,
        githubUrl: githubMeta?.url || githubMeta?.repo || null,
        branch: githubMeta?.branch || null,
        sourceHash: (await projects.readMetadata(project, 'upgrade-baseline.json', {}).catch(() => ({})))?.sourceHash || null,
      },
    });
    try {
      const r = await ai.completeJson({
        task: 'USER_CHAT',
        system: SYSTEM,
        prompt: `${languageInstruction(question)}\n${chatPrompt(project, question, ctx.text)}`,
        projectId: project.id,
      });
      return { ...(r.json || {}), contextSnapshot: ctx.snapshot };
    } catch (err) {
      return { reply: `AI response unavailable. ${friendlyAiError(err)}`, proposed_change: null, userLanguage };
    }
  });

  jobs.on('import_app', async (job, { emit }) => {
    const buf = job._zip;
    if (!buf) throw new Error('Upload a ZIP file.');
    emit('import', 'running', 'Reading the uploaded app…');
    let project;
    if (job.payload.projectId) {
      project = mustProject(job.payload.projectId);
      emit('snapshot', 'running', 'Saving a restore point…');
      await snapshots.create(project, 'before-zip-import');
    } else {
      const analysis = localAnalysis(job.payload.idea || job.payload.filename || 'Imported app');
      const plan = localPlan(job.payload.idea || 'Imported existing application', analysis);
      project = await projects.create({
        idea: job.payload.idea || `Imported ${job.payload.filename || 'app.zip'}`,
        name: analysis.name,
        analysis,
        plan,
      });
      jobs.attachProject(job.id, project.id);
    }
    const dest = projects.sourceDir(project.slug);
    // Capture working tree BEFORE this ZIP replaces it (for user-facing import diff).
    let beforeTree = null;
    try {
      beforeTree = await snapshotTree(dest);
      await projects.saveMetadata(project, 'import-diff-before.json', beforeTree);
    } catch { beforeTree = { entries: {}, fileCount: 0 }; }
    let stack;
    try {
      stack = await importZipBuffer(buf, dest, { replace: true });
    } catch (err) {
      // A replacement import is destructive to source, so restore the latest
      // checkpoint if unpacking/validation fails. New projects have no prior
      // checkpoint and can simply fail without affecting another project.
      if (job.payload.projectId) {
        const latest = snapshots.list(project.id)[0];
        if (latest?.id) await snapshots.restore(project, latest.id).catch(() => {});
      }
      throw err;
    }
    await projects.saveMetadata(project, 'requirements.json', { ...(await projects.readMetadata(project, 'requirements.json', {})), stack, imported: true, filename: job.payload.filename });
    // Diff: previous working tree vs this uploaded ZIP (now current)
    let importDiff = null;
    try {
      const afterTree = await snapshotTree(dest);
      await projects.saveMetadata(project, 'import-diff-after.json', afterTree);
      const beforeMeta = beforeTree || await projects.readMetadata(project, 'import-diff-before.json', { entries: {} });
      importDiff = diffTrees(beforeMeta, afterTree);
      await projects.saveMetadata(project, 'import-diff.json', {
        ...importDiff,
        filename: job.payload.filename || 'upload.zip',
        comparedAt: new Date().toISOString(),
        label: 'uploaded_zip_vs_previous_working_tree',
      });
      emit('import', 'done', formatDiffBrief(importDiff, { locale: 'en' }));
    } catch { /* non-fatal */ }
    await projects.saveMetadata(project, 'user-language.json', { language: detectUserLanguage(job.payload.idea || job.payload.filename || 'Imported app'), source: job.payload.idea || job.payload.filename || 'Imported app' });

    // Upgrade / external-AI path: accept the ZIP as the new source of truth.
    // Do NOT run Build-phase scan, DARE, deterministic repair, or security auto-fix.
    const originMeta = await projects.readMetadata(project, 'origin.json', {});
    const upgradeOriginMeta = await projects.readMetadata(project, 'upgrade-origin.json', null);
    const statusName = String(project.status || projects.get(project.id)?.status || '');
    const upgradeImport = Boolean(
      job.payload.upgrade === true
      || job.payload.mode === 'upgrade'
      || job.payload.skipRepair === true
      || originMeta?.origin === 'upgrade'
      || upgradeOriginMeta?.origin === 'upgrade'
      || statusName.startsWith('UPGRADE_')
      || job.payload.projectId // re-import into existing project = replace source for Upgrade/Publish, not Build
    );

    if (upgradeImport) {
      await projects.saveMetadata(project, 'origin.json', {
        ...(originMeta || {}),
        origin: 'upgrade',
        importedAt: new Date().toISOString(),
        filename: job.payload.filename || 'upload.zip',
      });
      await projects.saveMetadata(project, 'upgrade-origin.json', {
        ...(upgradeOriginMeta || {}),
        origin: 'upgrade',
        baselineHash: upgradeOriginMeta?.baselineHash || null,
        lastImportAt: new Date().toISOString(),
        lastImportFile: job.payload.filename || 'upload.zip',
        policy: 'accept-external-source-no-auto-repair',
      });
      // Clear stale security block state from prior Build runs so Publish is not stuck
      await projects.saveMetadata(project, 'security.json', {
        status: 'UPGRADE_ACCEPTED',
        critical: 0,
        summary: 'Upgrade import: security gate deferred. External AI changes accepted without Build repair.',
        findings: [],
        operationImpact: 'CONTINUE',
      });
      await projects.saveMetadata(project, 'test-plan.json', {
        status: 'upgrade-import-skipped',
        staticResult: { status: 'skipped' },
        nodeResult: { status: 'skipped' },
        note: 'Import in Upgrade mode does not run Build tests or DARE.',
      });
      projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
      emit('import', 'done',
        '✓ Upgrade import complete. External changes accepted as-is — no scan, DARE, or security auto-repair.\n'
        + 'Next: Run if you want a preview, then Publish. SoloHost package will sync on Publish.');
      return {
        projectId: project.id,
        stack,
        upgradeImport: true,
        tested: { skipped: true, reason: 'upgrade-origin' },
        summary: `Imported ${job.payload.filename || 'ZIP'} for Upgrade (no auto-repair). Stack: ${stack.language}.`,
        importDiff,
        compareAvailable: Boolean(importDiff),
      };
    }

    // 1.8.18: every ZIP import skips Build scan/DARE/repair — checks are for create_app only.
    await projects.saveMetadata(project, 'origin.json', {
      ...(originMeta || {}),
      origin: originMeta?.origin || 'import',
      importedAt: new Date().toISOString(),
      filename: job.payload.filename || 'upload.zip',
      policy: 'import-skip-checks',
    });
    await projects.saveMetadata(project, 'security.json', {
      status: 'IMPORT_ACCEPTED',
      critical: 0,
      summary: 'ZIP import: security/scan skipped. Validation runs only for apps created in Builder.',
      findings: [],
      operationImpact: 'CONTINUE',
    });
    await projects.saveMetadata(project, 'test-plan.json', {
      status: 'import-skipped',
      staticResult: { status: 'skipped' },
      nodeResult: { status: 'skipped' },
      note: 'Import ZIP does not run Build tests, DARE, or auto-repair.',
    });
    projects.setStatus(projects.get(project.id), 'UPGRADE_READY');
    emit('import', 'done',
      '✓ Import complete — checks skipped (scan/DARE/repair are for apps built in Builder only).\n'
      + 'Next: Run for a preview if you want, then Publish.');
    return {
      projectId: project.id,
      stack,
      importSkippedChecks: true,
      tested: { skipped: true, reason: 'import-origin' },
      summary: `Imported ${job.payload.filename || 'ZIP'} (checks skipped). Stack: ${stack.language}.`,
      importDiff,
      compareAvailable: Boolean(importDiff),
    };
  });

  jobs.on('apply_patch', async (job, { emit }) => {
    const project = mustProject(job.payload.projectId);
    const files = job.payload.files || [];
    emit('snapshot', 'running', 'Saving a restore point…');
    await snapshots.create(project, 'before-patch');
    emit('patch', 'running', 'Applying the change…');
    const checkpoint = await applySafeAiPatch({ sourceDir: projects.sourceDir(project.slug), files, project, snapshots, reason: 'apply-patch' });
    await stampMadeBy(projects.sourceDir(project.slug), cfg);
    await writeGithubWorkflow(projects.sourceDir(project.slug), project);
    const verified = await testAndMaybeFix(projects.get(project.id), emit);
    const failed = verified.staticResult?.status === 'failed' || verified.nodeResult?.status === 'failed' || verified.scan?.critical > 0 || verified.dockerBuild?.status === 'failed';
    if (failed && checkpoint?.snapshot?.id) {
      await snapshots.restore(project, checkpoint.snapshot.id).catch(() => {});
      emit('rollback', 'done', 'The explicit patch did not verify as a complete step forward, so the previous checkpoint was restored.');
      throw new Error('PATCH_ROLLED_BACK: the requested change did not pass verification. The previous working state is restored.');
    }
    return verified;
  });

  jobs.on('sandbox_demo', async (job, { emit }) => {
    emit('sandbox', 'running', 'Loading the Sandbox Benchmark demo…');
    const src = path.resolve(cfg.templatesDir || 'templates', 'sandbox-benchmark');
    const analysis = localAnalysis('Sandbox App Benchmark');
    const plan = localPlan('Prove HTML, JS, HTTP, filesystem and CPU in the preview sandbox.', analysis);
    const project = await projects.create({
      idea: 'Sandbox App Benchmark — prove preview before building a product app',
      name: 'Sandbox Benchmark',
      analysis,
      plan,
    });
    jobs.attachProject(job.id, project.id);
    const dest = projects.sourceDir(project.slug);
    await fs.cp(src, dest, { recursive: true });
    await stampMadeBy(dest, cfg).catch(() => {});
    emit('run', 'running', 'Starting the sandbox preview…');
    const runtime = await runProject(project, emit);
    await projects.saveMetadata(project, 'sandbox-probe.json', {
      ok: runtime.status === 'passed',
      at: new Date().toISOString(),
      previewPath: runtime.previewPath,
      error: runtime.error || null,
      internet: runtime.internet || null,
      interpretation: runtime.internet?.ok === false
        ? 'Sandbox outbound Internet is unavailable or blocked; diagnose the environment before changing product code.'
        : runtime.internet?.ok === true
          ? 'Sandbox outbound Internet is reachable; app-specific browsing issues should be diagnosed in the product gateway/proxy.'
          : 'Internet result unavailable.'
    });
    return {
      projectId: project.id,
      runtime,
      ui_url: runtime.previewPath,
      next: runtime.status === 'passed'
        ? 'Sandbox preview is ready. Open the test link, then build your own app.'
        : 'Sandbox preview failed. Fix Builder/preview first — this is not a product-app bug.',
    };
  });

  async function generateCode({ project, analysis, plan, emit, allowFallback = false }) {
    projects.setStatus(project, 'BUILDING');
    const dest = projects.sourceDir(project.slug);
    let written = [];
    let usedFallback = false;
    let phaseReport = [];
    try {
      emit('code', 'running', 'Building in 3 phases (foundation → product → polish)…');
      const multi = await generateCodeMultiPhase({
        ai,
        project,
        plan,
        dest,
        emit,
        allowFallback: false,
        singleShotPrompt: codePrompt(project, plan),
      });
      written = multi.files || [];
      phaseReport = multi.phases || [];
      await projects.saveMetadata(project, 'codegen-phases.json', { phases: phaseReport, at: new Date().toISOString() }).catch(() => {});
      const scaffolded = await ensureBoilerplate(dest).catch(() => []);
      if (scaffolded?.length) written = [...new Set([...written, ...scaffolded])];
    } catch (err) {
      if (!allowFallback) throw new Error(`AI code generation failed: ${friendlyAiError(err)}`);
      usedFallback = true;
      emit('code', 'running', 'Loading the optional demo starter…');
      written = await scaffoldFromTemplate(cfg.templatesDir, dest, {
        name: project.name, slug: project.slug, summary: analysis.summary || project.idea, idea: project.idea,
      });
      log.warn('Code generation used template', { error: err.message });
    }
    await stampMadeBy(dest, cfg);
    await ensureMissingDependencies(dest).catch(() => ({ changed: false }));
    await writeGithubWorkflow(dest, project);
    await snapshots.create(project, 'after-generate');
    const allocatedPort = await stableHostPort(project, null, dest);
    const pkg = await writeSoloHostPackage({
      project,
      sourceDir: dest,
      image: `paf-app:${project.slug}`,
      hostPort: allocatedPort,
    }).catch(() => null);
    const tested = await testAndMaybeFix(projects.get(project.id), emit);
    const imageFile = tested.imageFile?.status === 'passed' ? tested.imageFile : null;
    return { files: written, fallback: usedFallback, tested, e2e: tested.e2e || null, image: null, imageFile: null, downloads: [], next: tested.next };
  }

  async function testAndMaybeFix(project, emit) {
    const source = projects.sourceDir(project.slug);
    emit('test', 'running', 'Checking that the files look complete…');
    projects.setStatus(project, 'TESTING');
    let staticResult = await runStaticTests(source);
    // 1.8.9: deterministic boilerplate (Dockerfile, .env.example, README, smoke test...) is generated locally BEFORE
    // any repair attempt — a missing file must never cost an AI call or end in a project that cannot build.
    if (staticResult.status === 'failed') {
      const generated = await ensureBoilerplate(source).catch(() => []);
      if (generated.length) {
        emit('repair', 'done', `Generated missing standard files locally (no AI needed): ${generated.join(', ')}`);
        staticResult = await runStaticTests(source);
      }
    }
    let nodeResult = await runNodeTests(source, 45000);
    let attempts = 0;
    let dareAttempts = 0;
    const dareHistory = await projects.readMetadata(project, 'dare-history.json', []);
    let savedDareHistory = Array.isArray(dareHistory) ? dareHistory : [];

    // Deterministic-first: exhaust a provable repair before spending an AI repair attempt.
    // The checkpoint is created before DARE touches source so a regression can be restored.
    while (staticResult.status === 'failed' || nodeResult.status === 'failed') {
      const errText = [failSummary(staticResult), nodeResult.error].filter(Boolean).join('\n');
      if (dareAttempts < 2) {
        dareAttempts += 1;
        emit('repair', 'running', `Checking deterministic fixes first (${dareAttempts}/2)…`);
        const beforeFailureScore = failureScore(staticResult, nodeResult);
        const checkpoint = await snapshots.create(project, `before-dare-${dareAttempts}`).catch(() => null);
        try {
          const dare = await runDare({
            sourceDir: source,
            logs: errText,
            extra: { message: nodeResult.error || '' },
            history: savedDareHistory,
          });
          savedDareHistory = (dare.history || []).slice(-20);
          await projects.saveMetadata(project, 'dare-history.json', savedDareHistory);
          if (dare.ok) {
            const afterStatic = await runStaticTests(source);
            const afterNode = await runNodeTests(source, 45000);
            const afterFailureScore = failureScore(afterStatic, afterNode);
            if (afterFailureScore <= beforeFailureScore) {
              staticResult = afterStatic;
              nodeResult = afterNode;
              emit('repair', 'done', `${formatDareReport(dare)}\n✓ Post-repair checks completed.`);
              if (staticResult.status !== 'failed' && nodeResult.status !== 'failed') break;
              continue;
            }
            if (checkpoint?.id) await snapshots.restore(project, checkpoint.id).catch(() => {});
            emit('rollback', 'done', 'Deterministic repair did not improve verification. Checkpoint restored; next strategy will be tried.');
            staticResult = await runStaticTests(source);
            nodeResult = await runNodeTests(source, 45000);
          } else if (dare.userAction) {
            emit('repair', 'done', formatDareReport(dare));
            break;
          }
        } catch (err) {
          if (checkpoint?.id) await snapshots.restore(project, checkpoint.id).catch(() => {});
          emit('repair', 'failed', `Deterministic repair check stopped safely: ${String(err.message || err).slice(0, 240)}`);
        }
      }

      if ((staticResult.status !== 'failed' && nodeResult.status !== 'failed') || attempts >= cfg.limits.maxAutoFixes) break;

      attempts += 1;
      emit('repair', 'running', `Trying a safe AI fix (${attempts}/${cfg.limits.maxAutoFixes})…`);
      projects.setStatus(project, 'REPAIRING');
      const relevant = await collectRelevant(source);
      let checkpoint = null;
      try {
        const r = await ai.completeJson({
          task: 'DEBUGGING',
          system: SYSTEM,
          prompt: `${patchPrompt(project, errText, relevant)}\nDETERMINISTIC REPAIR NOTE: DARE has already been attempted for this evidence. Do not repeat the same deterministic patch; change only the minimum files required for a new root cause.`,
          projectId: project.id,
        });
        if (r.json?.files?.length) checkpoint = await applySafeAiPatch({ sourceDir: source, files: r.json.files, project, snapshots, reason: `before-fix-${attempts}` });
      } catch (err) {
        emit('repair', 'failed', friendlyAiError(err));
        break;
      }
      const beforeFailureScore = failureScore(staticResult, nodeResult);
      staticResult = await runStaticTests(source);
      nodeResult = await runNodeTests(source, 45000);
      const afterFailureScore = failureScore(staticResult, nodeResult);
      if (checkpoint?.snapshot?.id && afterFailureScore > beforeFailureScore) {
        await snapshots.restore(project, checkpoint.snapshot.id).catch(() => {});
        emit('rollback', 'done', 'AI repair made checks worse. Previous working state restored; Builder continues with other safe options if available.');
        staticResult = await runStaticTests(source);
        nodeResult = await runNodeTests(source, 45000);
      }
      if (staticResult.status !== 'failed' && nodeResult.status !== 'failed') break;
    }
    emit('security', 'running', 'Looking for secrets and unsafe settings…');
    let scan = await scanProject(source);
    let securityRepair = null;
    // Safe, deterministic gate: if every blocking finding explicitly permits
    // automatic repair, let the repair AI attempt one targeted fix immediately.
    // This keeps ordinary users from having to copy a security report manually.
    if (scan.critical > 0 && scan.findings.every((f) => f.autoFix)) {
      emit('repair', 'running', 'A safe security fix is available. Applying one targeted repair…');
      let securityCheckpoint = null;
      try {
        const relevant = await collectProjectContext(source, 'security repair', 'improve');
        const r = await ai.completeJson({
          task: 'SECURITY',
          system: SYSTEM,
          prompt: patchPrompt(project, scan.copy_for_ai, relevant, 'Automatically repair the blocking security findings above. Change only the affected files. Preserve all existing app behavior.'),
          projectId: project.id,
        });
        if (!r.json?.files?.length) throw new Error('AI did not return a safe security patch.');
        securityCheckpoint = await applySafeAiPatch({ sourceDir: source, files: r.json.files, project, snapshots, reason: 'before-security-fix' });
        const afterSecurityStatic = await runStaticTests(source);
        const afterSecurityNode = await runNodeTests(source, 45000);
        const afterSecurityScan = await scanProject(source);
        const securityWorse = afterSecurityScan.critical > scan.critical
          || failureScore(afterSecurityStatic, afterSecurityNode) > failureScore(staticResult, nodeResult);
        if (securityWorse || afterSecurityScan.critical > 0) {
          await snapshots.restore(project, securityCheckpoint.snapshot.id).catch(() => {});
          emit('rollback', 'done', 'The automatic security change was not a verified step forward, so the previous checkpoint was restored.');
          scan = await scanProject(source);
          securityRepair = { status: 'rolled_back', files: r.json.files.map((f) => f.path), reason: 'Security/runtime verification did not pass.' };
        } else {
          securityRepair = { status: 'attempted', files: r.json.files.map((f) => f.path) };
          scan = afterSecurityScan;
          staticResult = afterSecurityStatic;
          nodeResult = afterSecurityNode;
          emit('security', 'done', '✓ Security issue fixed and re-scanned.');
        }
      } catch (err) {
        if (securityCheckpoint?.snapshot?.id) await snapshots.restore(project, securityCheckpoint.snapshot.id).catch(() => {});
        securityRepair = { status: 'failed', error: String(err.message || err).slice(0, 500) };
        emit('repair', 'failed', `Security repair could not be applied automatically: ${securityRepair.error}`);
      }
    }
    await projects.saveMetadata(project, 'security.json', { ...scan, repair: securityRepair });
    if (scan.critical > 0) {
      emit('security', 'failed', scan.copy_for_ai);
      throw new Error(`RELEASE_SECURITY_BLOCKED\n${scan.copy_for_ai}\nNEXT: Fix the blocking security issue, then Run/Publish again.`);
    }
    emit('preview', 'running', 'Starting a safe preview without host Docker access…');
    let dockerBuild = await runner.run({ sourcePath: source, projectSlug: project.slug, timeout: cfg.limits.sandboxTimeoutSec });
    if (dockerBuild.status === 'failed' && dockerBuild.e2e?.status === 'failed' && attempts < cfg.limits.maxAutoFixes && hasConfiguredAi(ai, cfg)) {
      const ev = dockerBuild.e2e?.evidence || {};
      const browserEvidence = [
        dockerBuild.error || dockerBuild.e2e?.error || 'Preview browser check failed.',
        ev.pageErrors?.length ? `Uncaught page errors: ${ev.pageErrors.slice(0, 4).join(' | ')}` : '',
        ev.consoleErrors?.length ? `Console errors: ${ev.consoleErrors.slice(0, 4).join(' | ')}` : '',
        ev.failedRequests?.length ? `Failed requests: ${ev.failedRequests.slice(0, 4).map((r) => `${r.status || 'ERR'} ${r.method || 'GET'} ${r.url}`).join(' | ')}` : '',
      ].filter(Boolean).join('\n');
      attempts += 1;
      emit('repair', 'running', `Live preview found browser errors — applying targeted fix (${attempts}/${cfg.limits.maxAutoFixes})…`);
      const relevant = await collectRelevant(source);
      let checkpoint = null;
      try {
        const r = await ai.completeJson({
          task: 'DEBUGGING',
          system: SYSTEM,
          prompt: `${patchPrompt(project, browserEvidence, relevant)}\nFix only the browser/API runtime error observed during live preview.`,
          projectId: project.id,
        });
        if (r.json?.files?.length) {
          checkpoint = await applySafeAiPatch({ sourceDir: source, files: r.json.files, project, snapshots, reason: `before-e2e-fix-${attempts}` });
          await stampMadeBy(source, cfg);
          const nextStatic = await runStaticTests(source);
          const nextNode = await runNodeTests(source, 45000);
          const nextScan = await scanProject(source);
          const nextPreview = await runner.run({ sourcePath: source, projectSlug: project.slug, timeout: cfg.limits.sandboxTimeoutSec });
          if (nextPreview.status === 'passed' && nextStatic.status !== 'failed' && nextNode.status !== 'failed' && nextScan.critical === 0) {
            staticResult = nextStatic;
            nodeResult = nextNode;
            scan = nextScan;
            dockerBuild = nextPreview;
            emit('repair', 'done', '✓ Targeted browser fix verified in live preview.');
          } else if (checkpoint?.snapshot?.id) {
            await snapshots.restore(project, checkpoint.snapshot.id).catch(() => {});
          }
        }
      } catch {
        if (checkpoint?.snapshot?.id) await snapshots.restore(project, checkpoint.snapshot.id).catch(() => {});
      }
    }
    const imageFile = null;
    await projects.saveMetadata(project, 'test-plan.json', { staticResult, nodeResult, scan, preview: dockerBuild, dockerBuild, e2e: dockerBuild.e2e || null, imageFile, securityRepair });
    const ok = staticResult.status === 'passed' && nodeResult.status !== 'failed' && scan.critical === 0 && dockerBuild.status === 'passed';
    projects.setStatus(project, ok ? 'WAITING_APPROVAL' : 'FAILED');
    if (ok) {
      // 1.8.9: only claim what actually ran (this used to say "Playwright E2E passed" even when the browser test failed or was absent).
      const e2eOk = dockerBuild.e2e?.status === 'passed';
      const ran = ['Source checks', 'security', 'preview', ...(e2eOk ? ['browser E2E'] : [])];
      const notes = [];
      if (!e2eOk) notes.push('The browser E2E test was not run on this device.');
      if (nodeResult?.unverified) notes.push(`Automated tests could not run here (${String(nodeResult.reason || 'environment').slice(0, 120)}) — not fully verified.`);
      emit('test', 'done', `✓ ${ran.join(', ')} passed.${notes.length ? ' ' + notes.join(' ') : ''}`);
    }
    return { staticResult, nodeResult, scan, dockerBuild, e2e: dockerBuild.e2e || null, imageFile, autoFixes: attempts, securityRepair, next: ok ? 'Open the preview with Run, Improve if needed, or Publish when ready.' : 'Fix the blocking issue shown above, then Run again.' };
  }

  async function review(project) {
    try {
      const files = await projects.sourceFiles(project);
      const r = await ai.completeJson({
        task: 'CODE_REVIEW',
        system: SYSTEM,
        prompt: reviewPrompt(project, { files }),
        projectId: project.id,
      });
      return r.json;
    } catch {
      const scan = await projects.readMetadata(project, 'security.json', {});
      const tests = await projects.readMetadata(project, 'test-plan.json', {});
      const functionality = tests.staticResult?.status === 'passed' ? 90 : 60;
      const security = scan.critical ? 40 : scan.warning ? 80 : 95;
      return {
        functionality, security, reliability: 88, performance: 86, documentation: 90,
        overall: Math.round((functionality + security + 88 + 86 + 90) / 5),
        verdict: scan.critical ? 'BLOCK' : 'PASS',
        findings: scan.findings || [],
        source: 'heuristic',
      };
    }
  }


  async function releaseFailureGuide(project, error, context = '') {
    const lang = (await projects.readMetadata(project, 'user-language.json', {})).language || detectUserLanguage(project.idea);
    try {
      const r = await ai.completeJson({
        task: 'DEBUGGING',
        system: SYSTEM,
        prompt: `${languageInstructionFor(lang)}\nA release operation failed. App Builder already attempted its own internal automatic retries for transient GitHub state before surfacing this error — so if you are seeing this message, those retries did NOT resolve it. Diagnose it for a non-technical user.\nSTRICT RULES:\n- Do NOT say "I have already fixed it" or "please try again" or "the repository now has content" — those retries already happened and still failed, so repeating that claim would be misleading.\n- Do NOT tell the user to click Publish again as the primary fix unless the error is genuinely transient (rate limit, server error) — for anything else, retrying the same action will fail the same way again.\n- If the error code is 'auth', 'permission', 'PROJECT_EMPTY', or 'BLOCK_PUSH', name the exact thing to check (token scope, repo access, missing files) as the next action.\n- If the error is truly transient (rate_limit, server), say to wait briefly and retry.\n- Keep it to one or two sentences, plain language, one concrete action.\nERROR CODE: ${error?.code || 'unknown'}\nERROR: ${String(error?.message || error).slice(0, 1600)}\nCONTEXT: ${context.slice(0, 2500)}\nReturn JSON: {"reply":"short diagnosis and next action"}.`,
        projectId: project.id,
      });
      return String(r.json?.reply || '').trim();
    } catch { return ''; }
  }

  function sanitizeRuntimeForMeta(rt) {
    if (!rt || typeof rt !== 'object') return rt;
    if (!rt.e2e?.evidence) return rt;
    const { beforeDataUrl: _b, afterDataUrl: _a, ...cleanEvidence } = rt.e2e.evidence;
    return { ...rt, e2e: { ...rt.e2e, evidence: cleanEvidence } };
  }

  async function runProject(project, emit, opts = {}) {
    const source = projects.sourceDir(project.slug);
    const runtime = await runner.runApp({
      sourcePath: source,
      projectSlug: project.slug,
      timeout: cfg.limits.sandboxTimeoutSec,
      keepRunning: true,
      acceptancePlan: opts?.acceptancePlan || null,
      captureImages: Boolean(opts?.captureImages),
    });
    const cleanRuntime = sanitizeRuntimeForMeta(runtime);
    await projects.saveMetadata(project, 'runtime.json', { ...cleanRuntime, image: cleanRuntime.image || null, lastSeenAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
    const tests = await projects.readMetadata(project, 'test-plan.json', {});
    await projects.saveMetadata(project, 'test-plan.json', { ...tests, preview: cleanRuntime });
    projects.setStatus(project, runtime.status === 'passed' ? 'WAITING_APPROVAL' : 'FAILED');
    if (runtime.status === 'passed') {
      runtime.previewPath = runtime.previewPath || `/preview/${project.slug}/`;
      runtime.brief = briefRun(runtime);
      emit('run', 'done', `RESULT: App is running. Open ${runtime.previewPath}`);
    } else {
      runtime.brief = briefFail(runtime.error || runtime.reason || 'The app could not start.');
      emit('run', 'failed', runtime.brief);
    }
    return runtime;
  }

  async function inspectOnly(project, emit) {
    const source = projects.sourceDir(project.slug);
    const diagnosis = await diagnoseSource(source);
    const staticResult = await runStaticTests(source);
    const nodeResult = await runNodeTests(source, 45000);
    const scan = await scanProject(source);
    emit('analyze', staticResult.status === 'passed' && nodeResult.status !== 'failed' && scan.critical === 0 ? 'done' : 'failed',
      `INSPECT ONLY: source ${staticResult.status}; runtime tests ${nodeResult.status}; security critical ${scan.critical}.`);
    return { staticResult, nodeResult, scan, diagnosis, inspectOnly: true };
  }


  async function loadSoloHostFilesForUi(sourceDir) {
    const pairs = [
      ['solohost/docker-compose.yml', 'solohost/config_options.yml'],
      ['solohost-kit/docker-compose.yml', 'solohost-kit/config_options.yml'],
      ['docker-compose.yml', 'config_options.yml'],
    ];
    for (const [cRel, kRel] of pairs) {
      const compose = await fs.readFile(path.join(sourceDir, cRel), 'utf8').catch(() => '');
      const config = await fs.readFile(path.join(sourceDir, kRel), 'utf8').catch(() => '');
      if (String(compose).trim() && String(config).trim()) {
        return {
          compose: String(compose).trim(),
          config: String(config).trim(),
          filenames: ['docker-compose.yml', 'config_options.yml'],
          source: cRel.includes('/') ? cRel.split('/')[0] : 'root',
        };
      }
    }
    return null;
  }

  function isSoloHostFileRequest(text) {
    return /\b(solohost|config_options\.yml|docker-compose\.yml|install kit|bộ cài|file cài|gói cài)\b/i.test(String(text || ''));
  }

  async function improveProject(project, feedback, emit, opts = {}) {
    const taskCtx = createTaskContext({
      taskType: 'IMPROVE',
      originalRequest: feedback,
      projectId: project?.id,
      projectSlug: project?.slug,
      protectedFiles: ['Dockerfile', 'docker-compose.yml', 'config_options.yml'],
    });
    return runWithTaskContext(taskCtx, () => improveProjectInner(project, feedback, emit, taskCtx, opts));
  }

  async function improveProjectInner(project, feedback, emit, taskCtx, opts = {}) {
    const orchPlan = opts?.orchestratorPlan || null;
    try {
      updateTaskProgress({ currentStage: 'analyze', pendingTasks: ['inspect', 'patch', 'verify'] });
      appendTaskEvent({ type: 'task_start', summary: String(feedback || '').slice(0, 240) });
      await saveTaskCheckpoint(projects, project, taskCtx).catch(() => {});
    } catch { /* non-fatal */ }
    const source = projects.sourceDir(project.slug);
    // Fast path: optimize SoloHost install files without full app repair.
    if (isSoloHostFileRequest(feedback) && /\b(tối ưu|toi uu|optimize|minimal|rút gọn|rut gon|đơn giản|don gian|chỉ.*password|only.*password|2 field|hai trường)\b/i.test(String(feedback || ''))
      || (isSoloHostFileRequest(feedback) && /\b(solo\s*host|config_options|docker-compose)\b/i.test(String(feedback || '')) && /\b(sửa|sua|fix|update|optimize|tối ưu)\b/i.test(String(feedback || '')))) {
      try {
        if (orchPlan) await orchestrator.start(project, orchPlan, 'apply_patch', 'SoloHost config optimization');
        emit('package', 'running', 'Optimizing SoloHost install files (≤2 form fields)…');
        const originMeta = await projects.readMetadata(project, 'origin.json', {});
        const imageGuess = String(
          (await projects.readMetadata(project, 'release.json', {}))?.github?.image
          || (await projects.readMetadata(project, 'image.json', {}))?.image
          || '',
        ).trim();
        const pkg = await writeSoloHostPackage({
          project,
          sourceDir: source,
          image: imageGuess || undefined,
          preferLatestImage: true,
          minimalInstallFields: true,
        });
        const solohostFiles = await loadSoloHostFilesForUi(source);
        if (orchPlan) {
          await orchestrator.complete(project, orchPlan, 'apply_patch', 'solohost/docker-compose.yml + config_options.yml');
          await orchestrator.skip(project, orchPlan, 'verify_checks');
          await orchestrator.skip(project, orchPlan, 'live_browser_qa');
        }
        emit('package', 'done', pkg?.ok
          ? 'SoloHost install kit optimized. Copy the two files below into SoloHost.'
          : 'SoloHost kit written with best-effort defaults.');
        return {
          feedback,
          explanation: 'SoloHost docker-compose.yml + config_options.yml refreshed (form capped at 2 fields).',
          brief: 'SoloHost install files ready to copy.',
          files: ['solohost/docker-compose.yml', 'solohost/config_options.yml'],
          solohostFiles,
          tested: { skipped: true },
          outcome: 'APPLIED',
        };
      } catch (err) {
        emit('package', 'failed', String(err.message || err).slice(0, 300));
        // fall through to normal improve
      }
    }

    const language = detectUserLanguage(feedback);
    if (orchPlan) await orchestrator.start(project, orchPlan, 'acceptance_criteria');
    const acceptancePlan = buildAcceptancePlan({ feedback, project, language });
    const acceptanceSummary = formatAcceptancePlanSummary(acceptancePlan, language);
    await projects.saveMetadata(project, 'acceptance.json', acceptancePlan).catch(() => {});
    if (orchPlan) await orchestrator.complete(project, orchPlan, 'acceptance_criteria', `${acceptancePlan.criteria?.length || 0} criteria`);
    emit('plan', 'done', acceptanceSummary);

    const networkRequest = /\b(internet|offline|online|network|dns|proxy|gateway|browse|browsing|fetch|connection|kết nối|mạng|internet|truy cập web)\b/i.test(String(feedback || ''));
    let networkPreflight = null;
    if (networkRequest) {
      emit('network', 'running', 'Checking Builder network before changing app code…');
      networkPreflight = await checkBuilderInternet();
      if (!networkPreflight.ok) {
        const message = `BUILDER_NETWORK_BLOCKED\n${networkPreflight.summary}\n${networkPreflight.remediation}`;
        emit('network', 'failed', message);
        throw new Error(message);
      }
      emit('network', 'done', `Builder Internet OK (${networkPreflight.httpsOk}/${networkPreflight.targets.length}).`);
    }
    const runtimeState = await projects.readMetadata(project, 'runtime.json', {});
    const problemFingerprint = repairFingerprint({ feedback, runtime: runtimeState });
    const guard = await projects.readMetadata(project, 'action-guard.json', null);

    // Deterministic-first: a concrete runtime fingerprint must go through DARE
    // before AI is allowed to touch source code. This is especially important
    // for SoloHost container failures such as EACCES.
    if (orchPlan) await orchestrator.start(project, orchPlan, 'deterministic_check');
    const dareHistory = await projects.readMetadata(project, 'dare-history.json', []);
    const dareCheckpoint = await snapshots.create(project, 'before-improve-dare').catch(() => null);
    let dare = null;
    try {
      dare = await runDare({
        sourceDir: source,
        logs: `${feedback}\n${runtimeState?.error || ''}\n${runtimeState?.logs || ''}\n${runtimeState?.brief || ''}`,
        extra: runtimeState || {},
        history: Array.isArray(dareHistory) ? dareHistory : [],
      });
      await projects.saveMetadata(project, 'dare-history.json', (dare.history || []).slice(-20));
      if (dare.ok || dare.alreadyFixed || dare.next === 'CONTINUE') {
        if (dare.ok) emit('repair', 'done', formatDareReport(dare));
        else emit('repair', 'done', `✓ Deterministic runtime contract already applied. ${dare.reason || 'No source patch is needed.'}`);
        const afterStatic = await runStaticTests(source);
        const afterNode = await runNodeTests(source, 45000);
        const afterScan = await scanProject(source);
        if (afterStatic.status === 'passed' && afterNode.status !== 'failed' && afterScan.critical === 0) {
          if (orchPlan) {
            await orchestrator.complete(project, orchPlan, 'deterministic_check', dare.reason || 'DARE verified');
            await orchestrator.skip(project, orchPlan, 'apply_patch', 'Fixed deterministically');
            await orchestrator.complete(project, orchPlan, 'verify_checks', 'Static + tests + security OK');
            await orchestrator.start(project, orchPlan, 'live_browser_qa');
          }
          const repairedRuntime = await runProject(projects.get(project.id), emit, { acceptancePlan });
          const dareAcceptance = evaluateAcceptance({ plan: acceptancePlan, e2e: repairedRuntime?.e2e, runtime: repairedRuntime, language });
          if (repairedRuntime?.status === 'passed' && (dareAcceptance.passed || (!acceptancePlan.strictInteraction && !dareAcceptance.failedCriteria?.length))) {
            if (orchPlan) await orchestrator.complete(project, orchPlan, 'live_browser_qa', dareAcceptance.summaryText);
            await projects.saveMetadata(project, 'action-guard.json', null);
            await projects.saveMetadata(project, 'acceptance.json', { ...acceptancePlan, evaluation: dareAcceptance, passed: true }).catch(() => {});
            return { feedback, rootCause: dare.reason || '', explanation: dare.reason || 'Deterministic runtime repair verified.', brief: `${dare.reason || 'Verified'}\n\n${dareAcceptance.summaryText}`, files: dare.files || [], tested: { staticResult: afterStatic, nodeResult: afterNode, scan: afterScan }, runtime: repairedRuntime, acceptance: dareAcceptance, dare };
          }
        }
        if (dareCheckpoint?.id) await snapshots.restore(project, dareCheckpoint.id).catch(() => {});
        emit('rollback', 'done', 'Deterministic repair did not reach a verified running state. Checkpoint restored; Builder is trying the next safe strategy.');
      }
    } catch (err) {
      if (dareCheckpoint?.id) await snapshots.restore(project, dareCheckpoint.id).catch(() => {});
      emit('repair', 'failed', `Deterministic repair stopped safely: ${String(err.message || err).slice(0, 240)}`);
    }
    if (orchPlan) await orchestrator.complete(project, orchPlan, 'deterministic_check', language === 'Vietnamese' ? 'Chuyển sang AI chẩn đoán & vá mã' : 'Proceeding to AI diagnosis & patch');

    // If an identical request already exhausted full live-browser repair attempts recently,
    // verify once more in the live browser and return structured optimal alternatives instead of blindly repeating edits.
    if (guard?.exhausted === true && shouldBlockRepeatedAction(guard, problemFingerprint)) {
      if (orchPlan) await orchestrator.start(project, orchPlan, 'live_browser_qa');
      const liveCheck = await runProject(projects.get(project.id), emit, { acceptancePlan, captureImages: true }).catch(() => null);
      const liveEval = evaluateAcceptance({ plan: acceptancePlan, e2e: liveCheck?.e2e, runtime: liveCheck, language });
      if (liveEval.passed) {
        if (orchPlan) await orchestrator.complete(project, orchPlan, 'live_browser_qa', liveEval.summaryText);
        await projects.saveMetadata(project, 'action-guard.json', null);
        await projects.saveMetadata(project, 'acceptance.json', { ...acceptancePlan, evaluation: liveEval, passed: true }).catch(() => {});
        const okBrief = `${liveEval.summaryText}`;
        return { feedback, rootCause: '', explanation: okBrief, brief: okBrief, files: [], tested: { preview: liveCheck }, runtime: liveCheck, acceptance: liveEval, outcome: OUTCOMES.DONE };
      }
      if (orchPlan) await orchestrator.fail(project, orchPlan, 'live_browser_qa', liveEval.summaryText);
      const alternatives = await buildOptimalAlternatives({ feedback, evaluation: liveEval, attempts: Number(guard.attempts || 1), lastFailure: liveEval.failureEvidence || liveCheck?.error || '', language, ai, project });
      await projects.saveMetadata(project, 'acceptance.json', { ...acceptancePlan, evaluation: liveEval, alternatives }).catch(() => {});
      const briefText = [liveEval.summaryText, formatAlternativesMessage(alternatives, language)].filter(Boolean).join('\n\n');
      emit('verify', 'failed', briefText);
      await projects.chat(project, briefText, 'assistant', { action: 'alternatives', fingerprint: problemFingerprint, acceptance: liveEval, alternatives });
      return {
        feedback,
        rootCause: '',
        explanation: briefText,
        brief: briefText,
        files: [],
        tested: { preview: liveCheck },
        runtime: liveCheck,
        acceptance: liveEval,
        alternatives,
        outcome: OUTCOMES.NEEDS_ACTION,
        outcomeInfo: outcomeBrief({
          outcome: OUTCOMES.NEEDS_ACTION,
          reasonEn: alternatives.summary || 'Automated repair attempts are exhausted for this identical problem.',
          reasonVi: alternatives.summary || 'Các lượt tự sửa cho lỗi giống hệt trước đó chưa đạt nghiệm thu.',
          nextEn: alternatives.items?.[0]?.title || 'Try one of the recommended options below.',
          nextVi: alternatives.items?.[0]?.title || 'Hãy chọn một trong các phương án tối ưu bên dưới.',
        }, language),
      };
    }
    await projects.saveMetadata(project, 'action-guard.json', { ...nextRepeatState(guard, problemFingerprint), acceptanceAttempted: true, exhausted: false });

    if (orchPlan) await orchestrator.start(project, orchPlan, 'reproduce_inspect');
    const relevant = await collectProjectContext(source, feedback, 'improve');
    const attachContext = await attachmentContext(projects.projectDir(project));
    const attachList = await attachmentList(projects.projectDir(project));
    const security = await scanProject(source);
    const baselineDiagnosis = await diagnoseSource(source);
    const baselineStatic = await runStaticTests(source);
    const baselineNode = await runNodeTests(source, 45000);
    const baselineScore = failureScore(baselineStatic, baselineNode);
    const activity = await projects.readMetadata(project, 'activity.json', []);
    const recentJobs = jobs.list({ projectId: project.id, limit: 8 }).map((row) => {
      const full = jobs.get(row.id) || row;
      return { id: row.id, type: row.type, status: row.status, stage: row.stage, error: row.error, events: (full.events || []).slice(-6) };
    });
    // 1.8.9 prompt diet: a short digest instead of raw job/event JSON (same evidence, ~80% fewer tokens).
    const jobsDigest = recentJobs.slice(0, 5).map((j) => `- ${j.type} ${j.status}${j.error ? `: ${String(j.error).slice(0, 160)}` : ''}${j.events?.length ? ` (last: ${String(j.events[j.events.length - 1]?.message || '').slice(0, 100)})` : ''}`).join('\n');
    const recentContext = `\nRECENT ACTIVITY (use as evidence; do not repeat a failed identical action):\n${JSON.stringify(Array.isArray(activity) ? activity.slice(-12) : [])}\nRECENT JOBS:\n${jobsDigest}\n`;
    const networkContext = networkPreflight ? `\nBUILDER NETWORK PREFLIGHT:\n${JSON.stringify(networkPreflight)}\n` : '';
    const securityContext = security.findings?.length ? `\nSECURITY FINDINGS (treat as concrete repair requirements):\n${security.copy_for_ai}\n` : '';
    // Build effectiveFeedback in THIS scope (improveProject). Job handler must not reference it.
    let effectiveFeedback = String(feedback || '');
    try {
      const prov = await projects.readMetadata(project, 'template-provenance.json', null);
      const fromTemplate = Boolean(prov?.templateId) || /UI QUALITY GUARD|PHASE\s*[123]/i.test(effectiveFeedback);
      if (fromTemplate) {
        const hints = domainFeatureHints(project.idea || effectiveFeedback);
        effectiveFeedback = `${professionalUiGuard()}\n\nDomain hints:\n- ${hints.join('\n- ')}\n\nUSER REQUEST:\n${effectiveFeedback}`;
      }
    } catch {
      effectiveFeedback = String(feedback || '');
    }
    const contextText = relevant + recentContext + networkContext + securityContext + `\nATTACHMENTS (canonical project storage):\n${attachContext}\nATTACHMENT INDEX:\n${JSON.stringify(attachList)}`;
    const attachImages = await imageInputsFromAttachments(projects.projectDir(project));
    const baseTested = { staticResult: baselineStatic, nodeResult: baselineNode, scan: security };
    const maxCorrections = Math.max(1, Number(process.env.IMPROVE_MAX_CORRECTIONS ?? 3));
    let problemNote = '';
    let correction = 0;
    let lastRootCause = '';
    const attemptHistory = [];
    let liveRetryImages = [];
    let initialCheckpoint = null;

    // Optional pre-patch browser probe when fixing a live interaction/startup bug so the very first AI pass sees real runtime/DOM/console evidence.
    if (acceptancePlan.strictInteraction && (!runtimeState?.e2e?.evidence || runtimeState?.status === 'failed')) {
      try {
        emit('verify', 'running', language === 'Vietnamese'
          ? 'Đang chạy thử app trên trình duyệt để thu thập bằng chứng lỗi ban đầu…'
          : 'Running initial interactive browser check to capture live failure evidence…');
        const probeRuntime = await runProject(projects.get(project.id), emit, { acceptancePlan, captureImages: true });
        const probeEval = evaluateAcceptance({ plan: acceptancePlan, e2e: probeRuntime?.e2e, runtime: probeRuntime, language });
        if (probeEval.failureEvidence) {
          problemNote = `INITIAL LIVE BROWSER PROBE BEFORE PATCH:\n${probeEval.failureEvidence}`;
        }
        const ev = probeRuntime?.e2e?.evidence || {};
        liveRetryImages = [ev.afterDataUrl, ev.beforeDataUrl].filter(Boolean).slice(0, 2);
      } catch { /* non-fatal initial probe */ }
    }

    if (orchPlan) {
      await orchestrator.complete(project, orchPlan, 'reproduce_inspect', problemNote
        ? (language === 'Vietnamese' ? 'Đã thu thập bằng chứng lỗi ban đầu' : 'Captured initial failure evidence')
        : (language === 'Vietnamese' ? 'Đã đọc ngữ cảnh dự án & log' : 'Project context & logs collected'));
    }

    for (;;) {
      if (orchPlan) await orchestrator.start(project, orchPlan, 'apply_patch', correction ? `Attempt ${correction + 1}/${maxCorrections + 1}` : undefined);
      const combinedImages = [...attachImages, ...liveRetryImages].slice(0, 3);
      let patchReq;
      try {
        patchReq = await requestImprovePatch({
          ai, SYSTEM, patchPrompt, project, feedback: (typeof effectiveFeedback === 'string' ? effectiveFeedback : feedback), contextText, sourceDir: source,
          images: combinedImages, emit, language, problemNote, acceptanceSummary, attemptHistory,
        });
      } catch (err) {
        if (err?.code === 'AI_RESPONSE_MALFORMED') {
          if (orchPlan) await orchestrator.fail(project, orchPlan, 'apply_patch', 'Malformed AI JSON');
          const brief = outcomeBrief(mapPatchResult({ schemaMismatch: true }), language);
          emit('repair', 'failed', brief.message);
          return { feedback, rootCause: '', explanation: brief.message, brief: brief.message, files: [], tested: baseTested, runtime: null, outcome: OUTCOMES.NEEDS_ACTION, outcomeInfo: brief };
        }
        throw err;
      }
      const r = { json: patchReq.json, text: '', provider: 'improve-cycle' };
      lastRootCause = r.json?.root_cause || lastRootCause;

      if (!patchReq.ok && patchReq.outcome === OUTCOMES.NO_CHANGE) {
        const evidenceFail = (baselineScore > 0) || (security?.critical > 0) || Boolean(problemNote);
        if (evidenceFail && !baselineNode?.unverified) {
          // Soft recovery: one more AI pass with explicit "must change code" note instead of hard throw.
          if (correction < maxCorrections) {
            correction += 1;
            attemptHistory.push({ files: [], rootCause: lastRootCause, failure: 'AI returned no code changes despite failing verification.' });
            problemNote = [
              problemNote,
              'Evidence still shows failures, but your last answer proposed NO file changes.',
              'You MUST return a concrete patch: files[] and/or edits[] and/or new_files[].',
              'If edits.search is ambiguous, use a longer unique multi-line search OR return the full file content.',
              patchReq.message ? `Previous outcome: ${String(patchReq.message).slice(0, 600)}` : '',
            ].filter(Boolean).join('\n');
            emit('repair', 'running', language === 'Vietnamese'
              ? `AI chưa đề xuất thay đổi mã — đang yêu cầu lại với bằng chứng lỗi (${correction}/${maxCorrections})…`
              : `AI proposed no code change — requesting a concrete patch (${correction}/${maxCorrections})…`);
            continue;
          }
          if (orchPlan) await orchestrator.fail(project, orchPlan, 'apply_patch', 'No verified patch returned');
          if (initialCheckpoint?.id) await snapshots.restore(project, initialCheckpoint.id).catch(() => {});
          const alternatives = await buildOptimalAlternatives({ feedback, evaluation: null, attempts: correction + 1, lastFailure: problemNote || 'AI returned no changes.', language, ai, project });
          const altMsg = formatAlternativesMessage(alternatives, language);
          const brief = outcomeBrief({
            outcome: OUTCOMES.NEEDS_ACTION,
            reasonEn: 'AI did not produce a verified code change after multiple tries.',
            reasonVi: 'AI chưa tạo được bản sửa mã đạt kiểm tra sau nhiều lượt thử.',
            nextEn: alternatives.items?.[0]?.title || 'Choose one of the recommended options.',
            nextVi: alternatives.items?.[0]?.title || 'Hãy chọn một trong các phương án tối ưu bên dưới.',
          }, language);
          const fullBrief = [brief.message, altMsg].filter(Boolean).join('\n\n');
          return { feedback, rootCause: lastRootCause, explanation: fullBrief, brief: fullBrief, files: [], tested: baseTested, runtime: null, alternatives, outcome: OUTCOMES.NEEDS_ACTION, outcomeInfo: brief, attempts: correction + 1 };
        }
        if (orchPlan) await orchestrator.complete(project, orchPlan, 'apply_patch', patchReq.message);
        emit('repair', 'done', patchReq.message);
        return { feedback, rootCause: lastRootCause, explanation: r.json?.explanation || patchReq.message, brief: patchReq.message, files: [], tested: baseTested, runtime: null, noChange: true, outcome: OUTCOMES.NO_CHANGE, outcomeInfo: patchReq.brief };
      }
      if (!patchReq.ok) {
        // Edit/format failures already retried inside requestImprovePatch; outer AI self-repair pass.
        if (correction < maxCorrections && (patchReq.outcome === OUTCOMES.NEEDS_ACTION || patchReq.problems?.length)) {
          correction += 1;
          attemptHistory.push({ files: [], rootCause: lastRootCause, failure: String(patchReq.message || 'Patch could not be applied').slice(0, 400) });
          problemNote = [
            'Previous patch could not be applied.',
            String(patchReq.message || '').slice(0, 1500),
            'Return a corrected JSON patch. Use unique multi-line edits.search OR full files[].content.',
            'Do not repeat the same ambiguous short search string.',
          ].join('\n');
          emit('repair', 'running', language === 'Vietnamese'
            ? `Đề xuất chưa áp dụng được — AI tự sửa lần ${correction}/${maxCorrections}…`
            : `Patch not applied — AI self-repair ${correction}/${maxCorrections}…`);
          continue;
        }
        if (orchPlan) await orchestrator.fail(project, orchPlan, 'apply_patch', patchReq.message);
        emit('repair', 'failed', patchReq.message);
        return { feedback, rootCause: '', explanation: patchReq.message, brief: patchReq.message, files: [], tested: baseTested, runtime: null, outcome: patchReq.outcome, outcomeInfo: patchReq.brief };
      }

      // Risk gate: low and medium are applied (checkpointed + verified + rollback). Only "high" stops.
      const declaredRisk = String(r.json.risk || 'low').toLowerCase();
      if (declaredRisk === 'high') {
        if (orchPlan) await orchestrator.fail(project, orchPlan, 'apply_patch', 'High risk patch stopped');
        const brief = outcomeBrief({
          outcome: OUTCOMES.NEEDS_ACTION,
          reasonEn: 'The AI marked this change as HIGH risk (data, security or a large rewrite). Nothing was changed.',
          reasonVi: 'AI đánh dấu thay đổi này là RỦI RO CAO (dữ liệu, bảo mật hoặc viết lại lớn). Chưa có gì bị thay đổi.',
          nextEn: 'Split the request into smaller steps, e.g. one feature at a time.',
          nextVi: 'Chia nhỏ yêu cầu, ví dụ mỗi lần một tính năng.',
        }, language);
        emit('repair', 'failed', brief.message);
        return { feedback, rootCause: lastRootCause, explanation: brief.message, brief: brief.message, files: [], tested: baseTested, runtime: null, outcome: OUTCOMES.NEEDS_ACTION, outcomeInfo: brief };
      }

      const patchCheckpoint = await applySafeAiPatch({ sourceDir: source, files: r.json.files, project, snapshots, reason: correction ? `ai-improve-fix${correction}` : 'ai-improve' });
      if (!initialCheckpoint && patchCheckpoint?.snapshot) initialCheckpoint = patchCheckpoint.snapshot;
      if (orchPlan) {
        await orchestrator.complete(project, orchPlan, 'apply_patch', `${r.json.files.map((f) => f.path).join(', ')}${lastRootCause ? ` · ${String(lastRootCause).slice(0, 90)}` : ''}`);
        await orchestrator.start(project, orchPlan, 'verify_checks');
      }
      await stampMadeBy(source, cfg);
      // Verify the proposed patch WITHOUT another mutating auto-fix: a later repair must never hide a regression.
      const afterStatic = await runStaticTests(source);
      const afterNode = await runNodeTests(source, 45000);
      const afterScan = await scanProject(source);
      const afterScore = failureScore(afterStatic, afterNode);
      let runtime = null;
      const changedSecurity = afterScan.critical > security.critical || afterScan.warning > security.warning;
      const regressed = afterScore > baselineScore || afterScan.critical > 0 || changedSecurity;
      let failureEvidence = '';
      if (regressed) {
        failureEvidence = verificationEvidence({ afterStatic, afterNode, afterScan, baseline: { baselineScore, security } });
        if (orchPlan) await orchestrator.fail(project, orchPlan, 'verify_checks', failureEvidence.slice(0, 180));
      } else if (orchPlan) {
        await orchestrator.complete(project, orchPlan, 'verify_checks', `static=${afterStatic.status}, tests=${afterNode.status}, security=${afterScan.critical} critical`);
      }
      let liveFailure = false;
      let acceptanceEval = null;
      const tested = { staticResult: afterStatic, nodeResult: afterNode, scan: afterScan };
      if (!regressed && afterNode.status !== 'failed' && afterScan.critical === 0) {
        if (orchPlan) await orchestrator.start(project, orchPlan, 'live_browser_qa');
        emit('verify', 'running', language === 'Vietnamese'
          ? 'Đang khởi chạy app, chụp màn hình & bấm/cuộn thử theo tiêu chí nghiệm thu…'
          : 'Starting app, capturing screenshots & running live click/scroll verification…');
        runtime = await runProject(projects.get(project.id), emit, { acceptancePlan, captureImages: true });
        acceptanceEval = evaluateAcceptance({ plan: acceptancePlan, e2e: runtime?.e2e, runtime, language });
        emit('verify', acceptanceEval.passed ? 'done' : (acceptanceEval.unverified ? 'done' : 'failed'), acceptanceEval.summaryText);
        const acceptanceFailed = !acceptanceEval.passed && !acceptanceEval.unverified;
        if (runtime?.status === 'failed' || acceptanceFailed) {
          liveFailure = true;
          failureEvidence = [
            runtime?.status === 'failed' ? `The app failed live verification: ${String(runtime.error || runtime.brief || '').slice(0, 800)}` : '',
            acceptanceEval.failureEvidence || '',
          ].filter(Boolean).join('\n\n');
          if (orchPlan) await orchestrator.fail(project, orchPlan, 'live_browser_qa', `${acceptanceEval.passedCount}/${acceptanceEval.totalCount} criteria`);
        } else if (orchPlan) {
          await orchestrator.complete(project, orchPlan, 'live_browser_qa', `${acceptanceEval.passedCount}/${acceptanceEval.totalCount} criteria`);
        }
      }

      if (regressed || liveFailure) {
        const aiReady = hasConfiguredAi(ai, cfg);
        const changedPaths = (r.json.files || []).map((f) => f.path);
        attemptHistory.push({
          files: changedPaths,
          rootCause: lastRootCause,
          failure: String(failureEvidence || 'Live verification failed').slice(0, 700),
        });
        const ev = runtime?.e2e?.evidence || {};
        liveRetryImages = [ev.afterDataUrl, ev.beforeDataUrl].filter(Boolean).slice(0, 2);

        if (correction < maxCorrections && aiReady) {
          correction += 1;
          problemNote = [
            failureEvidence,
            `Files modified last attempt: ${changedPaths.join(', ')}.`,
            'Changes were KEPT in the workspace. Inspect the live browser errors / interaction result (and attached screenshot if present) and fix the real root cause without repeating the failed approach.',
          ].filter(Boolean).join('\n\n');
          emit('repair', 'running', language === 'Vietnamese'
            ? `Chưa đạt tiêu chí nghiệm thu — gửi bằng chứng chạy thử${liveRetryImages.length ? ' + ảnh chụp màn hình' : ''} cho AI sửa tiếp (${correction}/${maxCorrections})…`
            : `Acceptance criteria failed — sending live browser evidence${liveRetryImages.length ? ' + screenshot' : ''} to AI (${correction}/${maxCorrections})…`);
          continue;
        }

        // Exhausted or no AI available: restore clean checkpoint before returning honest alternatives.
        const rollbackSnap = initialCheckpoint || patchCheckpoint?.snapshot || snapshots.list(project.id)[0];
        if (rollbackSnap?.id) await snapshots.restore(project, rollbackSnap.id).catch(() => {});
        emit('rollback', 'done', language === 'Vietnamese'
          ? (aiReady
            ? 'Đã thử hết lượt sửa và kiểm tra thực tế; hoàn tác về điểm lưu an toàn.'
            : 'Không có AI để sửa tiếp; đã hoàn tác về điểm lưu an toàn.')
          : (aiReady
            ? 'Automatic verify-and-repair attempts reached limit; safe checkpoint restored.'
            : 'No AI available to continue fixing; safe checkpoint restored.'));
        await projects.saveMetadata(project, 'action-guard.json', { ...nextRepeatState(guard, problemFingerprint), acceptanceAttempted: true, exhausted: true });
        const restored = await inspectOnly(project, emit);
        const alternatives = await buildOptimalAlternatives({
          feedback,
          evaluation: acceptanceEval,
          attempts: correction + 1,
          lastFailure: failureEvidence,
          language,
          ai,
          project,
        });
        await projects.saveMetadata(project, 'acceptance.json', { ...acceptancePlan, evaluation: acceptanceEval, alternatives }).catch(() => {});
        const mapped = mapPatchResult({ rolledBack: true });
        const brief = outcomeBrief(mapped, language, { detail: failureEvidence.slice(0, 500) });
        const altMsg = formatAlternativesMessage(alternatives, language);
        const fullBrief = [brief.message, acceptanceEval?.summaryText || '', altMsg].filter(Boolean).join('\n\n');
        return {
          feedback,
          rootCause: lastRootCause,
          explanation: fullBrief,
          brief: fullBrief,
          files: [],
          tested: { staticResult: restored.staticResult, nodeResult: restored.nodeResult, scan: restored.scan },
          runtime: null,
          acceptance: acceptanceEval,
          alternatives,
          outcome: OUTCOMES.ROLLED_BACK,
          outcomeInfo: {
            ...brief,
            next: alternatives.items?.[0]?.title || brief.next,
          },
          attempts: correction + 1,
        };
      }

      const networkIssue = /\b(internet|offline|online|network|dns|proxy|gateway|browse|browsing|fetch|connection|kết nối|mạng|truy cập web)\b/i.test(feedback);
      if (networkIssue && runtime?.status === 'passed' && runtime?.internet?.ok !== true) {
        runtime.status = 'failed';
        runtime.error = 'Internet browsing is still not verified after the repair. The app page/health works, but the outbound Internet check failed or was unavailable.';
        runtime.brief = briefFail(runtime.error);
        emit('run', 'failed', runtime.error);
      }
      await projects.saveMetadata(project, 'action-guard.json', null);
      if (acceptanceEval) {
        await projects.saveMetadata(project, 'acceptance.json', { ...acceptancePlan, evaluation: acceptanceEval, passed: acceptanceEval.passed }).catch(() => {});
      }
      const unverified = Boolean(afterNode?.unverified && !acceptanceEval?.passed) || !runtime || runtime.status !== 'passed' || Boolean(acceptanceEval?.unverified);
      const mapped = mapPatchResult({ filesChanged: r.json.files.length, verified: !unverified, unverified });
      const createdNote = patchReq.created?.length
        ? (language === 'Vietnamese' ? `Tệp mới: ${patchReq.created.join(', ')}` : `New files: ${patchReq.created.join(', ')}`)
        : '';
      const brief = outcomeBrief(mapped, language, { detail: [r.json.explanation || '', createdNote].filter(Boolean).join('\n').slice(0, 700) });
      // The UI prints `next` separately for applied changes, so the brief carries no "Next:" line here.
      const baseBriefText = formatOutcomeMessage({ locale: language, outcome: mapped.outcome, reason: brief.reason });
      const briefText = acceptanceEval?.summaryText ? `${baseBriefText}\n\n${acceptanceEval.summaryText}` : baseBriefText;
      const touchedSolo = (r.json.files || []).some((f) => /config_options|docker-compose|solohost/i.test(String(f.path || '')));
      let solohostFiles = null;
      if (touchedSolo || isSoloHostFileRequest(feedback)) {
        solohostFiles = await loadSoloHostFilesForUi(source).catch(() => null);
        if (solohostFiles) emit('package', 'done', 'SoloHost install files updated — copy from the card below.');
      }
      return {
        feedback, rootCause: lastRootCause, explanation: r.json.explanation || '', brief: briefText,
        files: r.json.files.map((f) => f.path), created: patchReq.created || [], tested, runtime: sanitizeRuntimeForMeta(runtime),
        acceptance: acceptanceEval,
        outcome: mapped.outcome, outcomeInfo: brief, attempts: correction + 1,
        solohostFiles,
      };
    }
  }

  /** Short, concrete evidence for the AI after a failed verification (kept small on purpose). */
  function verificationEvidence({ afterStatic, afterNode, afterScan, baseline }) {
    const parts = [];
    const failedChecks = (afterStatic?.checks || []).filter((c) => c && c.ok === false).map((c) => `${c.category || ''} ${c.name || ''}`.trim());
    if (afterStatic?.status === 'failed') parts.push(`Static checks failed: ${failedChecks.slice(0, 8).join('; ') || failSummary(afterStatic)}`);
    if (afterNode?.status === 'failed') parts.push(`Tests/build failed (${afterNode.stage || afterNode.runner || 'tests'}):\n${String(afterNode.error || '').slice(0, 1800)}`);
    if (afterScan?.critical > 0 || afterScan?.warning > (baseline?.security?.warning ?? 0)) parts.push(`Security scan got worse (critical ${afterScan.critical}, warnings ${afterScan.warning}).\n${String(afterScan.copy_for_ai || '').slice(0, 900)}`);
    return parts.join('\n') || 'Verification regressed compared with the state before the change.';
  }

  function imageInputs(files) {
    let total = 0;
    const out = [];
    for (const f of (files || [])) {
      if (!/image\/(jpeg|png|gif|webp)/i.test(f?.mimetype || '') || !f.buffer || f.buffer.length > 20 * 1024 * 1024) continue;
      if (total + f.buffer.length > 40 * 1024 * 1024) break;
      total += f.buffer.length; out.push({ dataUrl: `data:${f.mimetype};base64,${f.buffer.toString('base64')}` });
      if (out.length >= 3) break;
    }
    return out;
  }

  async function applySafeAiPatch({ sourceDir, files, project, snapshots: snapshotStore, reason = 'ai-patch' }) {
    let proposed = Array.isArray(files) ? files.filter((f) => f && f.path && typeof f.content === 'string') : [];
    if (!proposed.length) throw new Error('AI returned no usable patch files.');
    // 1.8.9: real path gate. (It used to whitelist every proposed path, i.e. protected nothing.)
    // Look-alikes of existing files (e.g. src/server.js vs server.js), traversal and protected paths are rejected
    // as a whole — a half-applied patch is worse than none.
    // Remap look-alike paths (src/server.js → server.js) instead of rejecting the whole patch.
    const safe = await remapAndFilterPatchFiles({
      sourceDir,
      files: proposed,
      allowedNew: proposed.filter((f) => f?.isNew || f?.new).map((f) => f.path).filter(Boolean),
      allowImplicitNew: true,
      maxNew: 8,
    });
    if (!safe.files.length) throw new Error(`AI patch rejected. ${safe.suggestion || 'No usable paths from FILE INVENTORY.'}`);
    if (safe.remapped?.length) {
      // Keep going with remapped paths — do not fail the whole repair for a wrong folder prefix.
    }
    if (safe.rejected.length && !safe.files.length) throw new Error(`AI patch rejected. ${safe.suggestion || 'No usable paths.'}`);
    proposed = safe.files;
    if (proposed.length > 8) throw new Error('AI patch is too large for an automatic repair. I will not rewrite the project blindly.');
    const paths = new Set();
    for (const f of proposed) {
      const rel = String(f.path).replace(/\\/g, '/');
      if (paths.has(rel)) throw new Error(`AI patch contains the same file more than once: ${rel}`);
      paths.add(rel);
      if (Buffer.byteLength(f.content, 'utf8') > 1024 * 1024) throw new Error(`AI patch file is too large for a safe automatic change: ${rel}`);
      if (!rel || rel.startsWith('/') || rel.includes('..') || /^(?:data|workspace|projects)\//i.test(rel)) {
        throw new Error(`AI patch contains an unsafe path: ${rel}`);
      }
      // Real secret files remain protected, but example/template env files are safe
      // documentation/configuration artifacts and must be editable. Blocking .env.*
      // indiscriminately caused legitimate fixes to .env.example to deadlock Improve.
      if (/^(?:\.env$|.*\/(?:\.env$|id_rsa(?:\.|$)|private[_-]?key(?:\.|$)))/i.test(rel)) {
        throw new Error(`AI patch attempted to modify a protected secret file: ${rel}`);
      }
    }
    const snapshot = await snapshotStore.create(project, `before-${reason}`);
    const written = await writeGeneratedFiles(sourceDir, proposed);
    return { written, snapshot };
  }

  function failureScore(staticResult, nodeResult) {
    return (staticResult?.status === 'failed' ? 1 : 0) + (nodeResult?.status === 'failed' ? 1 : 0);
  }

  function repeatFingerprint(text) {
    return String(text || '')
      .toLowerCase()
      .replace(/\d{2,}/g, '#')
      .replace(/https?:\/\/\S+/g, 'URL')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 900);
  }

  function mustProject(id) {
    const p = projects.get(id);
    if (!p) throw new Error('Project not found');
    return p;
  }

  async function isImportOrUpgradeOrigin(project) {
    try {
      const origin = await projects.readMetadata(project, 'origin.json', {}) || {};
      const upgrade = await projects.readMetadata(project, 'upgrade-origin.json', null);
      const tests = await projects.readMetadata(project, 'test-plan.json', {}) || {};
      const status = String(project?.status || projects.get(project.id)?.status || '');
      return Boolean(
        origin.origin === 'upgrade'
        || origin.origin === 'import'
        || origin.policy === 'import-skip-checks'
        || origin.policy === 'accept-external-source-no-auto-repair'
        || upgrade?.origin === 'upgrade'
        || tests.status === 'import-skipped'
        || tests.status === 'upgrade-import-skipped'
        || status.startsWith('UPGRADE_')
      );
    } catch {
      return false;
    }
  }



  async function runWithRepair(project, emit, userMessage) {
    emit('run', 'running', 'Starting a safe local preview…');
    let runtime = await runProject(project, emit);
    if (runtime.status === 'passed') return runtime;
    const importOrigin2 = await isImportOrUpgradeOrigin(project);
    const profile2 = await detectAppProfile(projects.sourceDir(project.slug)).catch(() => null);
    if (importOrigin2 || profile2?.preferPublish) {
      runtime.brief = profile2?.guidance?.en
        || 'Preview failed for an Import/Upgrade or framework app. Diagnosis skipped — Publish to SoloHost.';
      emit('run', 'done', runtime.brief);
      return { ...runtime, importSkippedChecks: Boolean(importOrigin2), appProfile: profile2 };
    }
    const crash = classifyLogs(`${runtime.error || ''}\n${runtime.logs || ''}`);
    const diagnosis = await diagnoseSource(projects.sourceDir(project.slug));
    if (crash?.code === 'registry_unauthorized' || crash?.code === 'github_workflow_permission') {
      const guide = crash.code === 'github_workflow_permission'
        ? 'GitHub Actions is read-only. Open GitHub → Repository → Settings → Actions → General → Workflow permissions → Read and write permissions → Save.'
        : 'The Docker image cannot be downloaded from GHCR. Check that the image name is correct and the GHCR package is public/pullable.';
      runtime.brief = [`RESULT: Not ready.`, `WHY: ${crash.title}`, `DONE: Identified an access problem outside the app source.`, `MISSING: ${guide}`, `NEXT: ${guide}`].join('\n');
      return runtime;
    }
    emit('repair', 'running', crash ? `Crash found: ${crash.title}` : 'Preview failed. Applying one automatic fix…');
    let dareCheckpoint = null;
    try {
      const history = await projects.readMetadata(project, 'dare-history.json', []);
      dareCheckpoint = await snapshots.create(project, 'before-dare-run-repair').catch(() => null);
      const dare = await runDare({
        sourceDir: projects.sourceDir(project.slug),
        logs: `${runtime.error || ''}\n${runtime.logs || ''}`,
        extra: crash || {},
        history: Array.isArray(history) ? history : [],
      });
      await projects.saveMetadata(project, 'dare-history.json', (dare.history || []).slice(-20));
      if (dare.ok) {
        emit('repair', 'done', formatDareReport(dare));
        emit('run', 'running', 'Retrying the preview after deterministic repair…');
        runtime = await runProject(project, emit);
        if (runtime.status === 'passed') return { ...runtime, dare };
        if (dareCheckpoint?.id) await snapshots.restore(project, dareCheckpoint.id).catch(() => {});
        emit('rollback', 'done', 'Deterministic repair did not produce a passing preview. Checkpoint restored; continuing with AI diagnosis.');
      } else if (dare.userAction) {
        runtime.brief = formatDareReport(dare);
        return runtime;
      }
    } catch {}
    const feedback = [
      userMessage,
      crash ? `${crash.title} ${crash.hint}` : 'Health check failed because the process died before listen or the UI files are missing.',
      diagnosis.findings.map((f) => f.title).join('; '),
      runtime.error,
    ].filter(Boolean).join('\n');
    try {
      await improveProject(project, feedback, emit);
      emit('run', 'running', 'Retrying the preview after the fix…');
      runtime = await runProject(project, emit);
    } catch (err) {
      runtime = { ...runtime, repairError: err.message };
    }
    return runtime;
  }

  return { review };
}

function failSummary(staticResult) {
  return (staticResult.checks || [])
    .filter((c) => !c.ok)
    .map((c) => `${c.name} failed`)
    .join('\n');
}

async function collectRelevant(source) {
  const names = ['package.json', 'src/server.js', 'Dockerfile', 'tests/app.test.js'];
  const chunks = [];
  const existing = new Set(await listFiles(source));
  for (const n of names) {
    if (!existing.has(n)) continue;
    const text = await fs.readFile(path.join(source, n), 'utf8').catch(() => '');
    chunks.push(`--- ${n} ---\n${clampText(text, 2500)}`);
  }
  return chunks.join('\n\n');
}

function formatUserBrief({ action, runtime, diagnosis, reply, next, language = 'English', reports = [] }) {
  const templates = {
    English: { running: 'App is running.', failed: 'App did not stay up.', finished: 'Action finished.', none: 'none.', needRun: 'a passing Run.', image: 'safe preview started, health check and browser test passed.' },
    Vietnamese: { running: 'Ứng dụng đang chạy.', failed: 'Ứng dụng chưa chạy ổn định.', finished: 'Đã hoàn tất thao tác.', none: 'không có.', needRun: 'một lần Run thành công.', image: 'đã build image, khởi động container và kiểm tra /health thành công.' },
    Chinese: { running: '应用正在运行。', failed: '应用未能稳定运行。', finished: '操作已完成。', none: '无。', needRun: '一次成功的运行。', image: '镜像已构建，容器已启动，/health 检查通过。' },
    Japanese: { running: 'アプリは実行中です。', failed: 'アプリは安定して起動できませんでした。', finished: '操作が完了しました。', none: 'ありません。', needRun: '成功したRunが必要です。', image: 'イメージをビルドし、コンテナを起動して /health を確認しました。' },
    Korean: { running: '앱이 실행 중입니다.', failed: '앱이 안정적으로 실행되지 않았습니다.', finished: '작업이 완료되었습니다.', none: '없습니다.', needRun: '성공한 Run이 필요합니다.', image: '이미지를 빌드하고 컨테이너를 시작했으며 /health 검사를 통과했습니다.' },
    Spanish: { running: 'La aplicación está en ejecución.', failed: 'La aplicación no se mantuvo activa.', finished: 'La acción ha terminado.', none: 'ninguno.', needRun: 'una ejecución correcta.', image: 'la imagen se creó, el contenedor inició y /health pasó.' },
    French: { running: 'L’application est en cours d’exécution.', failed: 'L’application ne reste pas active.', finished: 'L’action est terminée.', none: 'aucun.', needRun: 'une exécution réussie.', image: 'l’image a été construite, le conteneur démarré et /health validé.' },
  };
  const t = templates[language] || templates.English;
  const failedReports = Array.isArray(reports) ? reports.filter((s) => s.status === 'failed' || s.status === 'blocked') : [];
  const result = failedReports.length
    ? t.failed
    : runtime?.status === 'passed'
      ? t.running
      : runtime?.error ? t.failed : action === 'reply' ? (reply || t.finished) : t.finished;
  const done = failedReports.length
    ? reports.filter((s) => s.status === 'done').map((s) => s.action).join(', ') || action
    : runtime?.status === 'passed' ? t.image : action;
  const missing = failedReports.length
    ? failedReports.map((s) => `${s.action}: ${String(s.error || 'not completed').slice(0, 180)}`).join('; ')
    : diagnosis?.findings?.length ? diagnosis.findings.map((f) => f.title).join('; ') : (runtime?.status === 'passed' ? t.none : (classifyLogs(runtime?.error || runtime?.logs || '')?.title || t.needRun));
  const card = describeFailure({ error: runtime?.error || '', logs: runtime?.logs || '', findings: diagnosis?.findings || [], action });
  const why = runtime?.status === 'failed' ? card.what : (runtime?.error ? String(runtime.error).split('\n')[0].slice(0, 220) : '');
  const extra = reply && !/RESULT:/i.test(reply) ? reply : '';
  const reportLines = Array.isArray(reports) && reports.length
    ? reports.map((s) => `${s.status === 'done' ? '✅' : '⚠️'} ${s.action}: ${String(s.goal || '').slice(0, 80)}${s.error ? ` (${s.error})` : ''}`).join('\n')
    : '';
  const failBlock = runtime?.status === 'failed' ? [`FIX: ${card.fix}`, `COPY_FOR_AI:\n${card.copy}`] : [];
  return [`RESULT: ${result}`, why ? `WHY: ${why}` : '', `DONE: ${done}`, `MISSING: ${missing}`, `NEXT: ${next}`, ...failBlock, reportLines, extra].filter(Boolean).join('\n');
}

function briefRun(runtime) {
  return [
    `RESULT: App is running.`,
    `TEST LINK: ${runtime.previewPath || runtime.url}`,
    `DONE: Safe preview started; health and browser checks passed.${runtime.internet?.ok === true ? ' Outbound Internet was also verified.' : ' Outbound Internet is not verified by this test.'}`,
    `MISSING: none for a test run.`,
    `NEXT: Open the test link, then tell me what to change. Tap Publish when you are happy.`,
  ].join('\n');
}

function briefFail(reason) {
  const card = describeFailure({ error: reason || '' });
  return [
    `RESULT: Not ready.`,
    `WHY: ${card.what}`,
    `FIX: ${card.fix}`,
    `MISSING: a passing run.`,
    `NEXT: Use the FIX above, or send COPY_FOR_AI to chat.`,
    `COPY_FOR_AI:\n${card.copy}`,
  ].join('\n');
}

function normalizeQuestions(questions) {
  return (Array.isArray(questions) ? questions : []).slice(0, 3).map((q) => {
    if (typeof q === 'string') return { question: q, options: [], required: true };
    return { question: String(q?.question || ''), options: Array.isArray(q?.options) ? q.options.slice(0, 4).map(String) : [], required: q?.required !== false };
  }).filter((q) => q.question);
}

async function checkBuilderInternet() {
  const targets = ['example.com', 'www.google.com', 'cloudflare.com'];
  const dnsResults = [];
  const httpsResults = [];
  for (const host of targets) {
    try {
      const addresses = await Promise.race([
        dns.lookup(host, { all: true }),
        new Promise((_, reject) => setTimeout(() => reject(new Error('DNS timeout')), 5000)),
      ]);
      dnsResults.push({ host, ok: Array.isArray(addresses) && addresses.length > 0, addresses: (addresses || []).map((x) => x.address) });
    } catch (err) { dnsResults.push({ host, ok: false, error: String(err?.code || err?.message || err) }); }
    try {
      const result = await new Promise((resolve) => {
        const req = https.request(`https://${host}/`, { method: 'HEAD', timeout: 7000, headers: { 'User-Agent': 'Pi-App-Factory-Network-Preflight/1.0' } }, (res) => { res.resume(); resolve({ ok: res.statusCode > 0, status: res.statusCode }); });
        req.on('timeout', () => req.destroy(new Error('HTTPS timeout')));
        req.on('error', (err) => resolve({ ok: false, error: String(err?.code || err?.message || err) }));
        req.end();
      });
      httpsResults.push({ host, ...result });
    } catch (err) { httpsResults.push({ host, ok: false, error: String(err?.message || err) }); }
  }
  const dnsOk = dnsResults.filter((x) => x.ok).length;
  const httpsOk = httpsResults.filter((x) => x.ok).length;
  const ok = httpsOk > 0;
  return {
    ok,
    targets,
    dnsOk,
    httpsOk,
    dns: dnsResults,
    https: httpsResults,
    summary: ok ? `Builder outbound HTTPS works for ${httpsOk}/${targets.length} test hosts.` : (dnsOk ? 'Builder DNS works, but outbound HTTPS is blocked.' : 'Builder DNS/network access is unavailable.'),
    remediation: ok ? 'Environment network is available. Continue with app-specific proxy/gateway diagnosis.' : 'Do not rewrite the app proxy yet. Fix Builder/Sandbox DNS or outbound network access first.'
  };
}

function improvePrompt(project, feedback, context) {
  return `Improve this existing application from the user's feedback.

Project: ${project.name}
Idea: ${project.idea}
User feedback: ${feedback}

Relevant files:
${context}

NETWORK DEBUGGING CONTRACT:
- If feedback mentions Internet, offline, proxy, gateway, DNS, fetch, browsing, or connection: diagnose before editing.
- If the latest Sandbox Benchmark says DNS_UNAVAILABLE or DNS_OK_BUT_HTTPS_BLOCKED, do not modify product proxy code; report the sandbox/environment blocker.
- If Sandbox Internet is available, inspect the actual app gateway/proxy, DNS lookup, HTTPS request, redirects, timeouts, response status, CORS/CSP, and browser-facing routing.
- Do not merely describe a fix: when the root cause is in source code, return the smallest concrete file patch.
- Re-test the real browsing flow after patching.
- Never call a passing /health or page-load check proof that Internet browsing works.

Return JSON with full file contents for every changed file:
{
  "root_cause": "",
  "files": [{"path":"","content":"full file content"}],
  "explanation": "short beginner-friendly explanation"
}`;
}

async function collectProjectContext(source, query = '', mode = 'improve') {
  // Lean context: path inventory + query-ranked excerpts; more bodies only via NEED_FILES.
  return collectProjectContextText(source, query, mode);
}

export function friendlyAiError(err) {
  const m = String(err?.message || err);
  const providers = Array.isArray(err?.providerErrors) ? err.providerErrors.map((x) => String(x).replace(/\s+/g, ' ').slice(0, 260)) : [];
  const detail = providers.join(' | ');
  const combined = `${m} ${detail}`;
  if (/No AI provider is configured|API key is not configured/i.test(m)) return 'No active AI key is available. Builder can use DeepSeek or Gemini; save a valid key in Settings.';
  if (/No verified AI model is available/i.test(m)) return 'No verified AI model is available. Open Settings, test or refresh your provider models, then retry.';
  if (/HTTP 401|HTTP 403|bad credentials|invalid api key|API key is invalid/i.test(combined)) return `AI authentication failed. ${detail || 'The selected key was rejected.'} Check the provider key, then Save Settings.`;
  if (/HTTP 404|model.*not found|invalid.*model|not available for this key|MODEL_OR_ENDPOINT_UNAVAILABLE/i.test(combined)) return `AI model is unavailable. ${detail || 'Builder could not reach the selected model.'} Select another verified model in Settings and retry.`;
  if (/HTTP 429|quota|rate limit|rate-limited|resource exhausted/i.test(combined)) return `AI quota/rate limit was reached. ${detail || 'The request was throttled.'} Builder will try another verified model when available.`;
  if (/HTTP 402|Insufficient Balance|billing/i.test(combined)) return `The AI provider requires available credit. ${detail || 'Use another configured provider/key.'}`;
  if (/timeout|timed out|fetch failed|ECONNRESET|ECONNREFUSED|ENOTFOUND|network/i.test(combined)) return `AI connection failed. ${detail || 'No files were changed.'} Builder will retry transient failures and switch model/provider when possible.`;
  if (/temporarily unavailable|temporarily paused|overloaded|HTTP 50[0234]|service unavailable/i.test(combined) || err?.code === 'AI_UNAVAILABLE') {
    return `AI provider is temporarily unavailable or overloaded. ${detail || m} Try again shortly or select another verified model in Settings.`;
  }
  if (/AI_RESPONSE_MALFORMED|AI_BAD_JSON|invalid JSON|FORMAT_ERROR/i.test(m) || err?.code === 'AI_RESPONSE_MALFORMED') return 'AI provider temporarily returned an invalid format. No verified work was rolled back; Builder retries or falls back when another provider is available.';
  if (err?.code === 'AI_NO_CHANGE' || /did not propose a code change/i.test(m)) return 'AI proposed no code change while checks still fail. Builder will not loop the same request; provide new evidence or switch provider.';
  if (err?.code === 'AI_CANCELLED') return 'AI step was cancelled before completion. No files were changed.';
  return detail
    ? `AI could not complete this step. No files were changed. Details: ${detail}`
    : 'AI could not complete this step. No files were changed. Save a valid provider key/model, then retry.';
}

function gateAction(action, { files = [], runtime = {}, githubConfigured = false, imageRef = '' } = {}) {
  const hasFiles = Array.isArray(files) && files.length > 0;
  const ran = runtime.status === 'passed' && runtime.health === true;
  if (action === 'export' && imageRef) {
    return { action: 'export', lock: '' };
  }
  if ((action === 'run' || action === 'analyze') && !hasFiles) {
    return { action: 'build', lock: 'No app files yet. I will Build first, then you can Run.' };
  }
  if (action === 'improve' && !hasFiles) {
    return { action: 'build', lock: 'There is nothing to improve yet. Describe the app so I can Build it first.' };
  }
  if (action === 'export' && !hasFiles) {
    return { action: 'build', lock: 'There is no project to zip yet. Build the app first.' };
  }
  if (action === 'publish' && !hasFiles) {
    return { action: 'build', lock: 'Publish is locked. Build the app first, then Run, then Publish.' };
  }
  if (action === 'publish' && !ran) {
    return { action: 'run', lock: 'Publish is locked until the preview runs. I will Run the app first.' };
  }
  if (action === 'publish' && !githubConfigured) {
    return { action: 'reply', lock: 'Publish needs a GitHub username and token in Settings. Add them, then tap Publish.' };
  }
  return { action, lock: '' };
}

function formatProjectDiagnosis(report) {
  const lines = ['🩺 PROJECT DIAGNOSIS', `Status: ${report.currentStatus || 'unknown'}`, `Confidence: ${report.confidence}`, `Root cause: ${report.rootCause}`];
  if (report.fingerprint && report.fingerprint !== 'NONE') lines.push(`Fingerprint: ${report.fingerprint}`);
  if (report.problems?.length) lines.push('', ...report.problems.slice(0, 4).map((p) => `⚠ ${p.id}: ${p.recommendation || p.evidence}`));
  if (report.previousFailedAttempts?.length) lines.push('', '⛔ Repeated ineffective repair detected. I will not repeat the same fix without new evidence.');
  lines.push('', `Next: ${report.recommendation}`, '', 'Verification: Build → Start → Health → Functional → Preview');
  if (report.ai?.unavailable) lines.push('', 'AI enhancement unavailable; deterministic evidence report is still available.');
  return lines.join('\n');
}

function formatAdvisor(report) {
  const o = report.overview || {};
  const lines = [
    '🧭 AI ADVISOR',
    `Apps analyzed: ${o.appsAnalyzed || 0}`,
    `Failed jobs: ${o.failedJobs || 0}`,
    'Advisor does not edit apps or Builder.',
  ];
  for (const row of (report.patterns || []).slice(0, 4)) lines.push('', `Pattern: ${row.what}`, `Why: ${row.why || ''}`, `Recommendation: ${row.recommendation}`);
  for (const row of (report.appImprovements || []).slice(0, 4)) lines.push('', `App: ${row.app}`, `What: ${row.what}`, `Recommendation: ${row.recommendation}`);
  if (!report.patterns?.length && !report.appImprovements?.length) lines.push('', 'No recurring problems in the selected scope.');
  return lines.join('\n');
}

function formatUserDiagnosis(report) {
  return [
    '⚠️ Problem detected',
    '🔎 Diagnosis complete',
    `Cause: ${report.rootCause}`,
    `Confidence: ${report.confidence}`,
    report.evidenceLedger?.conclusion ? `Evidence: ${report.evidenceLedger.conclusion}` : '',
    `Next: ${report.recommendation}`,
    report.previousFailedAttempts?.length ? 'The previous repair will not be repeated automatically.' : '',
  ].filter(Boolean).join('\n');
}
