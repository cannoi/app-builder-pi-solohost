(function (global) {
  const dict = {
    en: {
      'chat.placeholder': 'Describe your app idea, paste a GitHub link, or say what to change…',
      'chat.hint': '1 Idea → 2 Run → 3 Publish. I keep the next step visible.',
      'qa.run': '▶ Run',
      'qa.publish': '🚀 Publish',
      'qa.donate': '💛 Donate',
      'more.title': 'More',
      'more.zip': '⬇ Download ZIP',
      'more.import': '⬆ Import ZIP',
      'more.compareImport': '📋 Compare import',
      'more.sandbox': '🧪 Sandbox',
      'more.scriptRun': '📦 Run script on PC',
      'more.scriptGithub': '⬆ GitHub push script',
      'more.rollback': '↩ Undo',
      'more.support': '💛 Support',
      'welcome.title': 'App Builder — Pi SoloHost',
      'welcome.body': 'Type an idea, paste a GitHub link to upgrade, attach a ZIP, or ask to change a feature. One chat — I route the rest.',
      'welcome.idea': '💡 Sample idea',
      'welcome.github': '🔗 Paste GitHub link',
      'welcome.settings': '⚙ Connect AI',
      'welcome.chip': '💡 Try: milk-tea shop app',
      'welcome.ideaText': 'Create a simple sales app for a small shop',
      'welcome.chipText': 'Create a milk-tea shop app with menu and cart',
      'msg.needApp': 'Open or create an app first.',
      'msg.startIdea': 'Start with your app idea in the chat. I will create the project first.',
      'remote.title': 'Remote access',
      'remote.hide': 'Hide',
      'remote.show': 'Show',
      'remote.save': 'Save URL',
      'remote.copy': 'Copy URL',
      'remote.genPass': 'Create password',
      'top.settings': 'Settings',
      'pill.ready': 'Ready',
      'msg.busy': 'Wait for the current step to finish…',
      'msg.runTip': 'Tip: open ⋯ and choose Sandbox if preview fails — that separates Builder/preview issues from your app.',
      'msg.zipPrep': 'Preparing a ZIP of your app…',
      'msg.zipNeedApp': 'Create an app first, then download ZIP.',
      'msg.typeRequest': 'Type your request in the chat box.',
      'msg.repoExists': 'This GitHub repository already has content. Overwrite or cancel?',
      'msg.overwrite': 'Overwrite',
      'msg.cancel': 'Cancel',
      'support.title': '💛 Support this project',
      'support.body': 'Thank you for supporting App Builder — Pi SoloHost. Choose Pi Wallet or MB Bank, copy the details, and send what you can.',
      'acceptance.title': '🎯 Acceptance criteria',
      'acceptance.passed': 'Verified',
      'acceptance.failed': 'Needs fix',
      'alternatives.title': '💡 Optimal next options',
      'alternatives.apply': 'Try this option',
      'orch.title': '🧩 Agent Orchestrator · Fix Checklist',
      'orch.running': 'Running',
      'orch.done': 'Done',
      'orch.failed': 'Needs review',
      'orch.skipped': 'Skipped',
      'orch.pending': 'Queued',
    },
    vi: {
      'chat.placeholder': 'Mô tả ý tưởng app, dán link GitHub, hoặc nói cần đổi gì…',
      'chat.hint': '1 Ý tưởng → 2 Chạy thử → 3 Xuất bản. Tôi luôn hiện bước tiếp theo.',
      'qa.run': '▶ Chạy thử',
      'qa.publish': '🚀 Xuất bản',
      'qa.donate': '💛 Ủng hộ',
      'more.title': 'Thêm',
      'more.zip': '⬇ Tải ZIP',
      'more.import': '⬆ Nhập ZIP',
      'more.compareImport': '📋 So sánh import',
      'more.sandbox': '🧪 Sandbox',
      'more.scriptRun': '📦 Script chạy trên PC',
      'more.scriptGithub': '⬆ Script đẩy GitHub',
      'more.rollback': '↩ Hoàn tác',
      'more.support': '💛 Ủng hộ',
      'welcome.title': 'App Builder — Pi SoloHost',
      'welcome.body': 'Gõ ý tưởng, dán link GitHub để nâng cấp, đính kèm ZIP, hoặc nhờ đổi tính năng. Một ô chat — tôi tự phân loại và làm.',
      'welcome.idea': '💡 Ý tưởng mẫu',
      'welcome.github': '🔗 Dán link GitHub',
      'welcome.settings': '⚙ Kết nối AI',
      'welcome.chip': '💡 Thử: app bán trà sữa',
      'welcome.ideaText': 'Tạo app quản lý bán hàng đơn giản cho cửa hàng nhỏ',
      'welcome.chipText': 'Tạo app bán trà sữa với menu và giỏ hàng',
      'msg.needApp': 'Hãy mở hoặc tạo app trước.',
      'msg.startIdea': 'Hãy gõ ý tưởng app vào ô chat. Tôi sẽ tạo dự án trước.',
      'remote.title': 'Truy cập từ xa',
      'remote.hide': 'Ẩn',
      'remote.show': 'Hiện',
      'remote.save': 'Lưu URL',
      'remote.copy': 'Sao chép',
      'remote.genPass': 'Tạo mật khẩu',
      'top.settings': 'Cài đặt',
      'pill.ready': 'Sẵn sàng',
      'msg.busy': 'Vui lòng đợi bước hiện tại xong…',
      'msg.runTip': 'Mẹo: mở ⋯ rồi chọn Sandbox nếu xem trước lỗi — để tách lỗi Builder/preview khỏi app của bạn.',
      'msg.zipPrep': 'Đang chuẩn bị file ZIP…',
      'msg.zipNeedApp': 'Hãy tạo app trước, rồi tải ZIP.',
      'msg.typeRequest': 'Gõ yêu cầu vào ô chat.',
      'msg.repoExists': 'Kho GitHub này đã có nội dung. Ghi đè hoặc Hủy?',
      'msg.overwrite': 'Ghi đè',
      'msg.cancel': 'Hủy',
      'support.title': '💛 Ủng hộ dự án',
      'support.body': 'Cảm ơn bạn đã ủng hộ App Builder — Pi SoloHost. Chọn Pi Wallet hoặc MB Bank, sao chép thông tin và gửi số bạn muốn.',
      'acceptance.title': '🎯 Tiêu chí nghiệm thu',
      'acceptance.passed': 'Đạt',
      'acceptance.failed': 'Chưa đạt',
      'alternatives.title': '💡 Phương án tối ưu đề xuất',
      'alternatives.apply': 'Thử phương án này',
      'orch.title': '🧩 Agent Orchestrator · Kế hoạch sửa lỗi',
      'orch.running': 'Đang chạy',
      'orch.done': 'Hoàn tất',
      'orch.failed': 'Cần xem lại',
      'orch.skipped': 'Bỏ qua',
      'orch.pending': 'Chờ',
    },
  };

  let locale = 'en';
  try {
    const saved = localStorage.getItem('paf_locale');
    if (saved === 'vi' || saved === 'en') locale = saved;
    // Default remains English; user chooses VI via the language toggle
  } catch {}

  function t(key) {
    return (dict[locale] && dict[locale][key]) || dict.en[key] || key;
  }
  function setLocale(l) {
    locale = l === 'vi' ? 'vi' : 'en';
    try { localStorage.setItem('paf_locale', locale); } catch {}
    apply();
    try {
      document.documentElement.lang = locale === 'vi' ? 'vi' : 'en';
      const btn = document.getElementById('langToggle');
      if (btn) btn.textContent = locale === 'vi' ? 'VI' : 'EN';
    } catch {}
    try {
      global.dispatchEvent(new CustomEvent('paf-locale', { detail: { locale } }));
    } catch {}
  }
  function apply() {
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const k = el.getAttribute('data-i18n');
      if (k) el.textContent = t(k);
    });
    document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
      const k = el.getAttribute('data-i18n-placeholder');
      if (k) el.setAttribute('placeholder', t(k));
    });
    const btn = document.getElementById('langToggle');
    if (btn) btn.textContent = locale === 'vi' ? 'VI' : 'EN';
    const more = document.getElementById('moreMenu');
    if (more) {
      const map = {
        export: 'more.zip',
        import: 'more.import',
        'compare-import': 'more.compareImport',
        sandbox: 'more.sandbox',
        'script-run': 'more.scriptRun',
        'script-github': 'more.scriptGithub',
        rollback: 'more.rollback',
        support: 'more.support',
      };
      more.querySelectorAll('[data-more]').forEach((b) => {
        const key = map[b.getAttribute('data-more')];
        if (key) b.textContent = t(key); // single label (icon already in dictionary string)
      });
    }
  }
  function toggle() {
    setLocale(locale === 'vi' ? 'en' : 'vi');
  }
  global.pafI18n = { t, setLocale, getLocale: () => locale, apply, toggle, dict };
  if (typeof document !== 'undefined') {
    const boot = () => {
      apply();
      document.getElementById('langToggle')?.addEventListener('click', (e) => {
        e.preventDefault();
        toggle();
      });
    };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
  }
})(typeof window !== 'undefined' ? window : globalThis);

// orch_planning / orch_task_done used by orchestrator emit messages (en/vi in pipeline emit)
