import { PROVIDER_CATALOG, catalogEntry, taskComplexity } from './catalog.js';
import { OpenAICompatProvider, preferAutoModel, normalizeBaseUrl } from './openai-compat.js';
import { GeminiProvider, GEMINI_MODEL_CANDIDATES } from '../providers/gemini.js';
import { DeepSeekProvider } from '../providers/deepseek.js';
import { classifyProviderError, isTransient } from './errors.js';
import { maskKey } from '../../utils/mask.js';
import { CredentialVault } from './credentials.js';

const CACHE_MS = 6 * 60 * 60 * 1000;

export class AIProviderHub {
  constructor({ cfg, db, log }) {
    this.cfg = cfg; this.db = db; this.log = log;
    this.vault = new CredentialVault(cfg.dataDir);
    this.migrateLegacy();
  }

  state() {
    const raw = this.db.setting('aiHub', { mode: 'SELECTED', preferredProvider: '', preferredModel: '', preferredModels: [], connections: [] })
      || { mode: 'SELECTED', preferredProvider: '', preferredModel: '', preferredModels: [], connections: [] };
    return normalizeHubState(raw);
  }
  save(next) { this.db.setSetting('aiHub', next); return next; }

  migrateLegacy() {
    const st = this.state();
    if (!Array.isArray(st.connections)) st.connections = [];
    const migrate = (id, key, model) => {
      if (!key || st.connections.some((c) => c.provider === id)) return;
      const ref = `${id}-legacy`;
      this.vault.set(ref, key);
      st.connections.push({ id: ref, provider: id, credentialRef: ref, baseUrl: catalogEntry(id)?.baseUrl || '', status: 'UNVERIFIED', models: model ? [{ id: model, verified: false }] : [], lastError: null, lastVerified: null, cacheAt: null });
    };
    migrate('gemini', this.cfg.ai.geminiKey, this.cfg.ai.geminiModel);
    migrate('deepseek', this.cfg.ai.deepseekKey, this.cfg.ai.deepseekModel);
    // Remove any legacy plaintext apiKey fields from the hub state after migration.
    let changed = false;
    for (const c of st.connections) {
      if (c.apiKey) { if (!c.credentialRef) { c.credentialRef = c.id; this.vault.set(c.credentialRef, c.apiKey); } delete c.apiKey; changed = true; }
    }
    if (!st.mode) st.mode = 'AUTO';
    if (changed || st.connections.length) this.save(st);
    const secrets = this.db.setting('runtimeSecrets', null);
    if (secrets && typeof secrets === 'object') {
      let dirty = false;
      for (const k of ['GEMINI_API_KEY', 'GEMINI_MODEL', 'DEEPSEEK_API_KEY', 'DEEPSEEK_MODEL']) {
        if (k in secrets) { delete secrets[k]; dirty = true; }
      }
      if (dirty) this.db.setSetting('runtimeSecrets', secrets);
    }
  }

  key(conn) { return conn?.credentialRef ? this.vault.get(conn.credentialRef) : ''; }

  publicState() {
    const st = this.state();
    return {
      mode: 'SELECTED', preferredProvider: st.preferredProvider || '', preferredModel: st.preferredModel || '', preferredModels: normalizePreferredModels(st.preferredModels || (st.preferredModel ? [st.preferredModel] : [])),
      catalog: PROVIDER_CATALOG.map(({ id, name, kind }) => ({ id, name, kind })),
      connections: (st.connections || []).map((c) => ({
        id: c.id, provider: c.provider, name: catalogEntry(c.provider)?.name || c.provider,
        credentialRef: c.credentialRef, masked: maskKey(this.key(c)), status: c.status || 'UNVERIFIED',
        models: normalizeModelsState(c.models).map((m) => ({ id: m.id || m, verified: m.verified === true, capabilities: m.capabilities || {}, contextWindow: m.contextWindow || null, lastVerified: m.lastVerified || null })),
        verifiedCount: normalizeModelsState(c.models).filter((m) => m.verified === true).length,
        lastError: c.lastError || null, lastVerified: c.lastVerified || null, baseUrl: c.provider === 'custom' ? c.baseUrl : undefined,
      })),
    };
  }

  adapter(conn) {
    const meta = catalogEntry(conn.provider) || catalogEntry('custom');
    const apiKey = this.key(conn);
    if (conn.provider === 'gemini') return new GeminiProvider({ apiKey, model: firstModel(conn), db: this.db, log: this.log });
    if (conn.provider === 'deepseek') return new DeepSeekProvider({ apiKey, model: firstModel(conn) });
    if (conn.provider === 'anthropic') return new AnthropicAdapter({ ...conn, apiKey });
    return new OpenAICompatProvider({ id: conn.provider, name: meta?.name || conn.provider, apiKey, baseUrl: normalizeBaseUrl(conn.baseUrl || meta?.baseUrl || ''), model: firstModel(conn) || (conn.provider === 'custom' ? 'auto' : '') });
  }

  async testConnection({ provider, apiKey, baseUrl, model }) {
    const id = `${provider}-probe-${Date.now().toString(36)}`;
    const ref = `${id}-credential`;
    this.vault.set(ref, apiKey);
    const fallback = (catalogEntry(provider)?.fallbackModels || []).map((mid) => ({ id: mid, displayName: mid, available: true, verified: false, capabilities: normalizeCaps({}, mid, provider), source: 'documented-fallback' }));
    const conn = { id, provider, credentialRef: ref, baseUrl: baseUrl || catalogEntry(provider)?.baseUrl || '', models: model ? [{ id: model, verified: false }] : fallback };
    try {
      let discovered = [];
      try {
        discovered = await this.discover(conn, { force: true, allowFallback: true });
      } catch (err) {
        const cls = err.classify || classifyProviderError(err);
        if (cls.code === 'INVALID_CREDENTIAL') throw err;
      }
      if (!Array.isArray(discovered)) discovered = [];
      if (!discovered.length && model) discovered.push({ id: model, displayName: model, available: true, verified: false, capabilities: normalizeCaps({}, model, provider), source: 'manual' });
      if (!discovered.length) discovered = fallback;
      // Custom / Personal AI Hub: if discovery returned nothing but endpoint is reachable intent, seed "auto"
      if (!discovered.length && (provider === 'custom' || /personal-ai|ollama|localhost|127\.0\.0\.1/i.test(String(baseUrl || '')))) {
        discovered = [{ id: 'auto', displayName: 'auto', available: true, verified: false, capabilities: normalizeCaps({}, 'auto', provider), source: 'auto-default' }];
      }
      if (!discovered.length) throw Object.assign(new Error('No usable model is known for this provider. Paste the key and try again, or set Base URL for Custom (e.g. http://personal-ai-hub:8080/v1).'), { code: 'MODEL_OR_ENDPOINT_UNAVAILABLE', classify: { code: 'MODEL_OR_ENDPOINT_UNAVAILABLE', user: 'No usable model is known for this provider.' } });
      const probeId = model || selectProbeModel(discovered) || preferAutoModel(discovered) || discovered[0].id;
      const result = await this.probeModel(conn, probeId);
      if (result.ok) {
        const models = discovered.map((m) => ({ ...m, verified: m.id === probeId, lastVerified: m.id === probeId ? new Date().toISOString() : null }));
        return { ok: true, models, verifiedModel: probeId };
      }
      const cls = result.error?.classify || classifyProviderError(result.error);
      if (cls.code === 'INVALID_CREDENTIAL') throw result.error;
      // Key may still work on a later request. Keep models usable so chat does not stall.
      const models = discovered.map((m, i) => ({ ...m, verified: i === 0 || m.id === probeId, lastVerified: null }));
      return { ok: true, models, verifiedModel: models[0]?.id || probeId, warning: cls.user };
    } finally {
      this.vault.remove(ref);
    }
  }

  async discover(conn, { force = false, allowFallback = false } = {}) {
    const st = this.state();
    const stored = st.connections.find((c) => c.id === conn.id);
    if (!force && stored?.cacheAt && Date.now() - Date.parse(stored.cacheAt) < CACHE_MS && Array.isArray(stored.models)) return stored.models;
    const meta = catalogEntry(conn.provider) || {};
    const adapter = this.adapter(conn);
    let raw = [];
    try {
      if (typeof adapter.listModels === 'function' && meta.discover !== false) raw = await adapter.listModels();
      else if (conn.models?.length) raw = conn.models;
    } catch (err) {
      const cls = err.classify || classifyProviderError(err);
      if (cls.code === 'INVALID_CREDENTIAL' || cls.code === 'PERMISSION_DENIED') throw Object.assign(err, { classify: cls });
      if (!allowFallback) return [];
    }
    const models = normalizeModels(raw, conn.provider);
    if (!models.length && allowFallback && conn.models?.length) return normalizeModels(conn.models, conn.provider);
    return models;
  }

  async probeModel(conn, modelId) {
    const adapter = this.adapter({ ...conn, models: [{ id: modelId }] });
    try {
      const result = await adapter.complete({ prompt: 'Reply with exactly: OK', system: 'Connection verification. Do not perform any other task.', json: false, model: modelId, images: [] });
      if (!result?.text) throw new Error('Empty model verification response.');
      return { ok: true, result };
    } catch (err) {
      const cls = err.classify || classifyProviderError(err);
      return { ok: false, error: Object.assign(new Error(cls.user || err.message), { classify: cls, cause: err }) };
    }
  }

  upsertConnection(input) {
    const st = this.state();
    const id = input.id || `${input.provider}-${Date.now().toString(36)}`;
    const ref = input.credentialRef || `${id}-credential`;
    if (input.apiKey) this.vault.set(ref, input.apiKey);
    const next = { id, provider: input.provider, credentialRef: ref, baseUrl: input.baseUrl || catalogEntry(input.provider)?.baseUrl || '', status: input.status || 'UNVERIFIED', models: normalizeModelsState(input.models), lastError: input.lastError || null, lastVerified: input.lastVerified || null, cacheAt: input.cacheAt || new Date().toISOString() };
    const idx = st.connections.findIndex((c) => c.id === id || (c.provider === input.provider && c.provider !== 'custom'));
    if (idx >= 0) st.connections[idx] = { ...st.connections[idx], ...next };
    else st.connections.push(next);
    this.syncLegacyKeys(st);
    return this.save(st);
  }

  removeConnection(id) {
    const st = this.state(); const row = st.connections.find((c) => c.id === id);
    if (row?.credentialRef) this.vault.remove(row.credentialRef);
    st.connections = (st.connections || []).filter((c) => c.id !== id); this.syncLegacyKeys(st); return this.save(st);
  }

  setRouting({ preferredProvider, preferredModel, preferredModels }) {
    const st = this.state();
    st.mode = 'SELECTED';
    if (preferredProvider != null) st.preferredProvider = String(preferredProvider || '');
    const pair = normalizePreferredModels(preferredModels || (preferredModel ? [preferredModel] : st.preferredModels));
    st.preferredModels = pair.slice(0, 2);
    st.preferredModel = st.preferredModels[0] || '';
    this.syncLegacyKeys(st);
    return this.save(st);
  }

  isRoutingLocked() {
    const st = this.state();
    return Boolean(st.preferredProvider || normalizePreferredModels(st.preferredModels).length);
  }

  selectedModels() { return normalizePreferredModels(this.state().preferredModels || []); }

  syncLegacyKeys(st) {
    for (const c of st.connections || []) c.models = normalizeModelsState(c.models);
    const ds = st.connections.find((c) => c.provider === 'deepseek' && this.key(c));
    const gm = st.connections.find((c) => c.provider === 'gemini' && this.key(c));
    this.cfg.ai.deepseekKey = ds ? this.key(ds) : '';
    this.cfg.ai.geminiKey = gm ? this.key(gm) : '';
    const dsModels = normalizeModelsState(ds?.models);
    const gmModels = normalizeModelsState(gm?.models);
    if (dsModels.find((m) => m.verified)?.id) this.cfg.ai.deepseekModel = dsModels.find((m) => m.verified).id;
    if (gmModels.find((m) => m.verified)?.id) this.cfg.ai.geminiModel = gmModels.find((m) => m.verified).id;
    const preferred = st.preferredProvider || '';
    this.cfg.ai.provider = preferred || gm?.provider || ds?.provider || st.connections?.[0]?.provider || 'gemini';
  }

  candidates(task, modelRef = '') {
    const st = this.state(); const level = taskComplexity(task);
    let list = (st.connections || []).filter((c) => this.key(c) && c.status !== 'INVALID');
    const selected = normalizePreferredModels(st.preferredModels || []);
    if (selected.length) {
      const filtered = list.filter((c) => selected.some((ref) => ref.startsWith(`${c.provider}:`) || ref.startsWith(`${c.id}:`) || ref === c.provider));
      if (filtered.length) list = filtered;
    } else if (st.preferredProvider && st.preferredProvider !== 'AUTO') {
      const locked = list.filter((c) => c.provider === st.preferredProvider);
      if (locked.length) list = locked;
    }
    const out = [];
    for (const conn of list) {
      let models = normalizeModelsState(conn.models);
      if (!models.length) models = (catalogEntry(conn.provider)?.fallbackModels || []).map((id) => ({ id, verified: true }));
      const verified = models.filter((m) => m.verified === true);
      const usable = verified.length ? verified : models;
      for (const model of usable) {
        if (!model?.id) continue;
        const ref = `${conn.provider}:${model.id}`;
        const legacyRef = `${conn.id}:${model.id}`;
        if (modelRef && modelRef !== ref && modelRef !== legacyRef) continue;
        if (selected.length && !selected.includes(ref) && !selected.includes(legacyRef) && !selected.includes(model.id)) continue;
        out.push({ conn, model: model.id, ref, score: scoreModel(model, level) });
      }
    }
    if (!out.length) {
      for (const conn of list) {
        const models = normalizeModelsState(conn.models);
        const first = models[0] || (catalogEntry(conn.provider)?.fallbackModels || []).map((id) => ({ id }))[0];
        if (first?.id) out.push({ conn, model: first.id, ref: `${conn.provider}:${first.id}`, score: 1 });
      }
    }
    const added = new Map((st.connections || []).map((c, i) => [c.id, st.connections.length - i]));
    const rank = new Map(selected.map((ref, i) => [ref, selected.length - i]));
    return out.sort((a, b) => (rank.get(b.ref) || 0) - (rank.get(a.ref) || 0) || (added.get(b.conn.id) || 0) - (added.get(a.conn.id) || 0) || b.score - a.score);
  }

  async execute({ task, prompt, system, json = false, images = [], modelRef = '', signal = null, timeoutMs = 0, cancelSignal = null }) {
    const st = this.state();
    const level = taskComplexity(task);
    const preferred = normalizePreferredModels(st.preferredModels || (st.preferredModel ? [st.preferredModel] : []));
    const explicitRef = modelRef || '';
    const isLockedSelection = Boolean(explicitRef || preferred.length);
    let picks = this.candidates(task, explicitRef || preferred[0] || '');
    // Locked selection: try the selected model first; on transient/unavailable errors only,
    // allow same-connection backup models (same provider + key) without ever crossing providers.
    if (isLockedSelection) {
      const want = explicitRef || preferred[0];
      const locked = picks.filter((p) => p.ref === want || p.model === want.split(':').slice(1).join(':') || `${p.conn.provider}:${p.model}` === want);
      let primary = locked[0] || null;
      if (!primary) {
        const [prov, ...rest] = want.split(':');
        const mid = rest.join(':') || want;
        const conn = (st.connections || []).find((c) => (c.provider === prov || c.id === prov) && this.key(c) && c.status !== 'INVALID')
          || (st.connections || []).find((c) => c.provider === prov || c.id === prov)
          || (st.connections || [])[0];
        if (conn) primary = { conn, model: mid, ref: want, score: 100 };
      }
      picks = primary ? [primary, ...sameConnectionBackups(primary, preferred, level)] : [];
    } else if (picks.length > 1) {
      // 1.8.9: AUTO mode (no user-selected model) gets a short fallback ladder so one retired / overloaded /
      // rate-limited model cannot fail the whole request. A user-selected model stays provider-locked (above).
      picks = fallbackLadder(picks, Number(process.env.AI_LADDER_MAX || 3));
    }
    if (!picks.length) throw Object.assign(new Error('No verified AI model is available for this task. Connect a provider or refresh its models.'), { code: 'AI_UNAVAILABLE' });
    const errors = []; let tries = 0;
    const startedAt = Date.now();
    const totalBudget = timeoutMs > 0 ? Math.round(timeoutMs * 1.5) : 0;
    const badConnections = new Set();
    for (const pick of picks) {
      if (cancelSignal?.aborted) break;
      if (badConnections.has(pick.conn.id)) continue;
      // Attempt #1 keeps the caller's signal (unchanged behaviour). Later attempts get their OWN timeout,
      // so a slow first model cannot leave the fallback with an already-aborted signal.
      let attemptSignal = signal;
      let attemptTimeoutMs = timeoutMs;
      if (tries >= 1) {
        const remaining = totalBudget ? totalBudget - (Date.now() - startedAt) : 60000;
        if (remaining < Math.min(8000, Math.max(1500, Math.round((timeoutMs || 60000) * 0.2)))) break;
        const ms = Math.min(timeoutMs > 0 ? timeoutMs : 60000, remaining);
        const own = AbortSignal.timeout(ms);
        attemptSignal = cancelSignal ? AbortSignal.any([own, cancelSignal]) : own;
        attemptTimeoutMs = ms;
      }
      tries += 1;
      try {
        const adapter = this.adapter({ ...pick.conn, models: [{ id: pick.model }] });
        const sendImages = pick.conn.provider === 'deepseek' ? [] : images;
        let result;
        try {
          result = await adapter.complete({ prompt, system, json, model: pick.model, images: sendImages, signal: attemptSignal, timeoutMs: attemptTimeoutMs });
        } catch (imgErr) {
          const msg = String(imgErr?.message || '');
          if (sendImages?.length && (imgErr?.status === 400 || /image|vision|multimodal|media|content.*string/i.test(msg))) {
            result = await adapter.complete({ prompt, system, json, model: pick.model, images: [], signal: attemptSignal, timeoutMs: attemptTimeoutMs });
          } else {
            throw imgErr;
          }
        }
        this.markModelVerified(pick.conn.id, pick.model, result);
        if (tries > 1) result.fallbackFrom = errors[0]?.split(':')[0] || null;
        return result;
      } catch (err) {
        const cls = err.classify || classifyProviderError(err); errors.push(`${pick.conn.provider}/${pick.model}: ${cls.user}`);
        this.markError(pick.conn.id, cls.user, cls.code === 'INVALID_CREDENTIAL' ? 'INVALID' : 'ERROR');
        if (cls.code === 'INVALID_CREDENTIAL') { badConnections.add(pick.conn.id); continue; }
        if (tries === 1 && isLockedSelection && !isTransient(cls.code) && cls.code !== 'MODEL_OR_ENDPOINT_UNAVAILABLE') {
          break;
        }
        continue;
      }
    }
    throw Object.assign(new Error(errors.join(' | ') || 'No verified AI model is available'), { code: 'AI_UNAVAILABLE', providerErrors: errors });
  }

  markModelVerified(connectionId, modelId, result) {
    const st = this.state(); const row = st.connections.find((c) => c.id === connectionId); if (!row) return;
    row.models = normalizeModelsState(row.models);
    const m = row.models.find((x) => (x.id || x) === modelId); if (m && typeof m === 'object') { m.verified = true; m.lastVerified = new Date().toISOString(); }
    row.status = 'VERIFIED'; row.lastVerified = new Date().toISOString(); row.lastError = null; row.cacheAt = new Date().toISOString(); this.save(st);
  }

  markError(id, message, status = 'ERROR') {
    const st = this.state(); const row = st.connections.find((c) => c.id === id); if (!row) return;
    row.lastError = String(message || '').slice(0, 240); if (status === 'INVALID') row.status = 'INVALID'; this.save(st);
  }
}

function normalizeModelsState(models) {
  if (Array.isArray(models)) return models.map((m) => typeof m === 'string' ? { id: m, verified: false } : (m && typeof m === 'object' ? { ...m } : null)).filter((m) => m?.id);
  if (models && typeof models === 'object' && models.id) return [{ ...models }];
  return [];
}
function normalizePreferredModels(models) {
  if (!Array.isArray(models)) return models ? [String(models)] : [];
  return models.filter(Boolean).map(String).slice(0, 2);
}
function normalizeHubState(raw) {
  const st = { ...raw };
  st.mode = 'SELECTED';
  st.preferredProvider = st.preferredProvider && st.preferredProvider !== 'AUTO' ? String(st.preferredProvider) : '';
  st.preferredModels = normalizePreferredModels(st.preferredModels || (st.preferredModel && st.preferredModel !== 'AUTO' ? [st.preferredModel] : []));
  st.preferredModel = st.preferredModels[0] || '';
  st.connections = Array.isArray(st.connections) ? st.connections.map((c) => ({ ...c, models: normalizeModelsState(c.models) })) : [];
  return st;
}
function firstModel(conn) { return normalizeModelsState(conn.models).find((m) => m?.verified === true)?.id || normalizeModelsState(conn.models)[0]?.id || ''; }
function normalizeModels(raw, provider) {
  return (raw || []).map((m) => {
    const id = String(typeof m === 'string' ? m : (m.id || m.name || '')).replace(/^models\//, '');
    if (!id || /embedding|moderation|image-generation|tts|transcri|audio|rerank/i.test(id)) return null;
    return { id, displayName: typeof m === 'object' ? (m.displayName || id) : id, available: true, verified: false, capabilities: normalizeCaps(m, id, provider), contextWindow: typeof m === 'object' ? (m.context_length || m.inputTokenLimit || null) : null, lastVerified: null, source: 'discovery' };
  }).filter(Boolean).slice(0, 48);
}
function normalizeCaps(meta, id, provider) {
  const text = JSON.stringify(meta || '').toLowerCase(); const n = id.toLowerCase();
  return {
    chat: true, text_generation: true,
    coding: /code|gpt|claude|gemini|deepseek|grok|llama|mistral|qwen/.test(n) ? true : 'unknown',
    reasoning: /reason|think|pro|opus|sonnet|o[1-9]|grok/.test(n) ? true : 'unknown',
    vision: /vision|gpt-4o|gemini|claude|grok/.test(n) || /image/.test(text) ? true : 'unknown',
    tools: /tool|function/.test(text) ? true : 'unknown', streaming: 'unknown', function_calling: /tool|function/.test(text) ? true : 'unknown',
    long_context: Number(meta?.context_length || meta?.inputTokenLimit || 0) >= 100000 ? true : 'unknown', structured_output: provider === 'openai' || /json/.test(text) ? 'unknown' : 'unknown',
  };
}
function selectProbeModel(models) {
  const autoId = preferAutoModel(models);
  if (autoId) return autoId;
  return [...models].sort((a, b) => scoreModel(b, 'medium') - scoreModel(a, 'medium'))[0]?.id;
}
function scoreModel(model, level) {
  const n = String(model.id || '').toLowerCase(); let s = 50;
  if (n === 'auto') s += 100; // Personal AI Hub / smart router default
  if (level === 'high' && /pro|reason|opus|sonnet|gpt-5|gpt-4|grok-4|deepseek-v4/.test(n)) s += 20;
  if (level === 'low' && /flash|mini|haiku|small|lite/.test(n)) s += 15;
  if (model.capabilities?.coding === true) s += level === 'high' ? 10 : 2;
  if (model.capabilities?.reasoning === true && level === 'high') s += 8;
  if (/preview|exp/.test(n)) s -= 5;
  return s;
}

/**
 * Pick up to `max` distinct (connection, model) attempts: first the best model of every connection
 * (provider diversity), then second-best models of the same connection. Order of `picks` is preserved.
 */
export function fallbackLadder(picks, max = 3) {
  const seen = new Set();
  const firstPerConn = [];
  const rest = [];
  const usedConn = new Set();
  for (const p of picks) {
    const key = `${p.conn.id}:${p.model}`;
    if (seen.has(key)) continue;
    seen.add(key);
    if (!usedConn.has(p.conn.id)) { usedConn.add(p.conn.id); firstPerConn.push(p); } else rest.push(p);
  }
  return [...firstPerConn, ...rest].slice(0, Math.max(1, max));
}

function sameConnectionBackups(primary, preferred = [], level = 'high', max = 2) {
  const conn = primary?.conn;
  if (!conn) return [];
  const seen = new Set([primary.model]);
  const out = [];
  const push = (modelId, score = 0) => {
    if (!modelId || seen.has(modelId)) return;
    if (/embedding|moderation|image-generation|tts|transcri|audio|rerank/i.test(modelId)) return;
    seen.add(modelId);
    out.push({ conn, model: modelId, ref: `${conn.provider}:${modelId}`, score });
  };
  for (const pref of preferred || []) {
    const [prov, ...rest] = String(pref || '').split(':');
    const mid = rest.join(':');
    if (mid && (prov === conn.provider || prov === conn.id)) push(mid, 200);
  }
  const models = normalizeModelsState(conn.models);
  const verified = models.filter((m) => m.verified === true).sort((a, b) => scoreModel(b, level) - scoreModel(a, level));
  for (const m of verified) push(m.id, 150 + scoreModel(m, level));
  const others = models.filter((m) => m.verified !== true).sort((a, b) => scoreModel(b, level) - scoreModel(a, level));
  for (const m of others) push(m.id, scoreModel(m, level));
  if (conn.provider === 'gemini') {
    for (const candidate of GEMINI_MODEL_CANDIDATES) push(candidate, 10);
  }
  return out.slice(0, max);
}

class AnthropicAdapter {
  constructor(conn) { this.conn = conn; this.name = 'anthropic'; }
  async listModels() {
    const res = await fetch('https://api.anthropic.com/v1/models', { headers: { 'x-api-key': this.conn.apiKey, 'anthropic-version': '2023-06-01' }, signal: AbortSignal.timeout(20000) });
    const raw = await res.text(); if (!res.ok) { const cls = classifyProviderError(raw, res.status); throw Object.assign(new Error(cls.user), { classify: cls, status: res.status }); }
    const data = JSON.parse(raw); return Array.isArray(data.data) ? data.data.map((m) => ({ id: m.id, displayName: m.display_name, contextWindow: m.max_input_tokens })) : [];
  }
  async complete({ prompt, system, json = false, model, signal = null, timeoutMs = 120000 }) {
    const use = model || firstModel(this.conn); if (!use) throw new Error('Anthropic has no verified model yet.'); const started = Date.now();
    const timeout = AbortSignal.timeout(timeoutMs > 0 ? timeoutMs : 120000);
    const combinedSignal = signal ? AbortSignal.any([timeout, signal]) : timeout;
    const res = await fetch('https://api.anthropic.com/v1/messages', { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': this.conn.apiKey, 'anthropic-version': '2023-06-01' }, body: JSON.stringify({ model: use, max_tokens: 4096, system: system || undefined, messages: [{ role: 'user', content: json ? `${prompt}\nReturn JSON only.` : prompt }] }), signal: combinedSignal });
    const raw = await res.text(); if (!res.ok) { const cls = classifyProviderError(raw, res.status); throw Object.assign(new Error(cls.user), { classify: cls, status: res.status }); }
    const data = JSON.parse(raw); const text = (data.content || []).map((p) => p.text || '').join('\n'); if (!text) throw new Error('Anthropic returned an empty response');
    return { text, provider: 'anthropic', model: use, durationMs: Date.now() - started, tokens: (data.usage?.input_tokens || 0) + (data.usage?.output_tokens || 0), rawMeta: { key: maskKey(this.conn.apiKey) } };
  }
}
